# Execution ledger — independent source review

**Disposition: PASS_WITHIN_STATED_SCOPE.** All execution described as “own” below was visible in this review's container/tool responses. No cryptographic code was compiled or run. Retained CI evidence is labelled separately and is not attributed to this reviewer.

## 1. Supplied bytes and authority

| Supplied object | Bytes | Computed SHA-256 |
|---|---:|---|
| `lossless-client-io-final-review-5f26c775.zip` | 2223215 | `1d092ae10c9b3d20afc03eb9e784ff69d806bc12e6cf0da14ed0461783fae653` |
| External `.zip.sha256` | 111 | `0b0f7a17b4fee9e3dc23acccb9a5df1e471d88f3371f0f9d549320901141db3f` |
| Input `MANIFEST.json` | 79261 | `e912cbd6af3c81301a9aca7ad29a79d010dc03134539ccacb6b7f23070cba349` |
| Input `TASK.md` | 20416 | `05179f2a09993d4fa025352d021e768a074bb2644bd8d3c5f4fbae09ca1c3b1b` |
| Supplied paper PDF | 759375 | `61d9b948b17b6a624d3bf3372462555288308011226d2893e9e6bc3d6d197eac` |

Observed archive checks: one root, 206 unique regular members, no traversal/symlink/duplicate or case-fold collision, CRC valid, 205 exact non-self manifest payloads with matching lengths and SHA-256, 8,557,583 total uncompressed bytes. The sidecar's text names the supplied ZIP and contains its computed digest. TASK was read completely. Historical authorization/1000-trial clauses were not followed.

Working input root was `/mnt/data/review_work/input/lossless-client-io-final-review-5f26c775`. This is an extracted copy of the supplied ZIP, not a user's local checkout. The review does not establish private Git access or independent remote service attestation.

Declared engineering source `5f26c77598a350bbdce9f572f64aada9d38c4117`; evidence/document snapshot `3eae38f518cba6d4bcf4e53229334571f9152eb6`; official OpenFHE pin `df495ba2e91739a6dc8f1de254fc5a41155ce504`. These identities were checked for consistency against the supplied manifest, source identity, stage records, raw test output and retained run metadata.

## 2. Own observed non-cryptographic work

The commands below are the actual principal scratch-helper invocations, not commands asserted to have run on Linux/Windows CI. The helpers were authored for this review; no supplied historical parser was assumed to exist. Source reading additionally used ordinary `cat`, `sed`, `nl`, `grep`, Python text reads and line-range inspection. The attached JSON records preserve computed results; they are not copies of another reviewer's verdict.

### Packet and readback

```sh
python /mnt/data/review_work/verify_packet.py
```

Observed output included `archive_bytes=2223215`, the complete matching ZIP digest above, `regular_members=206`, `manifest_payloads=205`, and:

```text
PASS: outer identity, sidecar, safe unique regular paths, single root, CRC, exact manifest set/bytes/SHA256, TASK identity
```

The small computed digest/readback was reported visibly before substantive conclusions. Output record: `evidence/packet_verification.json`.

### Six-stage offline replay

```sh
python /mnt/data/review_work/replay_history.py
```

The helper copied `history/base/project/` into `/mnt/data/review_work/replay`, then invoked, in numerical order, the following command form with each supplied patch's exact absolute path and the replay directory as cwd:

```text
patch --batch --fuzz=0 -p1 -i <input-root>/history/<numbered-stage>.patch
```

The six filenames were `01-red-a.patch`, `02-green-a.patch`, `03-red-first-modulus.patch`, `04-green-first-modulus.patch`, `05-red-b.patch`, `06-green-b.patch`. All returned successful `patching file ...` output; exact stage file-set/hash checks passed after each. Final output: `replay_to_current=PASS`, current engineering files28, base engineering files24, base unchanged22. This changed only a disposable reconstruction, not supplied current source/tests/workflow. Output including each patch's stdout: `evidence/history_verification.json`.

### Independent exact arithmetic

```sh
python /mnt/data/review_work/check_exact_math.py
```

Observed final `status=PASS`: 16 left, 16 right and 16 product pairs match source versus frozen specification exactly; all 16 complex products/32 components independently recomputed with rational arithmetic; exact sub-binary64 input/product deltas; exact reduced scale denominator 1267650600226646386227681786497; L1 envelopes below one; symbolic butterfly check on 32 even monomials / 512 slots and 32 inverse compositions; tie-down examples `[-2,-1,0,1]` for `[-1.5,-0.5,0.5,1.5]`.

Output: `evidence/exact_math_verification.json`. This checks a mathematical transcription of inspected source formulas, not Boost transcendental execution, ciphertext correctness on a new key, or universal correct rounding.

### Independent raw-log reconciliation

```sh
python /mnt/data/review_work/check_logs.py
```

Observed final `status=PASS`. Every line of all 12 supplied job logs was processed: 50,700 lines, 1,078 actual Start/command/result bindings, 160 exact Fraction checks of emitted numerical gates across the history. Live57/58 test lists, order and commands were reconciled to current CMake. Source/run/job/pin identities, five API target builds and ordered boundary markers were checked. Error-output reprints were excluded from actual-execution counts. Latest root ledger: 238 independently matching bindings and 40 numerical comparisons, both hosts matching.

Focused output: `evidence/log_summary.json`. It retains stage/source/run/job identities, exact input log hashes, live-list and build anchors, numerical records, ordered markers, dependency-step state and summary counts. It is not a newly executed test log.

### Supplementary calculations

An observed inline `python - <<'PY'` calculation rebuilt the ordered legacy 57 `name<TAB>command<LF>` ledger from CMake: 3869 bytes, SHA-256 `3527832e2d46591c46a93d3cb96d5469a9362ec4ca1ba39c8ed0587964e77f8b`.

It also reconstructed CRLF bytes from the supplied latest Windows LF log: 427323 bytes, SHA-256 `fa9c7a8cfd788cbaf263f304e1dfddea373866a4ecb428f3676ba048ac6adc02`, matching the retained decoded-text provenance. **This was reconstruction from supplied text, not retrieval of original transport bytes.** Finally, exact rational substitution of the physical factor for S1 gives the slot-0 error stated in REVIEW §2 and exceeds 2^-80. Output: `evidence/supplementary_checks.json`.

### Source/paper inspection and observable limitations

The Files read attempt on the ZIP returned metadata and “No readable content”; it did not expose extracted source. The already mounted ZIP was therefore read with the container. Container outputs were observable; there was no missing-execution-result condition.

A public paper-PDF web open was restricted, and a screenshot call had no usable PDF reference. No remote PDF content was obtained. The supplied PDF/text remained available: the 15-page local PDF was inspected with PyMuPDF, with rendered pages 4, 7, 8 visually opened for the relevant mathematical definitions. No OCR or replacement OpenFHE download was used. Source/API conclusions rely on the packet, not the failed public fetch.

Early drafts of the review-only parsing helpers failed on whitespace in wrapped C++ literals, heterogeneous historical run-JSON keys, padded CTest Start lines, and Windows Ninja's different build-completion wording. Those helper parsers were corrected against actual readbacks before their reported final PASS. These were not project failures or cryptographic execution attempts; no source/test fix or rerun was performed to accommodate them. Failed parser drafts are not counted as successful verification evidence.

## 3. Retained hosted executions — NOT this reviewer's runtime

All six supplied terminal records specify event `push`, attempt 1. Linux/Windows job IDs and source SHAs are in `evidence/log_summary.json` and the original `*_RUN_FINAL_01.json` records under the input's `project/coordination/handoffs/lossless-client-io-pro-packet-01/`.

| Stage | Retained run | Linux / Windows jobs | Actual per-host result |
|---|---:|---|---|
| A RED | 33948543866 | 101258898386 / 101258898314 | 60 old passes; missing new public header stops new build; new focus/full58 NOT RUN |
| A GREEN | 33950923304 | 101265404189 / 101265404098 | 119 passes; actual-first55 finding not yet closed |
| First-modulus RED | 33952773643 | 101270511248 / 101270511113 | 60 old passes, then 1 intended failure: actual56 incorrectly accepted |
| First-modulus GREEN | 33953977794 | 101273809680 / 101273809728 | 119 passes; same actual56 fixture correctly rejected |
| B RED | 33960255214 | 101290796500 / 101290796367 | 60 old passes, then 1 failure: drifted Clone accepted; later Bind/Decrypt rejection and cleanup NOT RUN |
| B GREEN | 33961604938 | 101294323897 / 101294323767 | 119 passes; all three ordered drift rejections and cleanup; final 58/58 |

For each GREEN host, 119 bindings means the groups `1+2+57+1+58`, not 119 distinct suites, keys, trials or experiments. Latest Linux used an exact-key OpenFHE cache: dependency configure/build was skipped. Latest Windows configured/built/installed it. Both built the project and executed the final 58 suite. Runner/MSYS2 warning text was retained and distinguished from project compiler diagnostics.

Latest supplied LF log identities:

| Host | Lines / bytes | SHA-256 |
|---|---|---|
| Linux | 4714 / 337688 | `c8c09173e865140d624529c948ee020918727595d312fc3b13e4a6ea2c2d9f61` |
| Windows | 5543 / 421780 | `d05837d34ae99476ac90823e70d38c1192d3476ca845468faf282b8c15bbf927` |

The numerical `result=PASS` line is earlier than the final B assertions. Full-contract completion is anchored to ordered markers and actual CTest success, not that numerical line alone. Retained root verification and independent execution records were inputs to reconciliation, not runs performed here.

## 4. Explicit NOT RUN / NOT DONE

No OpenFHE or project configure/build, FHE encryption/decryption, test binary, CTest, benchmark, key generation, bootstrap/refresh, or 1000-trial batch was executed by this reviewer. No CI dispatch/rerun, credentials/browser-state access, private Git inspection, push/merge, external message, agent dispatch or second upstream checkout occurred. No current source, test, workflow or threshold was edited. No full-packing N32768, same-root h128 or eight-squaring experiment was attempted. No existing historical workflow was executed.

The later project goals and general accuracy/security claims remain unestablished here. They are not new review gates and do not turn this bounded source acceptance into full paper completion.

## 5. Delivery integrity

The four requested review documents and focused own-check JSON outputs are packaged under one output root. `MANIFEST.json` explicitly excludes itself and hashes every other packaged regular file. The external `.zip.sha256` hashes the completed ZIP and is not inside it. The final pre-packaging check rehashes all 205 supplied payloads and the input manifest and validates output references and JSON consistency; its result is included as `evidence/final_checks.json`. After packaging, CRC, exact ZIP membership, every manifest length/hash, and external sidecar agreement are verified again with observable tool output. The external sidecar is authoritative for the ZIP's final computed digest; no self-referential ZIP digest is embedded inside it.
