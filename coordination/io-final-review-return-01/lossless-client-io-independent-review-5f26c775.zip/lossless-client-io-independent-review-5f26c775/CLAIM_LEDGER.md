# Focused claim ledger

Disposition: **PASS_WITHIN_STATED_SCOPE**. No open P0/P1/P2 finding.

## Reference key and evidence classes

Every input reference is relative to `lossless-client-io-final-review-5f26c775/` in the verified user ZIP. Line numbers refer to the actual supplied text, not an external current branch. Paper pages are PDF pages.

| Abbreviation | Exact input path |
|---|---|
| IO_H | `project/include/openfhe_2023_1788/high_precision_client_io.h` |
| IO_CPP | `project/src/high_precision_client_io.cpp` |
| DC | `project/src/double_ckks.cpp` |
| DC_H | `project/include/openfhe_2023_1788/double_ckks.h` |
| TEST | `project/tests/precision_client_io_first_mult2_contract_test.cpp` |
| ORACLE | `project/tests/precision_client_io_oracle.h` |
| SPEC | `project/coordination/returns/lossless-client-io-pro-b64a980/PROPOSED_FIRST_TDD_CONTRACT.md` |
| PUBLIC | `project/coordination/returns/lossless-client-io-pro-b64a980/PROPOSED_PUBLIC_INTERFACE.md` |
| DESIGN | `project/coordination/returns/lossless-client-io-pro-b64a980/DESIGN_DECISION.md` |
| IMP | `project/coordination/tasks/LOSSLESS_CLIENT_IO_PRO_IMPLEMENTATION_01.md` |
| OFF/ | `official-full/` |
| EVIDENCE/ | `project/coordination/handoffs/lossless-client-io-pro-packet-01/` |
| PAPER | `paper/PAPER-2023-1788.pdf` |

**S** = observed in source/specification; **C** = independently computed here without cryptography; **H** = observed in supplied hosted evidence, not executed here; **U** = not established at this review boundary. Historical implementation instructions are reference material; current `TASK.md:1–147` is controlling.

## Load-bearing conclusions

### C01 — Packet identity and bounded source association [C, H]

The outer ZIP, sidecar, TASK and manifest identities match; safe paths/CRC and exact manifest membership/bytes/hashes pass. Six offline patch applications with zero fuzz match all six stage hash sets and the 28 current engineering files. The declared source association is also present in terminal run metadata and the new test's compiled-source output. This is a supplied-packet/source/log association, not independent remote Git or service attestation.

Anchors: `TASK.md:9–39,62–95`; `SOURCE_IDENTITY.json`; `MANIFEST.json`; `history/STAGES.json`; `history/01-red-a.patch` through `history/06-green-b.patch`; `EVIDENCE/*_RUN_FINAL_01.json`. Own outputs: `evidence/packet_verification.json`, `evidence/history_verification.json`, `evidence/log_summary.json`.

### C02 — Correct packed-stride transform convention [S, C; H on frozen vectors]

Forward sign, powers-of-five order, real/imaginary pairing, bit reversal and inverse 1/16 normalization agree with the official special FFT and paper notation for the specified projection. Exact cyclotomic-ring checking covers all 32 even monomials, 512 forward slot identities and inverse composition. Production numeric execution was not repeated here.

Anchors: `IO_CPP:303–407`; `ORACLE:302–368`; `TEST:91–148`; `DESIGN:262–319`; `OFF/src/core/lib/math/dftransform.cpp:50–69,209–268`; `OFF/src/pke/lib/encoding/ckkspackedencoding.cpp:336–405,465–508`; `PAPER:p.4`. Own output: `evidence/exact_math_verification.json`.

### C03 — Rational ownership and absence of a binary64 semantic bridge [S]

Positive scales own private cpp_int values and are reduced; zero/negative numerator or denominator is rejected. Public real values are 100-digit decimal numbers; work types are 160/220 digits. Integers cross into/out of the dynamic OpenFHE backend through decimal strings. Double values remain physical metadata, not slot normalization.

Anchors: `IO_H:17–35,69–87`; `IO_CPP:46–53,269–281,362–424,448–501,565–595`; `TEST:24–89`; `OFF/src/core/include/math/hal/bigintbackend.h:64–71`; `OFF/src/core/include/math/hal/bigintdyn/backenddyn.h:48–52`; `OFF/src/core/include/math/hal/bigintdyn/ubintdyn.h:74–81,186–195,829–837`.

### C04 — Scale transition and physical-factor order [S, C, H]

Fresh S0 is 2^100 once; S1 is 2^200/(qDiv*qL). The denominator is exactly 1267650600226646386227681786497. Correct basis transition is Q8→Q7→Q6, result level2/degree2/two components. At this FIXEDMANUAL pin the physical divisor is 2^50; the physical result factor is 2^100 and is not S1. The binder independently derives state from fresh parents, but does not authenticate operand lineage.

Anchors: `IO_CPP:448–545`; `DC:355–437,763–812,925–1117`; `PUBLIC:212–243`; `OFF/src/pke/include/schemerns/rns-cryptoparameters.h:603–649`; `OFF/src/pke/lib/scheme/ckksrns/ckksrns-leveledshe.cpp:172–189`; `PAPER:pp.7–8, Definitions4.1/4.3/4.5/4.7`. Own outputs: `evidence/exact_math_verification.json`, `evidence/supplementary_checks.json`. Hosted values: latest Linux log2657/4638 and Windows log3539/5527.

### C05 — Conservative rounding, strict range and centering [S; C for exact convention]

Tie-down means -1.5→-2 and +1.5→1. The public encoding policy rejects exact ties, equality with the ambiguity margin, inconsistent rounding, nonfinite values and insufficient working precision. It also enforces 2|c|<Q before reduction. Centered diagnostics use all coefficients. They establish final representatives, not prior nonwrap or all-key bounds. Universal transcendental rounding is **U**, explicitly not claimed.

Anchors: `IO_CPP:371–392,448–501,565–595`; `DESIGN:50–82,325–363`; `SPEC:181–196`; `PAPER:p.4`.

### C06 — Frozen numerical targets are independent of codec output [C, S, H]

All 16 complex products and every source/spec input/product component agree under exact rational recomputation. Adjacent witnesses are `(2^-70,2^-73)` and `(17/2^75,-3/2^74)`. Reported errors are checked without binary64 parsing. All 40 latest reported error-bound comparisons pass; the C++ itself applies the fixed ≤2^-80 and ≤2^-120 gates before successful completion.

Anchors: `SPEC:59–113,181–210`; `ORACLE:372–476`; `TEST:97–148,453–493,812–846`; latest logs as C04. Own outputs: `evidence/exact_math_verification.json`, `evidence/log_summary.json`. This does not establish relative accuracy on all near-zero inputs.

### C07 — Oracle independence is substantive but scoped [S, C]

Schoolbook negacyclic secret evaluation, explicit CRT and direct projected Horner do not use the production FFT or public Decrypt for their independent coefficient result. Literal monomials/interpolation and exact expected products anchor semantics. A shared wrong physical scale is falsified by the slot-0 calculation in `evidence/supplementary_checks.json`. Remaining common dependencies: official inverse NTT for coefficient conversion, and the intentionally shared packed-stride observation/receipt scale. Adding a small odd monomial can leave both projected answers and the maximum diagnostic unchanged; full canonical correctness is therefore **U**, not silently claimed.

Anchors: `ORACLE:75–272,302–368`; `TEST:91–148,453–493`; `DESIGN:288–309`; `SPEC:198–210`.

### C08 — Actual finalized profile and correct pinned types [S, H]

The constructor validates actual supported modes/geometry, actual first55, ordered basis structure and HYBRID tables. The four disabled CKKS setters are not used. The first56 control proves its actual state, uses no new keypair and checks snapshot nonmutation; a genuine RED precedes its smallest guard. Global Format and backend aliases correspond to the pin.

Anchors: `IO_CPP:46–53,97–245`; `TEST:233–336`; `history/03-red-first-modulus.patch`, `history/04-green-first-modulus.patch`; `OFF/src/core/include/utils/inttypes.h:65`; `OFF/src/pke/include/scheme/ckksrns/gen-cryptocontext-ckksrns-params.h:78–95`; `OFF/src/pke/include/scheme/gen-cryptocontext-params-defaults.h:46–86`; `EVIDENCE/FIRST_MODULUS_RED_LINUX_JOB_01.log:2657–2675`, corresponding Windows3547–3565, and subsequent GREEN records.

### C09 — Malformed-key checks precede unsafe upstream access [S, H]

The exact-two-element PK and full-Q SK checks establish all outer/tower parameter, value, format, root/order, context and tag requirements before upstream indexing/dereferencing. Twenty-two PK plus ten SK cases exercise default, moved-from/null-Params, empty-value, wrong-format, short/reordered/root-mismatched and partial malformed towers. Structural validity does not prove an RLWE key relation.

Anchors: `IO_CPP:137–160,448–463,547–557`; `TEST:497–557`; `IMP:127–144`; `OFF/src/pke/lib/schemerns/rns-pke.cpp:148–223`; `OFF/src/core/include/lattice/hal/default/dcrtpoly-impl.h:430–433,660–665`; `OFF/src/core/include/lattice/hal/default/poly.h:188–199`. H: current test reaches malformed_key_rejections=32 and actual final success on both hosts.

### C10 — Public coefficient I/O, not a cryptographic reimplementation [S, H]

Element Encrypt and the concrete CKKS Poly Decrypt dispatch match the corrected definitions; named ConstCiphertext lvalue and isValid ordering are correct. NativePoly-only or DecryptCore shortcuts are absent. Configured modes are not downgraded; v1 explicitly supports fixed-noise/COMPLEX only. General decryption-output protection equivalence and secure erasure are **U** and not claimed.

Anchors: `IO_CPP:448–501,547–595`; `PUBLIC:245–258`; `DESIGN:128–142,375–383`; `OFF/src/pke/include/schemebase/base-scheme.h:205–224`; `OFF/src/pke/lib/scheme/ckksrns/ckksrns-scheme.cpp:42–57`; `OFF/src/pke/lib/schemerns/rns-pke.cpp:40–69`; `OFF/src/pke/lib/scheme/ckksrns/ckksrns-pke.cpp:44–95`; `OFF/src/pke/include/schemebase/decrypt-result.h:63–84`; `OFF/src/pke/lib/encoding/ckkspackedencoding.cpp:408–508`.

### C11 — Owned binding, narrow clone isolation and ordered drift rejection [S, H]

Receipts own a strong context binding and immutable basis values. Live Q/P/QP/PK/partitions/counts/PModq are checked before clone/bind/decrypt; counts precede indexed partition access. Clone isolates values/scalars/empty maps, not shared Params. State remains cached/noexcept. Original contexts/maps remain alive in the B fixture, whose sole basis mutation follows all crypto setup and whose cleanup erases only its own eval tag. This is not concurrent-mutation safety or a full context deep copy.

Anchors: `IO_H:95–109`; `IO_CPP:19–31,218–267,426–446,503–563`; `TEST:387–442,559–722`; `IMP:146–163`; `OFF/src/pke/include/ciphertext.h:390–405`; `OFF/src/core/include/lattice/hal/default/dcrtpoly.h:74–106`; `OFF/src/core/include/lattice/hal/default/poly.h:133–146`; `OFF/src/pke/include/schemerns/rns-cryptoparameters.h:409–421`; `OFF/src/pke/include/cryptocontextfactory.h:66–68`; `OFF/src/pke/lib/cryptocontext.cpp:107–115`; `OFF/src/pke/include/schemebase/base-cryptoparameters.h:115–120`.

H: B RED Linux2661–2665 / Windows3543–3547 stops at Clone acceptance; B GREEN Linux2661–2668 and4642–4649 / Windows3543–3550 and5531–5538 reaches all three rejections and cleanup.

### C12 — Acceptance is not project completion [S, H; broader claims U]

Both latest jobs pass the full58 suite, with source/run identities and exact command order reconciled. Latest Linux uses the pinned dependency cache; Windows builds the dependency. These are retained hosted results, not this reviewer's runtime. Full packing, same-root h128 integration, repeated eight no-refresh squarings, security certification, all-key accuracy and universal rounding remain unestablished here. None is a newly imposed experiment obligation.

Anchors: `TASK.md:1–23,97–147`; `project/coordination/CORRECTNESS_ACCEPTANCE_SCOPE_20260905.md:1–35`; `EVIDENCE/CYCLE_B_GREEN_RUN_FINAL_01.json`; current raw log ranges in C11 and `evidence/log_summary.json`.
