# Final independent source review — high-precision client I/O

**Disposition: PASS_WITHIN_STATED_SCOPE**  
**Open findings: P0 = 0; P1 = 0; P2 = 0.**  
Review date: 2026-09-05. This is a source-and-retained-evidence decision, not a new cryptographic execution or an adoption of another reviewer's vote.

## 1. Decision and exact boundary

The supplied implementation supports the frozen **N64 / M128 / S16 / gap2**, native64/backend4, first-operation client seam:

`Encrypt → DCP → Mult2 → RCB → BindFirstMult2Rcb → Decrypt`.

I found no concrete missing requirement, incorrect implementation, or scope expansion requiring a change at this boundary. The previously identified actual-first-modulus and shared-Params defects are genuine historical defects and are closed in the reviewed source, not dismissed because a numerical roundtrip passes. No source, test, numerical threshold, workflow, or additional experiment needs changing to accept this review.

Reviewed engineering source: `5f26c77598a350bbdce9f572f64aada9d38c4117`. Evidence/document snapshot: `3eae38f518cba6d4bcf4e53229334571f9152eb6`. Official source pin: OpenFHE 1.5.0 `df495ba2e91739a6dc8f1de254fc5a41155ce504`.

The module is deliberately not the same-root h128 family integration, full packing at N32768, eight no-refresh squarings, a security-certified parameter set, or a universal accuracy theorem. The user-cancelled 1000-trial requirement is not an acceptance condition.

### Input identity and review coverage

The 2,223,215-byte ZIP and external sidecar agree on SHA-256 `1d092ae10c9b3d20afc03eb9e784ff69d806bc12e6cf0da14ed0461783fae653`. I checked CRC, safe unique regular paths, one-root layout, the exact 206-member set, all 205 manifest payload sizes/hashes, and the separately supplied manifest/TASK identities. `MANIFEST.json` explicitly excludes itself. TASK was read completely and governs this review.

The substantive read covers both complete production headers/sources, the complete new test and independent oracle, their frozen numerical/interface rules and corrections, relevant complete pinned API definitions, chronological engineering deltas, and all twelve retained job logs through an offline parser plus targeted source/log inspection. The 77 selected official files are not represented as an entire build tree or a newly fetched upstream checkout. The unchanged historical workflow is source evidence only.

All references below are relative to the verified input archive root. Abbreviations are expanded in `CLAIM_LEDGER.md`; `OFF/` means `official-full/`, and `EVIDENCE/` means `project/coordination/handoffs/lossless-client-io-pro-packet-01/`.

## 2. Mathematical and numerical conclusions

### Transform, projection, and independent anchors

For the supported geometry, the observable is the canonical evaluation of the **even-coefficient projection**, not of an arbitrary full 64-coefficient polynomial. With a primitive 128th root ζ and e_k = 5^k mod 128, it is

`E(c)[k] = Σ(j=0..31) c[2j] ζ^(2j e_k)`.

Since each e_k is 1 modulo 4, `ζ^(32 e_k) = i`; grouping `c[2j] + i*c[2j+32]` is therefore correct. Production uses the matching positive forward roots, negative inverse twiddles, bit reversal, and one inverse normalization by 16. Its roots are generated separately at 160 and 220 decimal digits, not lifted from the official double cache. This agrees with the paper's canonical convention and the pinned special FFT's partial-packing interpretation.

I independently checked the mathematical butterfly over **Q[ζ]/(ζ^64+1)** on all 32 even monomials: all 512 slot identities and all 32 inverse compositions matched exactly. This is an exact symbolic check of the inspected formulas, not execution or a floating-point certification of the C++ implementation. The source's separate literal tests for `1`, `X^32`, `X^2`, and off-stride `X` additionally prevent the test from relying only on a self-inverting codec.

Anchors: `IO_CPP:303–407`; `ORACLE:302–368`; `TEST:91–148`; `DESIGN:262–319`; `OFF/src/core/lib/math/dftransform.cpp:50–69,209–268`; `OFF/src/pke/lib/encoding/ckkspackedencoding.cpp:336–405,465–508`; supplied paper, p.4, canonical embedding/encoding notation. Exact results: `evidence/exact_math_verification.json`.

### Exact scale, metadata, and divisors

`PositiveRationalScale` rejects zero/negative operands, gcd-reduces positive integers, and owns its numerator and denominator. `ClientReal` is genuinely `cpp_dec_float<100>`; the semantic slot/coefficient route does not narrow through binary64. Integer bridges use decimal strings with an exact roundtrip check.

Fresh encoding multiplies the inverse coordinates by **S0 = 2^100 once**. Fresh metadata's degree 2 and recorded double factor describe compatibility; they do not cause another coefficient scaling. The first result removes qDiv and then qL from the **ordered** parent basis, leaving the six-tower prefix, level 2, two evaluation-format components, degree 2, 16 slots, integer factor 1, matching key/context, and an empty metadata map.

I recomputed:

- qDiv = 1125899906843009; qL = 1125899906840833;
- qDiv × qL = **1267650600226646386227681786497**;
- **S1 = 2^200 / 1267650600226646386227681786497**, already reduced.

An important distinction is preserved: at this pin, **FIXEDMANUAL `GetModReduceFactor(6)` returns the approximate base 2^50**, not the exact qL integer. Thus the physical sequence `fresh* fresh / base / modReduce` returns a recorded factor of 2^100, while the logical result scale is S1. Production reproduces the evaluator's operation order and never substitutes that double for S1. The paper's Tensor2 omission of the low×low term and subsequent relinearization/rescaling are approximate arithmetic, not an exact polynomial-product claim.

As an independent scale falsifier, normalizing an ideal slot-0 product by the physical factor instead of S1 creates an imaginary-component error of exactly `1583015269021418879 / 20282409603626342179642908583952`, greater than 2^-80. Consequently, sharing the receipt's scale between public decode and the oracle does not by itself let this concrete wrong-scale implementation pass the frozen product test.

Anchors: `IO_H:17–35,69–87`; `IO_CPP:269–281,411–424,448–501,503–545`; `DC:763–812,925–1117`; `PUBLIC:212–243`; `OFF/src/pke/include/schemerns/rns-cryptoparameters.h:603–649`; `OFF/src/pke/lib/scheme/ckksrns/ckksrns-cryptoparameters.cpp:168–175`; `OFF/src/pke/lib/scheme/ckksrns/ckksrns-leveledshe.cpp:172–189`; paper pp.7–8, Definitions 4.1, 4.3, 4.5, 4.7 and Theorem 4.8.

### Rounding, range, and accuracy claims

`PaperRound` selects the nearest integer with ties toward negative infinity, including negative half-integers. `StableRound` is deliberately more conservative: it requires finite coordinates, `max(1,|primary|)*epsilon160 < 2^-410`, equal rounded integers at both precisions, and a half-integer distance **strictly greater than** `max(16*disagreement, 2^-400)`. Exact halves and the guard boundary are rejected. This matches the approved ambiguity policy; it is neither accidental half-away rounding nor a proof of correct rounding for all transcendental inputs.

Pre-reduction coefficients must satisfy the strict exact bound `2*abs(c) < Q`. Decryption validates residue range and centers at `floor(Q/2)` using integer arithmetic. Both working-precision decodes must agree componentwise within 2^-120 before conversion to owned 100-digit results. Reported headroom examines all 64 centered coefficients; it is not proof that no earlier integer wrap occurred and is not an all-key noise bound.

All 16 input pairs and all 16 frozen complex products were independently parsed from the specification and C++ helper, compared exactly, and recomputed with rational arithmetic. The input delta is `(2^-70, 2^-73)` and the product delta is `(17/2^75, -3/2^74)`. All frozen input/product L1 envelopes are below one. The ≤2^-80 absolute-error and ≤2^-120 numerical-disagreement gates remain unchanged. These are absolute-error gates, not relative-accuracy guarantees on tiny or zero slots.

Anchors: `IO_CPP:371–407,448–501,565–595`; `SPEC:59–113,181–210`; `DESIGN:50–82,325–363`; `TEST:97–148,453–493`; `ORACLE:372–476`; paper p.4, rounding/residue notation.

## 3. API and parameter safety

The constructor validates actual finalized context state: geometry/batch, depth7, scaling50, actual first55, HYBRID/FIXEDMANUAL/COMPLEX, evaluation/fixed-decryption-noise modes, STANDARD/HPS, PRE NOT_SET, noiseScale1, uniform ternary secret distribution, HEStd_NotSet, digit0, max relinearization degree2, fixed-noise multiparty/one party, required features, ordered Q/P/QP/PK bases, three partitions of 3/3/2 towers, and exact PModq relationships. The complete observed feature mask and specified live profile fields are checked on subsequent use. This is the finalized, nonmutating-context contract, not a generic validator for arbitrarily forged or concurrently mutated upstream internals.

The four disabled CKKS setters are not called. Their actual defaults are read and checked. Global `Format` and the backend4 → M4Integer → bigintdyn::BigInteger definitions correspond to the compile-time checks.

Both PK components and the SK's full-Q element are checked before unsafe upstream access. The guard verifies nonnull outer and native Params, declared and stored tower counts, complete ordered modulus/root/geometry identity, evaluation format, populated native value storage, length, and modulus. It does not rely on `DCRTPoly::IsEmpty()` or equality on malformed objects. Context and nonempty tag checks precede dispatch. This closes the actual unchecked `pk[0]`, `pk[1]`, `cv[0]`, secret-Params and prefix-subtraction hazards visible in the official RNS code. It proves structural compatibility, not the secret/public-key RLWE relation.

Encryption calls the public scheme Element overload. Decryption supplies a **named ConstCiphertext lvalue** to the public `Poly*` overload, checks `isValid` before consuming the output, and validates the returned polynomial. The concrete CKKS override retains its configured polynomial-noise branch; the module does not call DecryptCore, copy secret decryption into production, or fall back to ordinary Plaintext/Decode. NativePoly's one-tower-only route is not substituted for the full-Q/prefix operation. The accepted mode is FIXED_NOISE_DECRYPT/COMPLEX; flooding, REAL postprocessing equivalence, and exposure as an evaluator-accessible decryption oracle are not claimed.

Anchors: `IO_CPP:46–53,97–245,448–501,547–595`; `TEST:233–336,497–557`; `OFF/src/pke/include/scheme/ckksrns/gen-cryptocontext-ckksrns-params.h:78–95`; `OFF/src/pke/include/scheme/gen-cryptocontext-params-defaults.h:46–86`; `OFF/src/core/include/utils/inttypes.h:65`; `OFF/src/core/include/math/hal/bigintbackend.h:64–71`; `OFF/src/core/include/math/hal/bigintdyn/backenddyn.h:48–52`; `OFF/src/core/include/math/hal/bigintdyn/ubintdyn.h:74–81,186–195,829–837`; `OFF/src/pke/include/schemebase/base-scheme.h:205–224`; `OFF/src/pke/lib/scheme/ckksrns/ckksrns-scheme.cpp:42–57`; `OFF/src/pke/lib/scheme/ckksrns/ckksrns-pke.cpp:44–95`; `OFF/src/pke/lib/schemerns/rns-pke.cpp:148–223`.

## 4. Ownership and failure ordering

Every BoundCiphertext holds a strong, immutable binding that owns the context/crypto-parameters and value snapshots of ordered Q/P/QP/PK/partition bases, partition counts, and PModq. Clone, bind, and decrypt validate their applicable bindings before raw-ciphertext access, cloning, or cryptographic dispatch. The partition count is checked before the upstream unchecked partition getter. Bind validates both parents and the expected returned state before cloning; it is explicitly a state check, **not operand-lineage authentication**.

Official Clone duplicates ciphertext scalars and coefficient vectors; NativePoly copies its value buffer but shares Params. The present-empty metadata-map rule avoids mutable value aliases. Production therefore correctly promises coefficient/scalar/map isolation, not transitive Params isolation. `State()` returns its cached immutable value and remains noexcept even after shared-basis drift. Owned decoded values do not reference local polynomial buffers.

The B fixture retains original contexts, parameters and evaluation-map entries. Registry-only `ReleaseAllContexts()` enables construction of a genuinely distinct allocation; explicit context/CP/encoding/basis/native-Params checks precede one additional matching keypair and one required evaluation-key generation. All clone/bind/decrypt preparation completes before the sole Q8→7 `PopLastParam()`. It then tests the three exact domain-error rejections and removes only its own evaluation-key tag. Original contexts, key material, caches and receipt values are checked for the promised nonmutation. The public operator== used by this fixture correctly dispatches to protected CompareTo internally; the superseded direct-CompareTo draft is not the executed RED failure.

Anchors: `IO_H:95–109`; `IO_CPP:19–31,218–267,426–446,503–563`; `TEST:387–442,559–722,724–846`; `IMP:127–163`; `OFF/src/pke/include/ciphertext.h:390–405`; `OFF/src/core/include/lattice/hal/default/dcrtpoly.h:74–106`; `OFF/src/core/include/lattice/hal/default/poly.h:133–146`; `OFF/src/core/include/lattice/hal/default/ildcrtparams.h:261–265`; `OFF/src/pke/include/schemerns/rns-cryptoparameters.h:409–421`; `OFF/src/pke/include/cryptocontextfactory.h:66–68`; `OFF/src/pke/lib/cryptocontext.cpp:107–115`; `OFF/src/pke/include/schemebase/base-cryptoparameters.h:115–120`.

## 5. Oracle independence and explicit blind spots

The oracle performs schoolbook negacyclic secret evaluation and explicit CRT, followed by a direct projected Horner calculation. It neither imports the production transform nor calls public decryption for its independent coefficient result. Literal roots/monomials, independent O(S²) interpolation, exact frozen products, and adjacent sub-binary64 witnesses make a matching wrong codec substantially harder to hide than a codec-only roundtrip. Both oracle and public outputs are compared to the intended values, and their componentwise difference is separately gated. All 22 PK and 10 SK malformed cases execute before the final test success.

Two dependencies remain deliberately visible. First, conversion of DCRT towers to coefficient form uses the official inverse NTT; this is not an independently implemented validation of every OpenFHE primitive. Second, both observations intentionally project out odd coefficients and use the bound logical scale. A concrete blind spot is adding a small `a*X` to a decrypted polynomial: projected output does not change, while full canonical evaluation changes by `a*ζ^e_k`; its maximum-coefficient diagnostic can also remain unchanged when an even coefficient dominates. The off-stride control names this difference instead of concealing it. It is not a missing requirement under the approved packed-stride contract and cannot support a full-coefficient correctness claim. The wrong-scale example in §2 shows why the shared scale is separately constrained by known products.

Anchors: `ORACLE:75–272,302–368,372–499`; `TEST:91–148,453–557`; `DESIGN:288–309`; `SPEC:198–210`.

## 6. Genuine chronological evidence

Offline application of the six safe patches, without fuzz, matches every stage's engineering hashes and reproduces all 28 current engineering files. Of 24 base engineering files, 22 are unchanged; only CMake/the tested workflow changed and four I/O files were added. DoubleCKKS and the legacy tests are unchanged. The independent oracle is unchanged from A RED, and B GREEN changes only the I/O header/source.

| Stage | Retained run | Result on each host |
|---|---:|---|
| A RED | 33948543866 | 60 legacy pass bindings; new target fails at the absent public header; new runtime/full58 not run |
| A GREEN | 33950923304 | 119 pass bindings; initial numerical/API tracer passes, but first55 boundary and B ownership closure were not yet established |
| Actual-first-modulus RED | 33952773643 | 60 old passes; new test fails after actual56 setup because the constructor accepts it |
| Actual-first-modulus GREEN | 33953977794 | 119 pass bindings; the smallest actual-first55 guard closes that defect |
| B RED | 33960255214 | 60 old passes; valid isolated fixture reaches drift and first Clone is wrongly accepted; later bind/decrypt rejection and cleanup not run |
| B GREEN | 33961604938 | 119 pass bindings, including all three drift rejections and cleanup; final58/58 |

All six metadata records agree with their engineering SHA, push event, attempt1 and terminal job conclusions. I independently parsed **all 50,700 supplied log lines**, associated 1,078 actual Start/command/result records, checked live CTest names/order/commands against CMake, and distinguished error-output reprints from executions. This is offline analysis of retained runs, not 1,078 newly performed tests or independent randomized trials.

For latest run33961604938, Linux job101294323897 and Windows job101294323767 both have groups `1+2+57+1+58`, all successful. The 238 bindings independently match the supplied root ledger. All 40 reported numerical bound comparisons from the four new-contract invocations pass exact Fraction checks. Maximum observed public product errors across each host's two invocations are:

| Host | Maximum reported public product error | Frozen gate |
|---|---:|---:|
| Linux | 3.33093850266731690491788370766776839447002948e-28 | ≤2^-80 |
| Windows | 5.48082463486344628148918436905618979142753786e-28 | ≤2^-80 |

The log's `result=PASS` numerical line precedes the later boundary assertions; only the ordered end-of-test CTest success establishes the complete contract. Latest source/log anchors are `TEST:812–846`, `EVIDENCE/CYCLE_B_GREEN_LINUX_JOB_01.log:2652–2673,4633–4651`, and `EVIDENCE/CYCLE_B_GREEN_WINDOWS_JOB_01.log:3534–3555,5522–5540`.

Linux's latest dependency configure/build was skipped because of an exact-key pristine cache hit; Windows actually configured, built and installed the dependency. Project builds are warning-clean; MSYS2 setup and runner deprecation messages are not erased or misclassified. The 77-file source packet cannot reproduce a whole upstream build here, and no such build was attempted.

## 7. Final acceptance statement

**Accept the supplied fixed first-operation client-I/O implementation at the stated scope.** `FINDINGS.json` contains an empty findings array. This review does not authorize changes or new experiments. Full-family/repeated/paper-size integration, all-key bounds, universal rounding, complete output-protection equivalence, and lineage authentication remain outside this acceptance rather than being invented defects or new gates.

Own observed arithmetic, archive/delta checks, retained hosted evidence, tool limitations, and explicit NOT RUN items are separated in `CLAIM_LEDGER.md` and `EXECUTION_LEDGER.md`.
