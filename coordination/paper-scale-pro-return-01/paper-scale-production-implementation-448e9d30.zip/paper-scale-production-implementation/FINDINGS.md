# Findings

## Final disposition

**Complete production draft delivered; validation gate remains open.** No unresolved source-proven mathematical blocker was identified in this bounded self-review. That is not a claim that the full implementation compiles, that all old tests pass, or that the encrypted eight-square precision gate passes.

Unresolved inventory: **P0 = 0 identified; P1 = 1 validation/evidence gap; P2 = 0 identified.** These counts are not an independently executed correctness certification.

## P1-V1 — Full production and dual-host cryptographic acceptance NOT RUN

CMake configuration exited 1 at `CMakeLists.txt:9` because neither `OpenFHEConfig.cmake` nor `openfhe-config.cmake` was installed. The final draft therefore has no executed full-source OpenFHE compilation/link evidence, no five-target API build evidence, no 60-test regression result, no live 61-test listing, and no paper encrypted chain or per-round sparse-secret/CRT/Horner evidence on either required host.

This is an evidence gap, not a demonstrated mathematical defect. The standalone GCC numeric extraction is useful evidence for the actual codec definitions, but is not a substitute for compiling the changed translation units or executing OpenFHE. Potential integration/type/toolchain issues, actual sampled-key noise, paper-scale key generation, family-local key switching, live rejection/lifetime behavior, and MinGW stack/runtime behavior remain unverified here.

**Disposition:** retain this draft as unaccepted until the existing prescribed hosted gates run on the integrated exact source. No new statistical, performance-replication, security-certification, second-chain or 1,000-trial obligation is proposed. Do not select replacement keys/inputs or weaken thresholds if the fixed test fails. The user-reported in-progress RED run 33968576607 was not queried, dispatched, rerun or reclassified by this author.

## Corrected during author self-review — not open findings

### C1 — Missing C++ dependent-template disambiguator

The first numeric-only extraction compile failed in generalized `Forward`: an indexed expression involving the templated transform table required `.template convert_to<std::string>()`. Both accesses were corrected in `src/high_precision_client_io.cpp:443-444`. The final unchanged extracted numeric definitions compiled and ran successfully. This local compiler failure is **not** the required hosted API/semantic RED. The initial compiler log and extraction block identities are retained as `evidence/codec_compile_01.log` and `codec_extraction_01.json`.

### C2 — Avoid repeated full-table transcendental construction

The first complete-size author numeric trial, using direct sine/cosine for every root at each precision, exceeded the 200,000-ms container command bound after the full fresh codec check and before a final completion marker. No complete result is claimed for it. The final `TransformTable` at `src/high_precision_client_io.cpp:333-358` uses each precision's own dyadic-angle seeds and balanced products, preserving the same roots/sign convention without promoting primary roots or using binary64. The completed local numeric-only run took approximately 11.14 seconds on this container. This is neither an FHE performance result nor evidence of meeting the hosted test timeout.

### C3 — Author-harness cross-precision measurement corrected

The interrupted draft harness initially converted primary/check outputs separately to binary-512 before subtraction, which rounded away differences smaller than binary-512's mantissa. The final harness subtracts at 220-decimal precision first, then converts the resulting difference for reporting. The final measured maximum is nonzero, approximately 4.33e-165. Production's own cross-precision check already subtracted at check precision and did not have this harness defect. The earlier partial log's zero cross values are not used as final evidence.

### C4 — Live null-basis check before context dimension access

Source inspection of the public upstream mutable Params boundary motivated an explicit Q/P/QP nonnull guard in `src/repeated_mult2.cpp:100-101`, before the context dimension getter. Final profile validation still compares the complete live bases/modes and sealed rows; cached dimensions are not used as authorization. Runtime mutation rejection remains covered only by source reasoning here, not by an executed OpenFHE test.

## Frozen test/API corrections

**None proposed.** No concrete defect was established in the frozen input generator, expected arithmetic, fresh phase checks, independent oracle, numerical gates, public-interface contract, CMake or workflow. None of those files were edited. The new nullptr overload only preserves the old context-constructor call form after adding the required shared-plan overload; it does not add a generic binder or another profile.

The complete h128 adapter module and all official OpenFHE files remain unchanged. No separate h128 or official-library patch is needed by the present draft, and none is supplied.

## Evidence boundaries

The codec harness's ideal final-scale experiment operates on plaintext expected values and rounded coefficients; it has no keys, ciphertexts, NTT, encryption, evaluation or decryption. Its full-packing, Horner, headroom and sub-binary64 checks establish no claim about accumulated encrypted error. Source seals establish supported live-state/normalization checks, not cryptographic operand authentication or immunity to C++ undefined behavior/concurrent global cache mutation. Historic accepted co-build evidence in the input is not reused as a result for this modified source.
