# Execution ledger

## Source and environment

Task source: `448e9d3067796b64656f0746f4be5c4153b1271d`; upstream reference pin: `df495ba2e91739a6dc8f1de254fc5a41155ce504`.

All execution was in the provided Linux container, not the user's Mac or either hosted runner. Observed tools: Linux x86_64, GCC 14.2.0, CMake 3.31.6, Git 2.47.3. No OpenFHE header/package installation was found under `/usr` or `/opt`; `gitleaks` was not found on PATH. `evidence/environment.log` records the probe. No other model/agent, external service, Git remote, hosted CI API, credential store, messaging endpoint or private repository was used.

Working paths used by the author:

```
/mnt/data/paper-scale-production-448e9d30.zip       input ZIP
/mnt/data/paper_task/                             verified original extraction
/mnt/data/paper_work/                             editable exact-source copy
/mnt/data/paper_checks/                           standalone checks and logs
/mnt/data/paper-scale-production-implementation/  deliverable staging directory
```

## Executed checks and actual outcomes

| Check | Actual command / mechanism | Result and precise scope |
|---|---|---|
| Input identity, archive safety and closure | Python zipfile/hashlib/stat inspection; final repeat: `python /mnt/data/paper_checks/verify_input_and_scope.py` | PASS: 1,452,912 bytes; expected SHA256; 132 safe unique regular members; CRC; 131 manifest payload sizes/SHA256; 128 supplied Git blob identities; original extracted bytes match archive. No remote Git history authentication. |
| Changed-path closure | Same verification script comparing all 50 supplied project files | PASS: exactly six allowed files changed; all other 44 files byte-identical. No test, oracle, input generator, CMake, workflow, contract or h128 edits. |
| Production configure | `cmake -S /mnt/data/paper_work -B /mnt/data/paper_checks/cmake_missing_openfhe -DCMAKE_BUILD_TYPE=Release` | **FAILED, exit 1** at required OpenFHE package lookup. CMake identified the compiler but built no production target. `evidence/configure.log`. |
| Initial numeric extraction | `python /mnt/data/paper_checks/extract_codec.py` followed by the GCC command below | First compile **FAILED, exit 1**, due to missing dependent-template keyword. Fixed in production; initial log and extraction hash inventory retained. Not a hosted/API RED. |
| Corrected direct-root numeric compile | Same extraction and GCC command | Exit 0. Subsequent initial numeric trial hit the tool's 200,000-ms timeout without a completion marker. Its partial output is retained as `codec_run_01_timeout.log`; no final exit-zero claim. |
| Final balanced-root numeric extraction/compile | `python /mnt/data/paper_checks/extract_codec.py`; `g++ -std=c++17 -O2 -Wall -Wextra -Werror=vla -fstack-usage /mnt/data/paper_checks/codec_harness.cpp -o /mnt/data/paper_checks/codec_harness` | **PASS, exit 0**. Six actual numeric definition blocks extracted unchanged from current production header/source; hashes/line ranges in `codec_extraction.json`. This does **not** compile any full production/OpenFHE translation unit. |
| Final standalone codec run | `/usr/bin/time -v /mnt/data/paper_checks/codec_harness` | **PASS, exit 0**, completion marker present. Original geometry fresh; paper full packing fresh; paper ideal final rational-scale codec; independent binary-512 Horner anchors; 160/220 check; wrong-normalization falsifier; ambiguity, range, nonwrap/headroom and output-witness checks. Zero encrypted chains. |
| Exact independent parameter/scale checks | `python /mnt/data/paper_checks/analytic_checks.py` | PASS: exact Q/P/root agreement with supplied probe; 12 deterministic 64-bit primality checks and primitive 65536th-root identities; family progression; eight exact recurrence/closed-form equalities; limited source call-scope assertions. No FHE execution. |
| Numeric stack-usage observation | GCC `-fstack-usage` output, summarized in `analytic_checks.log` | Largest reported single frame among extracted codec functions: 1,664 bytes on this GCC build. Heap vectors are present in production. This is not a whole-call-stack bound, full FHE stack analysis or a MinGW/Windows result. |
| Production patch creation/validation | `python /mnt/data/paper_checks/make_and_check_patch.py` with a temporary local Git index | PASS: `git diff --check`; ordinary `git apply --check` and `git apply` from fresh exact project root; all 50 resulting files match working tree; reverse check/apply restores exact original. No local commit or remote operation. Exact child commands in `patch_commands.json`. |
| Output packaging closure | Local SHA256/byte manifest generation; ZIP CRC/path/member closure and re-read of each deliverable | Recorded in `evidence/package_check.json` by the packaging procedure. Manifest excludes only itself. The final outer ZIP bytes/SHA256 are supplied with delivery. |

## Final standalone numeric output

The complete output and process resource report are in `evidence/codec_run.log` and `codec_resources.log`. Selected observed values:

```
legacy fresh max component error       3.3923902130327469673e-30
paper fresh max component error        1.3048302662304672283e-28
paper ideal final max component error   1.1947540738093127134e-28
largest 160/220 disagreement            4.3283507055756566072e-165
wrong nominal100 ideal final error      3.6874340501313190703e-05
ideal final positive centered headroom  588230968407117347342886640736
expected output real delta (slot1-0)    6.9110412050693540436e-22
codec output real delta (slot1-0)       6.9110413967955658633e-22
NUMERIC_CODEC_CHECK=PASS
CODEC_RUN_EXIT=0
```

Process wall time was approximately 11.14 seconds and maximum resident set size 61,284 KiB for this standalone numeric harness. These are observations of the local check, not paper experiment timing or memory claims.

The initial timed-out log is intentionally not discarded. Its cross-precision zeros came from a now-corrected author-harness measurement conversion and are not accepted final evidence. The final comparison subtracts at check precision, matching the production check. None of these edits touched the frozen test/oracle.

A requested interactive streaming session was unavailable (`StreamingExecNotEnabledContainerError`); it supplied no check result. The actual successful run used a normal bounded container command. No task was delegated for future/background delivery.

## Explicit NOT RUN / no-result inventory

- Successful production configure: **NOT ACHIEVED**. Full production compile/link against OpenFHE 1.5.0: **NOT RUN**.
- Existing five explicit API targets (`relin2_api_contract_test`, `rs2_api_contract_test`, `mult2_api_contract_test`, `add_api_contract_test`, `sub_api_contract_test`): **NOT RUN**.
- Existing 60 regression tests and their complete execution bindings: **NOT RUN** for this draft.
- Explicit `paper_full_eight_square_contract_test` build and live 61-test listing: **NOT RUN**.
- Actual production h128 key generation, full-slot Element encryption, DCP, eight chained Mult2 evaluations, terminal RCB/binder and public Poly* decryption: **NOT RUN**.
- Fresh/final/per-round encrypted sparse-secret+CRT+Horner oracles, encrypted <=2^-80 precision and live rejection/cleanup behavior: **NOT RUN**.
- Required GCC/Linux hosted test and MinGW64/Windows hosted test: **NOT RUN**; no Windows compiler/runtime evidence.
- Hosted RED run 33968576607 status/result: **NOT QUERIED OR CLAIMED**. Historic run 33964209898 evidence is input context only, not execution of this draft.
- gitleaks on the output: **NOT RUN** (executable absent). Incoming gitleaks passes were reported by the user, not independently re-executed here.
- No Mac configure/build/FHE execution, network push/merge, CI dispatch/rerun, external messaging, credential access, official OpenFHE edit, h128 module edit, expected-failure GREEN, threshold change, key-selection retry, statistical trial expansion, or second encrypted chain was performed.

## Reproducing the numeric-only check from this delivery

The harness deliberately has no OpenFHE includes or API stubs. From this package directory, using GCC and Boost headers:

```sh
python evidence/extract_codec.py production evidence
g++ -std=c++17 -O2 -Wall -Wextra -Werror=vla -fstack-usage \
    evidence/codec_harness.cpp -o /tmp/paper_codec_check
/tmp/paper_codec_check
```

This tests only the extracted numeric codec. The required production acceptance remains the unchanged hosted sequence after the first RED has been retained; this ledger does not replace it.
