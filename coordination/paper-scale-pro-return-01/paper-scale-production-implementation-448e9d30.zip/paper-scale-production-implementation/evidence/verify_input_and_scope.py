#!/usr/bin/env python3
"""Recheck archive identities and final working-tree scope without executing payloads."""
from pathlib import Path, PurePosixPath
from hashlib import sha256, sha1
import json, stat, zipfile, sys
archive=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/mnt/data/paper-scale-production-448e9d30.zip')
original=Path(sys.argv[2]) if len(sys.argv)>2 else Path('/mnt/data/paper_task')
work=Path(sys.argv[3]) if len(sys.argv)>3 else Path('/mnt/data/paper_work')
expected_source='448e9d3067796b64656f0746f4be5c4153b1271d'
expected_sha='afd8d383aabcd5c043961688e021b08625d94e19e3bd8d5d8393365b9f7e892f'
assert archive.stat().st_size==1452912
assert sha256(archive.read_bytes()).hexdigest()==expected_sha
with zipfile.ZipFile(archive) as z:
    entries=z.infolist(); names=[i.filename for i in entries]
    assert len(names)==len(set(names))==len(set(n.casefold() for n in names))
    for i in entries:
        p=PurePosixPath(i.filename); mode=(i.external_attr>>16)&0xffff
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename
        assert not i.is_dir() and stat.S_ISREG(mode) and not (i.flag_bits&1)
        assert all(':' not in part for part in p.parts)
    assert z.testzip() is None
    m=json.loads(z.read('MANIFEST.json'))
    assert m['source']==expected_source and m['manifest_self_excluded'] is True
    assert len(m['files'])==131
    payloads={e['path'] for e in m['files']}
    assert len(payloads)==131 and set(names)==payloads|{'MANIFEST.json'}
    blobs=0
    for e in m['files']:
        data=z.read(e['path'])
        assert len(data)==e['bytes'] and sha256(data).hexdigest()==e['sha256'],e['path']
        assert (original/e['path']).read_bytes()==data,e['path']
        origin=e.get('origin',{})
        if origin.get('blob'):
            assert sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==origin['blob'], e['path']
            blobs+=1
    print(f'ZIP_IDENTITY=PASS bytes={archive.stat().st_size} sha256={expected_sha}')
    print(f'ZIP_PATH_MODE_DUPLICATE_CASEFOLD_CRC_CLOSURE=PASS regular_files={len(entries)} payloads={len(payloads)} uncompressed_bytes={sum(i.file_size for i in entries)}')
    print(f'MANIFEST_BYTES_SHA256=PASS count={len(payloads)} ORIGINAL_EXTRACTION_MATCH=PASS git_blob_hashes={blobs}')
base=original/'project'
basepaths={p.relative_to(base).as_posix() for p in base.rglob('*') if p.is_file()}
workpaths={p.relative_to(work).as_posix() for p in work.rglob('*') if p.is_file()}
assert basepaths==workpaths
changed=sorted(p for p in basepaths if (base/p).read_bytes()!=(work/p).read_bytes())
allowed=sorted([f'include/openfhe_2023_1788/{n}.h' for n in ['double_ckks','repeated_mult2','high_precision_client_io']]+[f'src/{n}.cpp' for n in ['double_ckks','repeated_mult2','high_precision_client_io']])
assert changed==allowed
print('PRODUCTION_ONLY_SCOPE=PASS exact_changed_paths='+json.dumps(changed))
print('ALL_OTHER_PROJECT_FILES_BYTE_IDENTICAL=PASS count='+str(len(basepaths)-len(changed)))
print('TESTS_ORACLES_CMAKE_WORKFLOW_H128_MODULE_UNCHANGED=PASS')
