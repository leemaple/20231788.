// Extracted unchanged numeric definitions only. NO OpenFHE code or API stubs.
#include <boost/multiprecision/cpp_dec_float.hpp>
#include <boost/multiprecision/cpp_int.hpp>
#include <boost/math/constants/constants.hpp>
#include <boost/math/special_functions/fpclassify.hpp>
#include <algorithm>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>
namespace codec {
using ClientReal = boost::multiprecision::number<boost::multiprecision::cpp_dec_float<100>>;
using ExactInteger = boost::multiprecision::cpp_int;

struct ClientComplex final {
    ClientReal real;
    ClientReal imag;
};

class PositiveRationalScale final {
public:
    static PositiveRationalScale FromPositive(ExactInteger numerator, ExactInteger denominator);
    const ExactInteger& Numerator() const noexcept;
    const ExactInteger& Denominator() const noexcept;

private:
    PositiveRationalScale(ExactInteger numerator, ExactInteger denominator);
    ExactInteger numerator_;
    ExactInteger denominator_;
};


struct ClientGeometry final {
    std::uint32_t slots, n, m, gap;
};


using Geometry = ClientGeometry;

template <unsigned Digits>
using WorkReal = boost::multiprecision::number<boost::multiprecision::cpp_dec_float<Digits>>;
using Primary = WorkReal<160>;
using CheckReal = WorkReal<220>;


void Require(bool condition, const char* message) {
    if (!condition) throw std::domain_error(std::string("HighPrecisionClientIO: ") + message);
}

template <class Real>
void RequireFinite(const Real& value) {
    if (!boost::math::isfinite(value))
        throw std::range_error("HighPrecisionClientIO: nonfinite numerical value");
}

template <class Real>
Real Absolute(const Real& value) {
    return value < 0 ? Real(-value) : value;
}

template <class Real>
Real NegativePowerOfTwo(unsigned bits) {
    Real value = 1;
    for (unsigned bit = 0; bit < bits; ++bit) value /= 2;
    return value;
}

ExactInteger Gcd(ExactInteger left, ExactInteger right) {
    while (right != 0) {
        ExactInteger remainder = left % right;
        left = std::move(right);
        right = std::move(remainder);
    }
    return left;
}


template <class Real>
struct Complex final { Real real; Real imag; };

template <class Real>
Complex<Real> Add(const Complex<Real>& left, const Complex<Real>& right) {
    return {left.real + right.real, left.imag + right.imag};
}

template <class Real>
Complex<Real> Subtract(const Complex<Real>& left, const Complex<Real>& right) {
    return {left.real - right.real, left.imag - right.imag};
}

template <class Real>
Complex<Real> Multiply(const Complex<Real>& left, const Complex<Real>& right) {
    return {left.real * right.real - left.imag * right.imag, left.real * right.imag + left.imag * right.real};
}

// Independently generated immutable roots at EACH working precision. No
// OpenFHE binary64 root/cache data and no test oracle enters this module.
// Butterfly/order source: official dftransform.cpp:50-69,209-268 at df495ba.
template <class Real>
struct TransformTable final {
    const Geometry geometry;
    std::vector<std::uint32_t> powersOfFive;
    std::vector<Complex<Real>> roots;

    explicit TransformTable(Geometry dimensions)
        : geometry(dimensions), powersOfFive(dimensions.slots), roots(dimensions.m + 1) {
        std::uint32_t power = 1;
        for (auto& exponent : powersOfFive) { exponent = power; power = (5 * power) % geometry.m; }
        const Real pi = boost::math::constants::pi<Real>();
        roots[0] = {Real(1), Real(0)};
        // Generate each precision's own dyadic-angle seeds. Balanced products
        // need at most log2(M) factors per root, not an M-step accumulated
        // recurrence or M transcendental calls. No binary64 roots are reused.
        for (std::uint32_t span = 1; span < geometry.m; span *= 2) {
            const Real angle = Real(2) * pi * Real(span) / Real(geometry.m);
            const Complex<Real> step{boost::multiprecision::cos(angle), boost::multiprecision::sin(angle)};
            RequireFinite(step.real); RequireFinite(step.imag);
            for (std::uint32_t index = 0; index < span; ++index) {
                roots[index + span] = Multiply(roots[index], step);
                RequireFinite(roots[index + span].real); RequireFinite(roots[index + span].imag);
            }
        }
        roots[geometry.m] = roots[0];
    }
};

template <class Real>
void BitReverse(std::vector<Complex<Real>>& values) {
    for (std::size_t index = 1, reversed = 0; index < values.size(); ++index) {
        std::size_t bit = values.size() / 2;
        while ((reversed & bit) != 0) { reversed ^= bit; bit >>= 1; }
        reversed ^= bit;
        if (index < reversed) std::swap(values[index], values[reversed]);
    }
}

template <class Real>
void Transform(std::vector<Complex<Real>>& values, const TransformTable<Real>& table, bool inverse) {
    const std::size_t slots = table.geometry.slots;
    Require(values.size() == slots, "transform geometry mismatch");
    if (!inverse) BitReverse(values);
    for (std::size_t length = inverse ? slots : 2; length >= 2 && length <= slots;
         length = inverse ? length / 2 : length * 2) {
        const std::size_t half = length / 2, quarter = length * 4, gap = table.geometry.m / quarter;
        for (std::size_t offset = 0; offset < slots; offset += length) {
            for (std::size_t index = 0; index < half; ++index) {
                const auto left = values[offset + index], right = values[offset + index + half];
                const auto exponent = table.powersOfFive[index] % quarter;
                if (inverse) {
                    values[offset + index] = Add(left, right);
                    values[offset + index + half] = Multiply(Subtract(left, right), table.roots[(quarter - exponent) * gap]);
                }
                else {
                    const auto rotated = Multiply(right, table.roots[exponent * gap]);
                    values[offset + index] = Add(left, rotated);
                    values[offset + index + half] = Subtract(left, rotated);
                }
                RequireFinite(values[offset + index].real); RequireFinite(values[offset + index].imag);
                RequireFinite(values[offset + index + half].real); RequireFinite(values[offset + index + half].imag);
            }
        }
    }
    if (inverse) {
        BitReverse(values);
        for (auto& value : values) { value.real /= Real(slots); value.imag /= Real(slots); }
    }
}

template <class Real>
std::vector<Complex<Real>> Inverse(const std::vector<ClientComplex>& values,
                                         const TransformTable<Real>& table) {
    Require(values.size() == table.geometry.slots, "inverse input size mismatch");
    std::vector<Complex<Real>> result(table.geometry.slots);
    for (std::size_t slot = 0; slot < result.size(); ++slot) result[slot] = {Real(values[slot].real), Real(values[slot].imag)};
    Transform(result, table, true);
    return result;
}

template <class Real>
ExactInteger PaperRound(const Real& value) {
    const Real floor = boost::multiprecision::floor(value);
    // Paper notation: nearest integer, downward at an exact half-integer.
    const Real rounded = value - floor <= Real("0.5") ? floor : Real(floor + 1);
    return rounded.template convert_to<ExactInteger>();
}

ExactInteger StableRound(const Primary& primary, const CheckReal& check) {
    RequireFinite(primary); RequireFinite(check);
    const Primary unit = std::max(Primary(1), Absolute(primary)) * std::numeric_limits<Primary>::epsilon();
    if (!(unit < NegativePowerOfTwo<Primary>(410)))
        throw std::range_error("HighPrecisionClientIO: encoding supported range exceeded");
    const CheckReal disagreement = Absolute(CheckReal(check - CheckReal(primary)));
    const CheckReal fraction = check - boost::multiprecision::floor(check);
    const CheckReal halfDistance = Absolute(CheckReal(fraction - CheckReal("0.5")));
    const CheckReal margin = std::max(CheckReal(16 * disagreement), NegativePowerOfTwo<CheckReal>(400));
    const ExactInteger primaryInteger = PaperRound(primary), checkInteger = PaperRound(check);
    if (!(halfDistance > margin) || primaryInteger != checkInteger)
        throw std::range_error("HighPrecisionClientIO: ambiguous encoding precision");
    return checkInteger;
}

template <class Real>
std::vector<Complex<Real>> Forward(const std::vector<ExactInteger>& coefficients,
                                         const PositiveRationalScale& scale, const TransformTable<Real>& table) {
    const Real normalization = Real(scale.Denominator().convert_to<std::string>()) /
                               Real(scale.Numerator().convert_to<std::string>());
    Require(coefficients.size() == table.geometry.n, "forward coefficient size mismatch");
    std::vector<Complex<Real>> result(table.geometry.slots);
    for (std::size_t slot = 0; slot < result.size(); ++slot) {
        result[slot] = {Real(coefficients[table.geometry.gap * slot].template convert_to<std::string>()) * normalization,
                        Real(coefficients[table.geometry.gap * slot + table.geometry.n / 2].template convert_to<std::string>()) * normalization};
        RequireFinite(result[slot].real); RequireFinite(result[slot].imag);
    }
    Transform(result, table, false);
    return result;
}


PositiveRationalScale::PositiveRationalScale(ExactInteger numerator, ExactInteger denominator)
    : numerator_(std::move(numerator)), denominator_(std::move(denominator)) {}

PositiveRationalScale PositiveRationalScale::FromPositive(ExactInteger numerator, ExactInteger denominator) {
    if (numerator <= 0 || denominator <= 0)
        throw std::invalid_argument("PositiveRationalScale: numerator and denominator must be positive");
    const auto divisor = Gcd(numerator, denominator);
    numerator /= divisor;
    denominator /= divisor;
    return PositiveRationalScale(std::move(numerator), std::move(denominator));
}

const ExactInteger& PositiveRationalScale::Numerator() const noexcept { return numerator_; }
const ExactInteger& PositiveRationalScale::Denominator() const noexcept { return denominator_; }


} // namespace codec
