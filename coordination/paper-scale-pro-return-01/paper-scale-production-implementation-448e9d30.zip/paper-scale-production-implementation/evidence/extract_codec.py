#!/usr/bin/env python3
"""Extract actual production numeric definitions; never model OpenFHE APIs.
The standalone harness compiles only the codec, not a production/FHE TU.
"""
from pathlib import Path
import hashlib, json, sys
root = Path(sys.argv[1]) if len(sys.argv)>1 else Path('/mnt/data/paper_work')
out = Path(sys.argv[2]) if len(sys.argv)>2 else Path('/mnt/data/paper_checks')
src = root/'src/high_precision_client_io.cpp'
hdr = root/'include/openfhe_2023_1788/high_precision_client_io.h'
s, h = src.read_text(), hdr.read_text()
records=[]
def extract(text,start,end,path):
    a=text.index(start); b=text.index(end,a)
    block=text[a:b]
    records.append({'source':str(path.relative_to(root)), 'first_line':text[:a].count('\n')+1,
                    'last_line':text[:b].count('\n'), 'bytes':len(block.encode()),
                    'sha256':hashlib.sha256(block.encode()).hexdigest()})
    return block
parts=[extract(h,'using ClientReal =','enum class CanonicalProjection',hdr),
       extract(s,'struct ClientGeometry final {','// Opaque, immutable',src),
       'using Geometry = ClientGeometry;\n',
       extract(s,'template <unsigned Digits>','constexpr std::size_t kSlots',src),
       extract(s,'void Require(bool condition','ExactInteger CompositeModulus',src),
       extract(s,'template <class Real>\nstruct Complex final','}  // namespace\n\nvoid detail::',src),
       extract(s,'PositiveRationalScale::PositiveRationalScale','BoundCiphertext::BoundCiphertext',src)]
pre='''// Extracted unchanged numeric definitions only. NO OpenFHE code or API stubs.
#include <boost/multiprecision/cpp_dec_float.hpp>
#include <boost/multiprecision/cpp_int.hpp>
#include <boost/math/constants/constants.hpp>
#include <boost/math/special_functions/fpclassify.hpp>
#include <algorithm>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>
namespace codec {
'''
(out/'extracted_codec.hpp').write_text(pre+'\n'.join(parts)+'\n} // namespace codec\n')
(out/'codec_extraction.json').write_text(json.dumps({'production_file_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),
    'numeric_blocks':records,'scope':'numeric-only, not a production/OpenFHE build'},indent=2)+'\n')
print('Extracted',len(records),'unchanged numeric source blocks.')
