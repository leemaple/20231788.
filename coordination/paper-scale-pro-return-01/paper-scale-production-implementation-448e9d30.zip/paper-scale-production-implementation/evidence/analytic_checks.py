#!/usr/bin/env python3
"""Independent exact-integer, identity and scope checks; no FHE or network."""
from pathlib import Path
from fractions import Fraction
from decimal import Decimal, localcontext
import re, math, json, sys
source=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/mnt/data/paper_work')
packet=Path(sys.argv[2]) if len(sys.argv)>2 else Path('/mnt/data/paper_task')
s=(source/'src/repeated_mult2.cpp').read_text()
block=s.split('kPaperQ{{',1)[1].split('}};',1)[0]
q=[tuple(map(int,v)) for v in re.findall(r'\{(\d+)ULL,(\d+)ULL\}',block)]
probe=(packet/'historical-probe/table3_profile_probe.cpp').read_text()
probeq=[(int(a),int(b)) for _,a,b in re.findall(r'\{"(Base\d|Mult\d|Div)",\s*(\d+)ULL,\s*(\d+)ULL\}',probe)]
assert len(q)==11 and q==probeq
p=tuple(map(int,re.search(r'kPaperP\{(\d+)ULL,(\d+)ULL\}',s).groups()))
assert p==(1152921504606584833,4443670208963)
assert len({a for a,b in q+[p]})==12
# Deterministic Miller-Rabin basis set for unsigned integers below 2^64.
def prime64(n):
    if n<2: return False
    for a in (2,3,5,7,11,13,17,19,23,29,31,37):
        if n%a==0: return n==a
    d=n-1; twos=0
    while d%2==0: d//=2; twos+=1
    for a in (2,325,9375,28178,450775,9780504,1795265022):
        if a%n==0: continue
        x=pow(a,d,n)
        if x in (1,n-1): continue
        for _ in range(twos-1):
            x=x*x%n
            if x==n-1: break
        else: return False
    return True
for modulus,root in q+[p]:
    assert prime64(modulus) and (modulus-1)%65536==0 and 0<root<modulus
    assert pow(root,32768,modulus)==modulus-1 and pow(root,65536,modulus)==1
assert [v.bit_length() for v,r in q]==[50,50]+[60]*8+[40]
assert p[0].bit_length()==60
print('FROZEN_Q_P_ROOT_SEQUENCE=PASS full_q=11 reserved_p=1')
print('PRIMALITY_NTT_CONGRUENCE_EXACT_ORDER=PASS count=12 phi=65536')
families=[]; remaining=q[:]
for family in range(8):
    families.append(remaining[:]); assert len(remaining)==11-family and remaining[-1]==q[-1]
    del remaining[-2]
assert remaining==q[:2]+[q[-1]]
for f in range(7):
    assert families[f][:-2]==families[f+1][:-1]
assert families[-1][:-2]==q[:2]
print('FAMILY_PROGRESSION=PASS full_counts=11,10,9,8,7,6,5,4 terminal_active=2 absolute_level=9')
s0=1<<100; d=q[-1][0]; scale=Fraction(s0,1); records=[]
for r in range(1,9):
    m=q[10-r][0]
    tensor=scale*scale/d; scale=tensor/m
    # Closed form independent of the iterative denominator update.
    closedDen=d**((1<<r)-1)
    for j in range(1,r+1): closedDen*=q[10-j][0]**(1<<(r-j))
    assert scale==Fraction(s0**(1<<r),closedDen)
    assert (Fraction(1<<100)**2/Fraction(1<<50))/Fraction(1<<50)==1<<100
    with localcontext() as ctx:
        ctx.prec=90
        ratio=Decimal(scale.numerator)/Decimal(scale.denominator)/Decimal(s0)
        records.append({'round':r,'consumed_mult_role':f'Mult{8-r}','consumed_modulus':m,
            'numerator_bits':scale.numerator.bit_length(),'denominator_bits':scale.denominator.bit_length(),
            'Si_over_2_to_100':str(ratio)})
print('EXACT_SCALE_RECURRENCE_VS_CLOSED_FORM=PASS rounds=8 metadata=100->150->100')
print('EXACT_SCALE_OBSERVATIONS='+json.dumps(records))
assert scale>Fraction(s0)*Fraction(10003,10000) and scale<Fraction(s0)*Fraction(10004,10000)
# Lexical scope assertions do not claim C++ compilation or control-flow proof.
factory=s.split('RepeatedMult2ClientSetup CreatePaperRepeatedMult2Setup() {',1)[1].split('// ---------------- END CLIENT SETUP BOUNDARY',1)[0]
assert factory.count('CreateFixedQH128ClientKeyPair(')==1 and '->KeyGen(' not in factory
assert 'keys=data_->' not in s
for path in ('src/double_ckks.cpp','include/openfhe_2023_1788/double_ckks.h'):
    text=(source/path).read_text()
    uncommented=re.sub(r'/\*.*?\*/|//[^\n]*','',text,flags=re.S)
    assert not re.search(r'\b(?:PrivateKey|DecryptCore)\b|->(?:Encrypt|Decrypt|KeyGen|EvalBootstrap)\s*\(',uncommented)
print('SOURCE_CALL_SCOPE=PASS one_h128_adapter_call_in_paper_factory no_evaluator_secret_decrypt_encrypt_keygen_bootstrap_calls')
# Current numeric-only frame reports, not a Windows or whole-program stack proof.
su=Path('/mnt/data/paper_checks/codec_harness.su')
if su.exists():
    rows=[]
    for line in su.read_text().splitlines():
        v=line.rsplit('\t',2)
        if len(v)==3 and v[1].isdigit() and 'extracted_codec.hpp' in v[0]: rows.append((int(v[1]),v[0],v[2]))
    print('GCC_EXTRACTED_CODEC_REPORTED_MAX_SINGLE_FRAME_BYTES='+str(max(v[0] for v in rows)))
    print('STACK_SCOPE=standalone_GCC_numeric_functions_only; no_MinGW_or_FHE_stack_claim')
print('ANALYTIC_CHECK=PASS')
