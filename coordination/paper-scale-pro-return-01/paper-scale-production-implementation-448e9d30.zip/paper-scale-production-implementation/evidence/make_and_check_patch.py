#!/usr/bin/env python3
"""Use a temporary local index to produce repository-root git-apply paths.
No commit, remote, credentials, network or user's repository are used.
"""
from pathlib import Path
from hashlib import sha256
import subprocess, shutil, os, json
base=Path('/mnt/data/paper_task/project'); work=Path('/mnt/data/paper_work')
package=Path('/mnt/data/paper-scale-production-implementation')
index=Path('/mnt/data/paper_checks/local_index'); applied=Path('/mnt/data/paper_checks/apply_exact_snapshot')
assert not index.exists() and not applied.exists(), 'scratch dirs already exist'
package.mkdir(exist_ok=True)
shutil.copytree(base,index); shutil.copytree(base,applied)
env=dict(os.environ,GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_SYSTEM='/dev/null')
log=[]
def run(args,cwd):
    result=subprocess.run(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    log.append({'command':args,'cwd':str(cwd),'exit':result.returncode,
                'stdout':result.stdout.decode(),'stderr':result.stderr.decode()})
    assert result.returncode==0,log[-1]
    return result.stdout
changed=sorted(p.relative_to(work).as_posix() for p in work.rglob('*') if p.is_file() and p.read_bytes()!=(base/p.relative_to(work)).read_bytes())
assert len(changed)==6
run(['git','init','-q'],index)
run(['git','add','--']+changed,index)
for rel in changed:
    shutil.copy2(work/rel,index/rel)
    out=package/'production'/rel; out.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(work/rel,out)
run(['git','diff','--check'],index)
patch=run(['git','diff','--binary','--full-index','--no-ext-diff'],index)
patchpath=package/'IMPLEMENTATION.patch'; patchpath.write_bytes(patch)
assert b'a/project/' not in patch and b'b/project/' not in patch
run(['git','apply','--check',str(patchpath)],applied)
run(['git','apply',str(patchpath)],applied)
for original in work.rglob('*'):
    if original.is_file():
        assert (applied/original.relative_to(work)).read_bytes()==original.read_bytes(),original
run(['git','apply','--reverse','--check',str(patchpath)],applied)
run(['git','apply','--reverse',str(patchpath)],applied)
for original in base.rglob('*'):
    if original.is_file():
        assert (applied/original.relative_to(base)).read_bytes()==original.read_bytes(),original
print('PATCH_PRODUCTION_PATHS=PASS count=6 no_project_prefix=true')
print('GIT_DIFF_WHITESPACE=PASS')
print('GIT_APPLY_CHECK_AND_APPLY_ON_EXACT_SOURCE=PASS all_50_project_files_match_working_copy')
print('GIT_REVERSE_CHECK_AND_REVERSE=PASS exact_original_restored')
print('PATCH_BYTES='+str(len(patch))+' PATCH_SHA256='+sha256(patch).hexdigest())
print(run(['git','diff','--stat'],index).decode())
Path('/mnt/data/paper_checks/patch_commands.json').write_text(json.dumps(log,indent=2)+'\n')
