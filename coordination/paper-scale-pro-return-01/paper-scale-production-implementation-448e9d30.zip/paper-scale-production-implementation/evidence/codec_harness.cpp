// Independent non-cryptographic arithmetic check. Never includes OpenFHE,
// never invokes or emulates encryption/evaluation/decryption/NTT/keygen.
#include "extracted_codec.hpp"
#include <boost/multiprecision/cpp_bin_float.hpp>
#include <chrono>
#include <iostream>
#include <iomanip>
#include <array>
#include <type_traits>

using Bin=boost::multiprecision::number<boost::multiprecision::cpp_bin_float<512,boost::multiprecision::digit_base_2>>;
struct BC { Bin re,im; };
Bin absb(const Bin& x) { return x<0?-x:x; }
void demand(bool p,const char* reason) { if(!p) throw std::runtime_error(reason); }
BC square(const BC& v) { return {v.re*v.re-v.im*v.im,2*v.re*v.im}; }
BC input(std::size_t slot) {
    const std::size_t t=slot/2;
    Bin a=Bin(1015)/1024-Bin(t%16)/65536+Bin(slot)*boost::multiprecision::ldexp(Bin(1),-75);
    Bin b=Bin(1+(t/16)%8)/1024;
    if((t/512)%2) b=-b;
    switch((t/128)%4) { case 0:return {a,b}; case 1:return {-b,a}; case 2:return {-a,-b}; default:return {b,-a}; }
}
codec::PositiveRationalScale scale8() {
    const std::array<std::uint64_t,8> m={{1152921504589938689ULL,1152921504592429057ULL,
        1152921504592822273ULL,1152921504593412097ULL,1152921504595640321ULL,
        1152921504595968001ULL,1152921504597016577ULL,1152921504598720513ULL}};
    auto scale=codec::PositiveRationalScale::FromPositive(codec::ExactInteger(1)<<100,1);
    for(auto prime:m) scale=codec::PositiveRationalScale::FromPositive(scale.Numerator()*scale.Numerator(),
        scale.Denominator()*scale.Denominator()*codec::ExactInteger(1099510054913ULL)*prime);
    return scale;
}
BC horner(const std::vector<codec::ExactInteger>& coeffs,std::size_t slot,const codec::PositiveRationalScale& scale,
          const codec::Geometry& geom) {
    std::uint32_t e=1; for(std::size_t i=0;i<slot;++i) e=(e*5)%geom.m;
    const Bin angle=Bin(2)*boost::math::constants::pi<Bin>()*e/geom.m;
    const Bin wr=cos(angle), wi=sin(angle);
    Bin re=0,im=0;
    for(std::size_t i=coeffs.size();i-- > 0;) {
        const Bin nextRe=re*wr-im*wi+Bin(coeffs[i].convert_to<std::string>());
        im=re*wi+im*wr; re=nextRe;
    }
    const Bin normalization=Bin(scale.Denominator().convert_to<std::string>())/Bin(scale.Numerator().convert_to<std::string>());
    return {re*normalization,im*normalization};
}
void check_case(const char* name,const codec::Geometry& geom,
                const codec::TransformTable<codec::Primary>& primaryTable,
                const codec::TransformTable<codec::CheckReal>& checkTable,
                bool finalScale) {
    std::cout<<name<<" starting\n";
    std::vector<BC> expected(geom.slots);
    std::vector<codec::ClientComplex> values(geom.slots);
    for(std::size_t s=0;s<geom.slots;++s) {
        expected[s]=input(s);
        if(finalScale) for(unsigned r=0;r<8;++r) expected[s]=square(expected[s]);
        values[s]={codec::ClientReal(expected[s].re),codec::ClientReal(expected[s].im)};
    }
    const auto scale=finalScale?scale8():codec::PositiveRationalScale::FromPositive(codec::ExactInteger(1)<<100,1);
    const auto primary=codec::Inverse(values,primaryTable);
    const auto check=codec::Inverse(values,checkTable);
    const codec::Primary sp=codec::Primary(scale.Numerator().convert_to<std::string>())/
                            codec::Primary(scale.Denominator().convert_to<std::string>());
    const codec::CheckReal sc=codec::CheckReal(scale.Numerator().convert_to<std::string>())/
                              codec::CheckReal(scale.Denominator().convert_to<std::string>());
    std::vector<codec::ExactInteger> coeffs(geom.n);
    codec::ExactInteger maxCoefficient=0;
    for(std::size_t s=0;s<geom.slots;++s) {
        coeffs[geom.gap*s]=codec::StableRound(codec::Primary(primary[s].real*sp),codec::CheckReal(check[s].real*sc));
        coeffs[geom.gap*s+geom.n/2]=codec::StableRound(codec::Primary(primary[s].imag*sp),codec::CheckReal(check[s].imag*sc));
    }
    for(const auto& c:coeffs) maxCoefficient=std::max(maxCoefficient,codec::Absolute(c));
    const auto gotPrimary=codec::Forward(coeffs,scale,primaryTable);
    const auto gotCheck=codec::Forward(coeffs,scale,checkTable);
    Bin maxError=0,maxCross=0,maxHorner=0,maxAgainstHorner=0;
    const Bin correct=boost::multiprecision::ldexp(Bin(1),-80), cross=boost::multiprecision::ldexp(Bin(1),-120);
    for(std::size_t s=0;s<geom.slots;++s) {
        maxError=std::max(maxError,std::max(absb(Bin(gotCheck[s].real)-expected[s].re),absb(Bin(gotCheck[s].imag)-expected[s].im)));
        const codec::CheckReal crossRe=gotCheck[s].real-codec::CheckReal(gotPrimary[s].real);
        const codec::CheckReal crossIm=gotCheck[s].imag-codec::CheckReal(gotPrimary[s].imag);
        maxCross=std::max(maxCross,std::max(absb(Bin(crossRe)),absb(Bin(crossIm))));
    }
    const std::vector<std::size_t> anchors=geom.slots==16?std::vector<std::size_t>{0,1,3,7,15}:
        std::vector<std::size_t>{0,1,256,257,512,513,768,769,1023,16383};
    for(auto s:anchors) {
        const auto v=horner(coeffs,s,scale,geom);
        maxHorner=std::max(maxHorner,std::max(absb(v.re-expected[s].re),absb(v.im-expected[s].im)));
        maxAgainstHorner=std::max(maxAgainstHorner,std::max(absb(v.re-Bin(gotCheck[s].real)),absb(v.im-Bin(gotCheck[s].imag))));
    }
    demand(maxError<=correct,"componentwise codec round trip failed");
    demand(maxCross<=cross,"160/220 codec comparison failed");
    demand(maxHorner<=correct && maxAgainstHorner<=cross,"independent binary512 direct Horner failed");
    std::cout<<name<<" slots="<<geom.slots<<" max_error="<<maxError<<" max_cross="<<maxCross
        <<" horner_expected="<<maxHorner<<" horner_vs_transform="<<maxAgainstHorner<<" max_abs_coefficient="<<maxCoefficient<<'\n';
    if(finalScale) {
        const codec::ExactInteger q=codec::ExactInteger(1125899904679937ULL)*1125899903827969ULL;
        demand(2*maxCoefficient<q,"ideal terminal codec wrap");
        auto wrong=codec::Forward(coeffs,codec::PositiveRationalScale::FromPositive(codec::ExactInteger(1)<<100,1),checkTable);
        const Bin error=std::max(absb(Bin(wrong[0].real)-expected[0].re),absb(Bin(wrong[0].imag)-expected[0].im));
        demand(error>boost::multiprecision::ldexp(Bin(1),-30),"wrong nominal normalization not falsified");
        const Bin witness=Bin(gotCheck[1].real)-Bin(gotCheck[0].real);
        const Bin exactWitness=expected[1].re-expected[0].re;
        demand(absb(witness-exactWitness)<=2*correct,"sub-binary64 output witness lost");
        demand(exactWitness>boost::multiprecision::ldexp(Bin(1),-71) && exactWitness<boost::multiprecision::ldexp(Bin(1),-70),"frozen witness domain mismatch");
        std::cout<<name<<" wrong_nominal_error="<<error<<" ideal_headroom="<<(q/2-maxCoefficient)
            <<" witness="<<witness<<" expected_witness="<<exactWitness<<'\n';
    }
}
int main() {
    std::cout<<std::scientific<<std::setprecision(36)<<std::unitbuf;
    std::cout<<"SCOPE=numeric-codec-only NO_OPENFHE NO_KEYS NO_CIPHERTEXT NO_CRYPTOGRAPHIC_CHAIN\n";
    const auto begin=std::chrono::steady_clock::now();
    { const codec::Geometry g{16,64,128,2};
      const codec::TransformTable<codec::Primary> p(g); const codec::TransformTable<codec::CheckReal> c(g);
      check_case("legacy_fresh_codec",g,p,c,false); }
    { const codec::Geometry g{16384,32768,65536,1};
      const codec::TransformTable<codec::Primary> p(g); const codec::TransformTable<codec::CheckReal> c(g);
      std::cout<<"paper_independent_root_tables_complete\n";
      check_case("paper_fresh_codec",g,p,c,false);
      check_case("paper_ideal_final_scale_codec",g,p,c,true); }
    bool ambiguous=false;
    try { (void)codec::StableRound(codec::Primary("0.5"),codec::CheckReal("0.5")); }
    catch(const std::range_error& e) { ambiguous=std::string(e.what())=="HighPrecisionClientIO: ambiguous encoding precision"; }
    demand(ambiguous,"exact half-integer guard failed");
    demand(codec::PaperRound(codec::Primary("-0.5"))==-1 && codec::PaperRound(codec::Primary("0.5"))==0,
           "downward half-integer round definition failed");
    bool range=false;
    try { (void)codec::StableRound(codec::Primary("1e60"),codec::CheckReal("1e60")); }
    catch(const std::range_error& e) { range=std::string(e.what())=="HighPrecisionClientIO: encoding supported range exceeded"; }
    demand(range,"supported-range guard failed");
    std::cout<<"ambiguity_range_rounding_checks=PASS\nNUMERIC_CODEC_CHECK=PASS elapsed_seconds="
        <<std::chrono::duration<double>(std::chrono::steady_clock::now()-begin).count()<<'\n';
}
