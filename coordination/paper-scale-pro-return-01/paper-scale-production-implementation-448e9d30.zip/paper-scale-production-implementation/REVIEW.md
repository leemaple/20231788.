# Paper-scale eight-square production draft: source review

## Disposition and source identity

**Complete bounded implementation draft; hosted production acceptance is NOT established.** The six permitted production files are supplied in full under `production/`, together with a repository-root `IMPLEMENTATION.patch`. No production stub, expected-failure success path, test weakening, second encrypted chain, or alternative implementation is included.

Input source: `448e9d3067796b64656f0746f4be5c4153b1271d`. Input ZIP: 1,452,912 bytes, SHA-256 `afd8d383aabcd5c043961688e021b08625d94e19e3bd8d5d8393365b9f7e892f`. OpenFHE reference pin: `df495ba2e91739a6dc8f1de254fc5a41155ce504` (1.5.0). The source and official references were obtained exclusively from that ZIP; no network checkout was used. The declared commit identity is supplied by the manifest; individual supplied blob identities were recomputed, not authenticated against a remote Git history.

This is the code author's self-review, not an additional independent reviewer seat. There is no cryptographic precision, runtime, security-level, all-key, or replicated-paper-mean claim. The unchanged frozen test remains the acceptance authority.

## Applying the draft

From the exact extracted `project/` directory or the corresponding repository root:

```sh
git apply --check /path/to/IMPLEMENTATION.patch
git apply /path/to/IMPLEMENTATION.patch
```

No extra `project/` prefix or stripping option is required. Actual apply, reverse-apply and complete tree comparisons passed on a fresh exact-source copy. Patch scope is exactly six files, with 475 insertions and 119 deletions. Every other one of the 44 supplied project files, including all tests/oracles, CMake, workflow, coordination contracts and both h128 files, remains byte-identical.

## Requirement-to-source map

All implementation locations below refer to the supplied complete files under `production/`, not to historical source line numbers.

| Requirement / invariant | Implementation location | Reasoning / check |
|---|---|---|
| Four frozen public entry points | `include/openfhe_2023_1788/repeated_mult2.h:58-60`; `high_precision_client_io.h:137-149`; `double_ckks.h:162` | Adds the paper setup, plan constructor, terminal result method and narrow binder. No arbitrary result/scale constructor is exposed. |
| Privately issued result and exact getter types | `include/openfhe_2023_1788/repeated_mult2.h:90-110`; `src/repeated_mult2.cpp:502-531` | No default or public state constructor; const owner members retain the issuing plan, a const-allocated independent ciphertext snapshot, and the canonical receipt. Copy/move construction preserves ownership. |
| Exact Table 3 Q/P/root sequence | `src/repeated_mult2.cpp:21-32,155-203,412-432` | Uses Base0, Base1, Mult0..Mult7, Div and the reserved P literally; actual returned parameters must match those identities. Eight families remove only the actual second-last Mult prime. |
| Two explicit repeated profiles only | `src/repeated_mult2.cpp:155-203,234-287,301-304,369-432` | Existing N64/Q10 two-family diagnostic and new N32768/Q11 eight-family paper setup are selected privately; there is no public parameter framework. |
| Actual factory-returned profile validation | `src/repeated_mult2.cpp:48-78,92-138,173-203` | Returned context, parameters, scheme components, Q/P/QP, partition counts/order, PK basis and fixed modes are checked, not merely requested settings. Null live Q/P/QP pointers are rejected before context dimension getters. |
| Nominal 50, not probe nominal 100 | `src/repeated_mult2.cpp:124-136,155-170,253-286`; `src/high_precision_client_io.cpp:174-242` | Encoding parameters are nominal 50. Recorded metadata stays 2^100 -> 2^150 -> 2^100, with degrees 2 -> 3 -> 2; logical scale is separate. |
| One real h128 root, projected by full identity | `src/repeated_mult2.cpp:320-367,412-432` | Calls the unchanged h128 adapter once in B0, independently checks actual signed coefficients across all Q towers and weight 128, then projects the same secret by modulus/root/phi identity into each family. |
| No secret in evaluator/plan/result | `include/openfhe_2023_1788/repeated_mult2.h:7-9,65-118`; `src/repeated_mult2.cpp:79-90,223-232,316-434`; `src/double_ckks.cpp:1246-1282` | Private keys exist only in client setup locals and the separately returned client setup fields. Public plan Data and result contain no private key. DEBUG_KEY compilation is rejected. |
| Local evaluation rows, seals and cleanup | `src/repeated_mult2.cpp:140-153,205-211,223-232,297-308,320-347` | Checks absence before acquiring tag ownership, installs only family-local rows, seals row identity and full A/B values, and revalidates them. RAII removes only acquired tags, including partial-setup failure. No global cache clear is added. |
| Canonical exact receipt chain | `src/repeated_mult2.cpp:253-286,305-314` | Receipts are allocated const and accepted only by membership in the issuing plan. Input/Reentry -> Tensor -> Relinearized -> Rescaled captures exact rational scales, operation/family, local level and metadata. |
| DCP once and repeated family routing | `src/double_ckks.cpp:370-397,440-490,1213-1244`; `src/repeated_mult2.cpp:436-499` | Existing DCP/Mult2/Tensor2/Relin2/RS2 arithmetic is retained. Slots become the validated family batch. Reentry copies unchanged elements into the next family wrapper, preserving exact scale; it does not decompose, decrypt, encrypt, key-switch or refresh the operand. |
| Terminal RCB with original root wrapper | `src/double_ckks.cpp:1246-1282`; `src/repeated_mult2.cpp:510-531` | Requires the issuing terminal Rescaled receipt and live pair. Uses existing family-local d*high+low RCB, validates the original ordered prefix, and only rewraps unchanged elements into B0/root tag. For paper, absolute level is 9 and the active prefix is the original two Base primes. |
| Narrow terminal binder and live cached-state checks | `src/high_precision_client_io.cpp:453-487,506-519,645-689`; `include/openfhe_2023_1788/high_precision_client_io.h:44,101-118` | Rejects foreign/no-plan result, validates live plan/result/receipt/state, clones a separate snapshot, records exact S8 and distinct RepeatedMult2Rcb origin, and leaves first-operation factors absent. Clone and Decrypt revalidate paper state against its canonical receipt. |
| Strong lifetime ownership | `include/openfhe_2023_1788/repeated_mult2.h:104-109`; `src/high_precision_client_io.cpp:24-40,506-539,645-661` | I/O and bound ciphertexts retain a binding that owns the plan; the result directly owns the plan. No owner cycle is introduced. Old pairs remain receipt-only, preserving the diagnostic plan-release behavior. |
| Public Element Encrypt / public Poly* Decrypt | `src/high_precision_client_io.cpp:541-597,664-717` | Exact integer coefficients go through the official Poly/DCRT constructor and public scheme Element Encrypt. Public Poly* Decrypt is followed by exact centering and our codec using the bound rational scale. No packed Plaintext Decode or binary64 slot transport is used. |
| Heap geometry and independent precision roots | `src/high_precision_client_io.cpp:18-20,333-410,436-449,522-539,559-575,689-716` | Both geometries use heap vectors. Each precision independently generates dyadic-angle seeds and balanced products; the 160-decimal roots are never promoted into the 220-decimal table. Tables are immutable within the shared I/O implementation and reused across its operations. |
| Rounding, nonwrap and codec disagreement | `src/high_precision_client_io.cpp:413-450,552-577,689-717` | Retains the supported-range and half-integer ambiguity checks, exact coefficient nonwrap guard and <=2^-120 cross-precision check. Positive-forward / negative-inverse butterflies are preserved. |
| Legacy I/O contract preserved | `src/high_precision_client_io.cpp:174-242,531-532,599-643`; `include/openfhe_2023_1788/high_precision_client_io.h:137-147` | Context-only construction still admits only N64/Q8/UNIFORM, 16 slots/gap2. Existing BindFirstMult2Rcb remains separate. A nullptr overload preserves source compatibility after adding the plan overload. N64/Q10 plan I/O is not enabled. |

## Scale, basis and same-root argument

Write d for the unchanged final Div prime. In B0 the fresh logical scale is exactly S0=2^100 and the full basis has eleven towers. The existing DCP drops Div, leaving ten active towers and local level 1. For operation i in family B(i-1), the tensor/relinearized receipt has exact scale S(i-1)^2/d. RS2 consumes the actual second-last full-family prime m_i and issues S_i=S(i-1)^2/(d*m_i), at local level 2. Reentry uses this unchanged active basis as the next family's full basis minus Div and keeps the same exact scale.

The consumed sequence is Mult7, Mult6, Mult5, Mult4, Mult3, Mult2, Mult1, Mult0. Thus B7 has full basis [Base0, Base1, Mult0, Div]; its final active basis is [Base0, Base1]. The B0 wrapper's absolute level is 11-2=9. Its ciphertext elements are not rescaled or otherwise changed by the root-wrapper seam. Full modulus/root/phi matching in client setup establishes that each family's private polynomial is the projection of the same signed ternary polynomial, so this wrapper change does not require an evaluator secret or a key switch.

The independent exact-integer check compared all eight recursive scales against

```
S_i = (2^100)^(2^i) /
      [ d^(2^i - 1) * product(j=1..i, m_j^(2^(i-j))) ].
```

It gives S8/2^100 = approximately `1.000364850389603922850588307864032785175907537109906`. That number is explanatory only: no approximate ratio authorizes a result or normalizes production output. The plan stores the exact reduced rational, and the binder takes its numerator/denominator from the validated terminal receipt. Recorded metadata 2^100 is intentionally not the logical normalization.

The nominal 50 decision follows the supplied `NOMINAL_SCALE_AUDIT_01.md` and pinned FIXEDMANUAL getters; it is not inferred from a successful FHE run here. The parameter-only historical probe is used solely for exact Q/P/root identities.

## Ownership and mutation boundary

A caller can observe const ciphertexts and the upstream shared context/Params graph; that is not transitive immutability of OpenFHE objects. Boundary validation therefore remains mandatory. Family profile and row checks compare live state against private value seals. The result snapshot is a newly const-allocated ciphertext object, with independent coefficient storage and an independently owned empty metadata map. The binder clones that snapshot again. Bound evaluation clones do not alias the bound coefficient storage or empty metadata map.

Upstream getters can expose mutable metadata-map/Params objects even through const ciphertext handles. Result adoption and bound use check the live map, context, basis and metadata. The new paper cached state is also compared with the canonical receipt on every CloneForEvaluation and Decrypt: changing a copied/cast state value cannot authorize a different scale, basis, origin or root. This is normalization provenance, not authenticated operand lineage. C++ undefined behavior and concurrent mutations of OpenFHE's global caches are outside the supported boundary; callers must serialize cache/context mutation, as already required by the accepted h128 module.

Rows are owned by unique setup-acquired tags, not by all equivalent contexts or a global clear. Data destruction releases only its own tags. I/O/result/bound ownership can extend that lifetime beyond the local setup/evaluator variable. Pairs themselves were deliberately not made plan owners because the existing diagnostic test depends on releasing the plan while a receipt-bearing pair still exists.

## Transform reasoning and numeric-only evidence

The two internal geometries are (slots,N,M,gap)=(16,64,128,2) and (16384,32768,65536,1). The original butterfly order and signs remain those of the supplied official `dftransform.cpp:209-268`. The coefficient split is real coefficients at gap*j and imaginary coefficients at gap*j+N/2.

A root indexed by k is assembled from that precision's independently generated exp(2*pi*i*2^b/M) seeds for the set bits of k. Each root uses at most log2(M) factors; this avoids both M transcendental calls and an M-step accumulated recurrence. Root construction is O(M), tables and working arrays are heap-backed, and the transform remains O(slots*log(slots)). The I/O object shares its immutable tables across its Encrypt/Decrypt calls; no global or speculative cache framework was added.

A separate harness extracted the actual production numeric definitions unchanged, compiled them with GCC and Boost, and exercised the original and full-packing geometries. It used binary-512 expected arithmetic and independent direct Horner evaluation at ten paper anchors. Final-scale input to this harness was an **ideal plaintext z^256 coefficient-encoding experiment**, not an evaluated ciphertext and not an encrypted chain.

| Final local numeric check | Observed maximum |
|---|---:|
| N64/16-slot fresh coefficient codec error | 3.392390213032747e-30 |
| Paper full-slot fresh coefficient codec error | 1.304830266230467e-28 |
| Paper ideal final-scale coefficient codec error | 1.194754073809313e-28 |
| Largest 160/220-decimal disagreement, measured before binary conversion | 4.328350705575657e-165 |
| Paper fresh direct-Horner vs expected error at ten anchors | 5.342436301701689e-29 |
| Paper ideal final direct-Horner vs expected error at ten anchors | 5.025245963290269e-29 |
| Ideal final slot-0 error with deliberately wrong 2^100 normalization | 3.687434050131319e-5 |

The 2^-80 componentwise bound is about 8.27e-25; 2^-120 is about 7.52e-37. These numeric-only checks passed without changing either bound. The ideal output-difference witness was retained and the ideal two-Base nonwrap/headroom check passed. Actual encrypted noise, h128 generation, relinearization, RS2 and per-round ciphertext oracles were **not** exercised.

The initial author numeric extraction caught a missing dependent-template disambiguator, which was corrected. An earlier direct-root numeric run timed out without a completion marker; its partial log is retained but is not accepted as a complete run. See the execution ledger for these distinctions and the harness-only measurement correction.

## Pinned source basis and remaining acceptance

Relevant supplied official references include:

- `official-full/src/pke/include/schemebase/base-scheme.h:204-224`: public Element encryption and Poly* decryption routes.
- `official-full/src/pke/lib/scheme/ckksrns/ckksrns-pke.cpp:71-96`: Poly* coefficient/CRT result rather than packed plaintext normalization.
- `official-full/src/core/lib/math/dftransform.cpp:209-268`: original special-FFT order and signs.
- Supplied `ciphertext.h`, `cryptocontextfactory.h`, CKKS/RNS precomputation and HYBRID key-switch files: clone ownership, actual returned contexts, family tables and local public evaluation rows.
- Supplied `paper/PAPER-2023-1788.txt`, section 6.3/Table 3, the parameter-only probe and frozen production/input-domain/nominal-scale contracts. The provided TXT, rather than an independently fetched paper version, was used for paper text review.

No changed full production translation unit was compiled against OpenFHE in this environment. CMake failed at the required package lookup. The existing five API builds, all 60 regression tests, explicit paper target build, live 61 listing and one focused paper chain on each GCC/Linux and MinGW64/Windows host remain NOT RUN here. The package is ready for the independent integration review and the already-defined hosted sequence after retention of the first RED; it is not permission to report GREEN early or to add trials/relaxations.
