# TEST / CLAIM LEDGER

## Status definitions

- `EXECUTED-PASS`: the named non-build check was actually run in this container and passed.
- `SOURCE-INSPECTED`: the source/test construction was inspected and is present, but its compile/runtime result is not known.
- `NOT-EXECUTED`: no corresponding compilation, runtime test, platform build, or CI run was performed here.
- `PACKET-HISTORICAL`: a statement recorded by the supplied task; it is not this reviewer's execution evidence.

## A. Input, patch, and source-integrity claims

| ID | Claim | Evidence/artifact | Status |
|---|---|---|---|
| I-01 | Outer ZIP has the user-declared SHA-256 and byte size | `checks/input-verification.txt` | `EXECUTED-PASS` |
| I-02 | ZIP central-directory/content integrity check found no corrupt member | `checks/input-verification.txt` | `EXECUTED-PASS` |
| I-03 | All 24 manifest-listed files match bytes and SHA-256; no extra regular file beyond the manifest | `checks/input-verification.txt` | `EXECUTED-PASS` |
| I-04 | All 12 patches replay in lexical order on the supplied exact `project/` bytes | `checks/patch-apply.txt` | `EXECUTED-PASS` |
| I-05 | Replayed tree equals candidate tree `32e9cf3a5e66c3e87018fe8a344593df24b8bb2a` | `checks/patch-apply.txt` | `EXECUTED-PASS` |
| I-06 | Candidate working tree is clean and aggregate diff passes `git diff --check` | `checks/git-diff-and-tree.txt` | `EXECUTED-PASS` |
| I-07 | Existing production code was not deleted or silently rewritten | production numstat in `checks/git-diff-and-tree.txt` | `EXECUTED-PASS` for the diff fact |
| I-08 | Workflow YAML parses and includes the target branch once | `checks/workflow-yaml.txt` | `EXECUTED-PASS` |
| I-09 | Both Linux/GCC and Windows/MinGW64 workflow jobs explicitly build both API contract targets and run CTest | `checks/workflow-yaml.txt` | `SOURCE-INSPECTED` |

## B. Red—green sequence claims

| ID | Required transition | Source evidence | Runtime/build status |
|---|---|---|---|
| T-01 | Add API compile-red | Patch 01 adds an explicit target whose exact member pointer references an absent Add declaration | `NOT-EXECUTED` |
| T-02 | Add API scaffold-green | Patch 02 adds the exact const signature and an unconditional `invalid_argument` scaffold | `NOT-EXECUTED` |
| T-03 | Add runtime behavioral-red | Patch 03 registers a real encrypted DCP call and treats the scaffold diagnostic as missing behavior | `NOT-EXECUTED` |
| T-04 | Minimal Add green | Patch 04 replaces only the scaffold with validation, cloned-left componentwise `+=`, result construction, and result validation | `NOT-EXECUTED` |
| T-05 | Sub API compile-red | Patch 05 adds an explicit target whose exact member pointer references an absent Sub declaration | `NOT-EXECUTED` |
| T-06 | Sub API scaffold-green | Patch 06 adds the exact const signature and an unconditional `invalid_argument` scaffold | `NOT-EXECUTED` |
| T-07 | Sub runtime behavioral-red | Patch 07 registers a real encrypted DCP call and treats the scaffold diagnostic as missing behavior | `NOT-EXECUTED` |
| T-08 | Minimal Sub green | Patch 08 replaces only the scaffold with validation, cloned-left componentwise `-=`, result construction, and result validation | `NOT-EXECUTED` |

The eight source states were inspected commit by commit in `checks/red-green-source-state.txt`. A hosted executor must still capture the actual compiler/runtime red and green at each step.

## C. Final public-seam behavioral claims

| ID | Claim under test | Primary test seam | Status |
|---|---|---|---|
| B-01 | Exact public Add signature is a const member taking two const pair references | `tests/pair_add_api_contract_test.cpp` | `SOURCE-INSPECTED`; compile `NOT-EXECUTED` |
| B-02 | Exact public Sub signature is a const member taking two const pair references | `tests/pair_sub_api_contract_test.cpp` | `SOURCE-INSPECTED`; compile `NOT-EXECUTED` |
| B-03 | Basic public Add performs high/high and low/low modular addition rather than throwing or swapping members | `tests/pair_add_test.cpp` | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-04 | Basic public Sub performs high/high and low/low modular subtraction with correct order | `tests/pair_sub_test.cpp` | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-05 | Independent expected values use `cpp_int` CRT/centered signed reduction, not production Add/Sub or OpenFHE EvalAdd/EvalSub | `CheckMemberOracle`, `ReconstructCentered` in `tests/pair_arithmetic_test.cpp` | `SOURCE-INSPECTED` |
| B-06 | Every high/low member, two RLWE components, active tower, and ring coefficient is compared modulo its tower modulus | `CheckMemberOracle` | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-07 | Public RCB result equals `q_div*(high_L ± high_R)+(low_L ± low_R)` modulo the same active Q | `CheckRcbOracle` | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-08 | RCB expectation is not constructed by calling production RCB on either operand | `CheckRcbOracle` source path | `SOURCE-INSPECTED` |
| B-09 | Deterministic 0, ±1, and points around signed ±Q/2 exercise modular wrap/carry | `BoundaryWitnesses`, `InstallControlledPair` | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-10 | High and low witnesses are nonzero and distinct | controlled-oracle fixture assertions | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-11 | Self-addition and same-object aliasing are supported | `selfSum = module.Add(left,left)` plus independent oracle/provenance checks | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-12 | Self-subtraction produces exact zero residues | `selfDifference = module.Sub(left,left)` plus independent zero/oracle checks | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-13 | Subtraction order is noncommutative for the controlled witness | forward/reverse Sub comparisons | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-14 | Add/Sub preserve lifecycle, level, basis, degree, all scale fields, key tag, slots, format, and component count | `CheckResultManifestAndProvenance` | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-15 | Fresh output high/low objects derive from corresponding left metadata/parameter provenance and do not alias each other or either input object | `CheckMemberStructureDerivedFrom`, `CheckMetadataDerivedFrom` | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-16 | Input pair/ciphertext values and exposed metadata/parameter objects remain unchanged | `SnapshotPair`, `CheckPairUnchanged`, `CheckCiphertextUnchanged` | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-17 | Add/Sub work in `ReadyForFirstMult` | public DCP fixture | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-18 | Add/Sub work in `ReadyForRS2` | public DCP → Tensor2 → Relin2 fixture | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-19 | Add/Sub work in `RefreshRequired` | public DCP → Tensor2 → Relin2 → RS2 fixture | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-20 | Lifecycle fixtures include untouched nonzero real and complex encrypted inputs | `TestPublicLifecyclesAndKeyIndependence` | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-21 | Add/Sub do not require this fixture's multiplication key | targeted `ClearEvalMultKeys(fixtureTag)` before all three lifecycle calls | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-22 | Targeted key removal leaves an unrelated guard row, and Add/Sub/RCB do not mutate remaining key identities or A/B DCRT values | `SnapshotEvalKeyCache`, `CheckEvalKeyCacheUnchanged` | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-23 | Add/Sub/RCB do not mutate exposed context parameter identities/values during the scoped window | `SnapshotContextParameters`, `CheckContextParametersUnchanged` | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-24 | Mixed lifecycle rejects before arithmetic | compatibility rejection case | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-25 | Genuine key-tag mismatch rejects | two key pairs in the same context | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-26 | Genuine slots mismatch rejects | separately encoded slot-count fixture | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-27 | Genuine foreign-context pair rejects | a distinct context forced by different batch size and identity assertion | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-28 | Malformed divisor/basis/level/degree/recorded and logical scale/key tag/slots/encoding/component count/tower format reject | public-accessor/member-corruption cases | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-29 | Both operands are unchanged after every rejection | `CheckBothRejectWithoutMutation` | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-30 | Left validation precedes right validation; right validation precedes mutual compatibility | deliberately layered malformed/mismatch cases and exact diagnostics | `SOURCE-INSPECTED`; runtime `NOT-EXECUTED` |
| B-31 | New production lines contain no convenience Add/Sub, rescale, relinearization, key-generation/cache, or modulus-reduction call | static added-line scan | `EXECUTED-PASS` for source text only |

## D. Platform/build claims

| ID | Claim | Status |
|---|---|---|
| P-01 | CMake can locate pristine OpenFHE 1.5.0 in this container | `NOT-EXECUTED` as a successful configure; dependency probe failed at `find_package` |
| P-02 | Linux/GCC warning-clean project build succeeds | `NOT-EXECUTED` |
| P-03 | Add and Sub API contract targets compile | `NOT-EXECUTED` |
| P-04 | Focused pair tests pass | `NOT-EXECUTED` |
| P-05 | Full CTest suite passes | `NOT-EXECUTED` |
| P-06 | Windows/MinGW64 warning-clean build and tests pass | `NOT-EXECUTED` |
| P-07 | GitHub Actions workflow passes | `NOT-EXECUTED`; no dispatch/push was performed |

## E. Historical packet evidence — not adopted as execution

- The task records that source-identical production `a801e2c` passed warning builds and 40 tests on Linux/GCC and Windows/MinGW64 in Actions run `33833020685`. This is `PACKET-HISTORICAL`, not execution of the returned candidate.
- The task records that baseline run `33834861766` had Linux success and Windows still in progress when the packet was prepared. No Windows-success claim is made for that run.

## F. Explicit blind spots and non-claims

The deep immutability tests cover exposed ciphertext values, ciphertext and metadata identities, metadata deep values, aggregate/tower parameter identities and values, context parameters, and evaluation-key A/B vectors where the public types expose them. They do not instrument unexposed process-global allocator state, hidden library caches unrelated to the inspected evaluation-key map, data races, or concurrent callers.

No claim is made about decoded accuracy, 53-bit/106-bit precision, theorem normalization, security level, performance, Mult2 correctness, automatic refresh, or a second multiplication.
