# INPUT VERIFICATION

## Result

`PASS`

## Outer archive

| Field | Value |
|---|---|
| File | `pair-arithmetic-pro-7041a48.zip` |
| Observed bytes | `900942` |
| Declared SHA-256 | `50269f2a0f5198d5f4aee312808097370e6153783f7586cb1e9c0446da133c38` |
| Recomputed SHA-256 | `50269f2a0f5198d5f4aee312808097370e6153783f7586cb1e9c0446da133c38` |
| Hash match | yes |
| ZIP integrity (`testzip`) | OK |
| ZIP entries | 38 total, 25 regular files |

## Source manifest

| Field | Value |
|---|---|
| Manifest | `SOURCE-MANIFEST.json` |
| Manifest SHA-256 | `a14252379ac595d22272c7daeff8b88c10e5099dc6e47c6aeb88623cf6b9a054` |
| Manifest-listed files | 24 |
| Extracted regular files excluding manifest | 24 |
| Missing | 0 |
| Extra | 0 |
| Byte-count mismatches | 0 |
| SHA-256 mismatches | 0 |

## Bound identities read from the verified manifest

- Project source commit: `7041a489ae1afa98b75322ec334543f29f10b738`
- Target branch: `codex/pair-arithmetic-01`
- Pristine OpenFHE commit: `df495ba2e91739a6dc8f1de254fc5a41155ce504`

The original verified manifest is copied unchanged as `INPUT_SOURCE_MANIFEST.json`. The raw recomputation output is in `checks/input-verification.txt`.
