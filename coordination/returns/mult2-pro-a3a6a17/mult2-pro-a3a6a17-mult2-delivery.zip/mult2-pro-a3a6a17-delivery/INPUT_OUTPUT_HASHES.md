# 输入与输出身份

## 1. 输入包

```text
filename  = mult2-pro-a3a6a17.zip
bytes     = 1576818
sha256    = 5b83855378345120e65a4495eb034b2c2e5d406b1c6b03053491f1929bde7f81
members   = 43
regular   = 31
```

输入身份已实际复算，大小和 SHA-256 均与任务给定值一致。

## 2. 输入约束对象

```text
SOURCE-MANIFEST.json
bytes   = 5705
sha256  = 812a0a4465f3a600442abc33cc9ee9e49817796337822c544da06af7652fc4a2

TASK.md
bytes   = 8738
sha256  = d85cd3be8d95d893b75bc77e17b82bfbc3334a39ca5596b4e88a85d2080088f1

PAPER-2023-1788.pdf
bytes   = 759375
sha256  = 61d9b948b17b6a624d3bf3372462555288308011226d2893e9e6bc3d6d197eac
```

清单声明：

```text
source commit = a3a6a171b60c4829f674f0dc4f5b35d658d47868
branch        = codex/mult2-01
OpenFHE       = df495ba2e91739a6dc8f1de254fc5a41155ce504
```

输入 ZIP 没有 `.git` 对象，故 `source commit` 是由已校验的 SOURCE-MANIFEST 绑定的供应身份；本环境不能从包内 Git object graph 独立重算该 commit。

## 3. 本地审查账本身份

为生成可排序的 format-patch，在临时本地仓库中把包内 `project/` 字节导入一个合成 baseline commit。该本地 commit **不是**任务指定 source commit，不能替代它：

```text
local content-import baseline = 7a00c8bc0422cbb05943b49a78b0a9715e144da7
local candidate head          = c70afca9f0fc772244eefe2fa5ff40bd0a78d0c8
local candidate parent        = f66b709b16485c337e26366a50b86cfb5ef5d74d
final Git tree                = 66bad80110c866a4616194a74eb3b6fa55b096af
```

在第二个干净临时仓库中按补丁顺序重放后，commit ID 因 committer 元数据不同而变化，但最终 Git tree 仍精确为：

```text
66bad80110c866a4616194a74eb3b6fa55b096af
```

## 4. 补丁 SHA-256

```text
91a3bcf9417915ec511e7d3cb0c138e95d249b56b2d43675b58fe4861aa10d06  patches/0001-test-red-add-missing-Mult2-public-API-contract.patch
4dd82c1f90831ad83a07fa0f9fe506e9649f3d23beea75a9e0976d603ebf949b  patches/0002-feat-green-scaffold-const-Mult2-API.patch
4403dbfcfec2a1e2961384d0666c90e9138487e5a55ad90c5dc4338acb2db2f3  patches/0003-test-red-require-first-Mult2-end-to-end-composition.patch
404c3ebdc0fca7c8c7732f087c022f5f2fcb49d21b54878a54547c3d602c1ce1  patches/0004-feat-green-compose-Mult2-from-Tensor2-Relin2-and-RS2.patch
d29f9927d82a6b9e09ab650d15c253a52457ea0aea0bb48ab30ecfa654a737fa  patches/0005-test-add-independent-Mult2-end-to-end-arithmetic-oracle.patch
41de21eb9dca1c9b4a4dd34256891feef08a4e7efc80d197a3f9de2657084882  patches/0006-test-harden-Mult2-validation-and-terminal-fail-fast.patch
2a2d144ead51685acb0a26d530f27078afccb94ac5c2c9736f09509fb2fa59df  patches/0007-test-make-Mult2-output-oracle-independent-of-RCB.patch
cd86177cafd78950d1959c2d33f5b6e506ba5ee189d4b08c4215fa64fa060b0c  patches/0008-ci-exercise-Mult2-branch-and-all-public-API-targets.patch
2f6d480d07a97931830b9b9a7dce4c1fc9208747cf0f3525dfd7981e4e7769a4  patches/series
```

## 5. 最终源码导出身份

`final-project/` 含 22 个普通文件，总计 565,847 bytes。其 Git tree 是：

```text
66bad80110c866a4616194a74eb3b6fa55b096af
```

另提供一个与 Git 无关的、按 UTF-8 相对路径排序并串联“路径长度、路径、内容长度、内容”计算的 SHA-256：

```text
41eeb1c85ed343a72f6cf1647a7163aae4428435c3000366bb43272d6511c96a
```

关键差异摘要：

```text
verification/production-code-diff.txt
sha256 = 8ef0df97c875246c63e03f4a182575bbd9412f4b3eb55ddd8a814d9474cc8c3f

verification/final-combined.diff
sha256 = d60bc6e571db5c296ef7c6d1b2a1a888d25e450e6d504b5c31108c91fa31e383
```

## 6. 交付包身份规则

- `DELIVERY-MANIFEST.json` 列出除自身外的全部文件及大小/SHA-256；
- `SHA256SUMS` 覆盖除自身和 `DELIVERY-MANIFEST.json` 外的全部文件；
- 外层 ZIP 不能可靠地把自身 SHA-256 写进自身，因此 ZIP 的最终大小和 SHA-256 放在同目录的 `.sha256` sidecar 中；
- 解压后运行 `python3 verify_delivery.py` 可复算交付内部身份。
