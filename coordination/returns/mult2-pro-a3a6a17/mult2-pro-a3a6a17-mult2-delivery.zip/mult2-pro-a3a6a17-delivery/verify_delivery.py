#!/usr/bin/env python3
"""Verify this Mult2 delivery without compiling the C++ project."""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path, PurePosixPath

MANIFEST_NAME = "DELIVERY-MANIFEST.json"
SUMS_NAME = "SHA256SUMS"
EXPECTED_PATCH_COUNT = 8


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_relative_path(text: str) -> bool:
    path = PurePosixPath(text)
    return (
        text != ""
        and not path.is_absolute()
        and ".." not in path.parts
        and "" not in path.parts
        and "\\" not in text
    )


def regular_files(root: Path) -> set[str]:
    return {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file()
    }


def fail(messages: list[str]) -> int:
    for message in messages:
        print(f"ERROR: {message}", file=sys.stderr)
    return 1


def main() -> int:
    root = Path(__file__).resolve().parent
    errors: list[str] = []

    manifest_path = root / MANIFEST_NAME
    sums_path = root / SUMS_NAME
    if not manifest_path.is_file():
        return fail([f"missing {MANIFEST_NAME}"])
    if not sums_path.is_file():
        return fail([f"missing {SUMS_NAME}"])

    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        return fail([f"cannot parse {MANIFEST_NAME}: {exc}"])

    if manifest.get("schemaVersion") != 1:
        errors.append("unsupported manifest schemaVersion")
    records = manifest.get("files")
    if not isinstance(records, list):
        return fail(errors + ["manifest files field is not a list"])

    record_map: dict[str, tuple[int, str]] = {}
    for index, record in enumerate(records):
        if not isinstance(record, dict):
            errors.append(f"manifest record {index} is not an object")
            continue
        rel = record.get("path")
        size = record.get("bytes")
        digest = record.get("sha256")
        if not isinstance(rel, str) or not safe_relative_path(rel):
            errors.append(f"manifest record {index} has unsafe path: {rel!r}")
            continue
        if rel == MANIFEST_NAME:
            errors.append("manifest must not contain its own record")
        if rel in record_map:
            errors.append(f"duplicate manifest path: {rel}")
        if not isinstance(size, int) or size < 0:
            errors.append(f"invalid byte count for {rel}")
            continue
        if (
            not isinstance(digest, str)
            or len(digest) != 64
            or any(character not in "0123456789abcdef" for character in digest)
        ):
            errors.append(f"invalid SHA-256 for {rel}")
            continue
        record_map[rel] = (size, digest)

    actual = regular_files(root)
    expected_manifest_files = actual - {MANIFEST_NAME}
    manifest_files = set(record_map)
    for rel in sorted(expected_manifest_files - manifest_files):
        errors.append(f"file missing from manifest: {rel}")
    for rel in sorted(manifest_files - expected_manifest_files):
        errors.append(f"manifest references absent/unexpected file: {rel}")

    for rel, (expected_size, expected_digest) in sorted(record_map.items()):
        path = root / rel
        if not path.is_file():
            continue
        actual_size = path.stat().st_size
        if actual_size != expected_size:
            errors.append(
                f"size mismatch for {rel}: expected {expected_size}, got {actual_size}"
            )
            continue
        actual_digest = sha256_file(path)
        if actual_digest != expected_digest:
            errors.append(
                f"SHA-256 mismatch for {rel}: expected {expected_digest}, got {actual_digest}"
            )

    sums_records: dict[str, str] = {}
    try:
        lines = sums_path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeDecodeError) as exc:
        return fail(errors + [f"cannot read {SUMS_NAME}: {exc}"])
    for line_number, line in enumerate(lines, start=1):
        if not line:
            continue
        if len(line) < 67 or line[64:66] != "  ":
            errors.append(f"malformed {SUMS_NAME} line {line_number}")
            continue
        digest = line[:64]
        rel = line[66:]
        if (
            len(digest) != 64
            or any(character not in "0123456789abcdef" for character in digest)
            or not safe_relative_path(rel)
        ):
            errors.append(f"invalid {SUMS_NAME} line {line_number}")
            continue
        if rel in sums_records:
            errors.append(f"duplicate {SUMS_NAME} path: {rel}")
        sums_records[rel] = digest

    expected_sums_files = actual - {MANIFEST_NAME, SUMS_NAME}
    sums_files = set(sums_records)
    for rel in sorted(expected_sums_files - sums_files):
        errors.append(f"file missing from {SUMS_NAME}: {rel}")
    for rel in sorted(sums_files - expected_sums_files):
        errors.append(f"unexpected {SUMS_NAME} path: {rel}")
    for rel, expected_digest in sorted(sums_records.items()):
        path = root / rel
        if path.is_file():
            actual_digest = sha256_file(path)
            if actual_digest != expected_digest:
                errors.append(
                    f"{SUMS_NAME} mismatch for {rel}: expected {expected_digest}, got {actual_digest}"
                )

    series_path = root / "patches" / "series"
    if not series_path.is_file():
        errors.append("missing patches/series")
        series: list[str] = []
    else:
        series = [line.strip() for line in series_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(series) != EXPECTED_PATCH_COUNT:
        errors.append(
            f"patches/series count mismatch: expected {EXPECTED_PATCH_COUNT}, got {len(series)}"
        )
    if len(series) != len(set(series)):
        errors.append("patches/series contains duplicates")
    for entry in series:
        if not safe_relative_path(entry) or PurePosixPath(entry).name != entry:
            errors.append(f"unsafe/non-local patch series entry: {entry}")
        elif not (root / "patches" / entry).is_file():
            errors.append(f"series patch is missing: {entry}")
    actual_patches = {
        path.name for path in (root / "patches").glob("*.patch") if path.is_file()
    }
    if actual_patches != set(series):
        errors.append(
            "patch files and patches/series differ: "
            f"only_files={sorted(actual_patches - set(series))}, "
            f"only_series={sorted(set(series) - actual_patches)}"
        )

    if errors:
        return fail(errors)

    print(
        "PASS: delivery verified; "
        f"manifest_files={len(record_map)}; "
        f"sha256sum_files={len(sums_records)}; "
        f"patches={len(series)}"
    )
    print("NOTE: this verifier does not compile C++ or prove Theorem 4.8.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
