#include "openfhe.h"
#include "openfhe_2023_1788/double_ckks.h"

#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <map>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace {

using lbcrypto::Ciphertext;
using lbcrypto::CryptoContext;
using lbcrypto::DCRTPoly;
using lbcrypto::NativeInteger;
using openfhe_2023_1788::CiphertextPair;
using openfhe_2023_1788::DoubleCKKS;
using openfhe_2023_1788::PairLifecycle;
using openfhe_2023_1788::PaperScaleDescriptor;
using openfhe_2023_1788::ReadOnlyCiphertext;

using EvalMultKeyMap = std::map<std::string, std::vector<lbcrypto::EvalKey<DCRTPoly>>>;

constexpr std::uint32_t kRingDimension = 64;
constexpr std::uint32_t kBatchSize = 16;
constexpr std::uint32_t kScalingModSize = 30;
constexpr std::uint32_t kFirstModSize = 35;
constexpr std::uint32_t kMultiplicativeDepth = 7;

class TestFailure final : public std::runtime_error {
public:
    using std::runtime_error::runtime_error;
};

void Check(bool condition, const std::string& message) {
    if (!condition) {
        throw TestFailure(message);
    }
}

template <class Function>
void CheckThrowsExactInvalidArgument(Function&& function,
                                     const std::string& expectedMessage,
                                     const std::string& label) {
    bool threw = false;
    try {
        std::invoke(std::forward<Function>(function));
    }
    catch (const std::invalid_argument& exception) {
        Check(exception.what() == expectedMessage,
              label + " diagnostic mismatch: " + exception.what());
        threw = true;
    }
    catch (const std::exception& exception) {
        throw TestFailure(label + " threw the wrong exception type: " + exception.what());
    }
    Check(threw, label + " did not fail loudly");
}

struct CiphertextSnapshot {
    ReadOnlyCiphertext identity;
    Ciphertext<DCRTPoly> clone;
    lbcrypto::MetadataMap metadataIdentity;
};

CiphertextSnapshot SnapshotCiphertext(const ReadOnlyCiphertext& ciphertext,
                                      const std::string& label) {
    Check(ciphertext != nullptr, label + " is null");
    const auto metadata = ciphertext->GetMetadataMap();
    Check(metadata != nullptr, label + " metadata map is null");
    return {ciphertext, ciphertext->Clone(), metadata};
}

void CheckCiphertextUnchanged(const ReadOnlyCiphertext& ciphertext,
                              const CiphertextSnapshot& snapshot,
                              const std::string& label) {
    Check(ciphertext != nullptr, label + " became null");
    Check(ciphertext.get() == snapshot.identity.get(), label + " identity changed");
    Check(*ciphertext == *snapshot.clone, label + " value or metadata changed");
    Check(ciphertext->GetMetadataMap().get() == snapshot.metadataIdentity.get(),
          label + " metadata-map identity changed");
}

struct PairSnapshot {
    CiphertextSnapshot high;
    CiphertextSnapshot low;
    const lbcrypto::CryptoContextImpl<DCRTPoly>* contextIdentity;
    NativeInteger divisor;
    std::vector<NativeInteger> orderedModuli;
    std::size_t level;
    PaperScaleDescriptor paperScale;
    double recordedScalingFactor;
    std::size_t noiseScaleDegree;
    PairLifecycle lifecycle;
    std::string keyTag;
    std::uint32_t slots;
    Format format;
    std::size_t componentCount;
};

PairSnapshot SnapshotPair(const CiphertextPair& pair, const std::string& label) {
    return {SnapshotCiphertext(pair.GetHigh(), label + " high"),
            SnapshotCiphertext(pair.GetLow(), label + " low"),
            pair.GetContextIdentity(),
            pair.GetDivisor(),
            pair.GetOrderedModuli(),
            pair.GetLevel(),
            pair.GetPaperScale(),
            pair.GetRecordedScalingFactor(),
            pair.GetNoiseScaleDegree(),
            pair.GetLifecycle(),
            pair.GetKeyTag(),
            pair.GetSlots(),
            pair.GetFormat(),
            pair.GetComponentCount()};
}

void CheckPairUnchanged(const CiphertextPair& pair,
                        const PairSnapshot& snapshot,
                        const std::string& label) {
    CheckCiphertextUnchanged(pair.GetHigh(), snapshot.high, label + " high");
    CheckCiphertextUnchanged(pair.GetLow(), snapshot.low, label + " low");
    Check(pair.GetContextIdentity() == snapshot.contextIdentity,
          label + " context manifest changed");
    Check(pair.GetDivisor() == snapshot.divisor, label + " divisor manifest changed");
    Check(pair.GetOrderedModuli() == snapshot.orderedModuli,
          label + " basis manifest changed");
    Check(pair.GetLevel() == snapshot.level, label + " level manifest changed");
    Check(pair.GetPaperScale().inputRecordedScalingFactor ==
              snapshot.paperScale.inputRecordedScalingFactor,
          label + " paper recorded scale changed");
    Check(pair.GetPaperScale().divisor == snapshot.paperScale.divisor,
          label + " paper divisor changed");
    Check(pair.GetPaperScale().approximateLogicalScalingFactor ==
              snapshot.paperScale.approximateLogicalScalingFactor,
          label + " high logical scale changed");
    Check(pair.GetPaperScale().approximateRecombinedLogicalScalingFactor ==
              snapshot.paperScale.approximateRecombinedLogicalScalingFactor,
          label + " recombined logical scale changed");
    Check(pair.GetRecordedScalingFactor() == snapshot.recordedScalingFactor,
          label + " recorded scaling factor changed");
    Check(pair.GetNoiseScaleDegree() == snapshot.noiseScaleDegree,
          label + " noise-scale degree changed");
    Check(pair.GetLifecycle() == snapshot.lifecycle, label + " lifecycle changed");
    Check(pair.GetKeyTag() == snapshot.keyTag, label + " key tag changed");
    Check(pair.GetSlots() == snapshot.slots, label + " slots changed");
    Check(pair.GetFormat() == snapshot.format, label + " format changed");
    Check(pair.GetComponentCount() == snapshot.componentCount,
          label + " component count changed");
}

struct EvalKeyPointerSnapshot {
    std::string tag;
    std::vector<const void*> keyPointers;
};

std::vector<EvalKeyPointerSnapshot> SnapshotEvalKeyCache() {
    const auto& cache = lbcrypto::CryptoContextImpl<DCRTPoly>::GetAllEvalMultKeys();
    std::vector<EvalKeyPointerSnapshot> result;
    result.reserve(cache.size());
    for (const auto& [tag, keys] : cache) {
        EvalKeyPointerSnapshot row{tag, {}};
        row.keyPointers.reserve(keys.size());
        for (const auto& key : keys) {
            row.keyPointers.push_back(key.get());
        }
        result.push_back(std::move(row));
    }
    return result;
}

void CheckEvalKeyCacheMatches(const std::vector<EvalKeyPointerSnapshot>& snapshot,
                              const std::string& label) {
    const auto& cache = lbcrypto::CryptoContextImpl<DCRTPoly>::GetAllEvalMultKeys();
    Check(cache.size() == snapshot.size(), label + " row count changed");
    auto current = cache.begin();
    for (const auto& expected : snapshot) {
        Check(current != cache.end(), label + " row disappeared");
        Check(current->first == expected.tag, label + " row tag or order changed");
        Check(current->second.size() == expected.keyPointers.size(),
              label + " key-vector length changed");
        for (std::size_t index = 0; index < expected.keyPointers.size(); ++index) {
            Check(current->second[index].get() == expected.keyPointers[index],
                  label + " key pointer changed");
        }
        ++current;
    }
    Check(current == cache.end(), label + " gained trailing rows");
}

class EvalKeyCacheRestorer final {
public:
    EvalKeyCacheRestorer()
        : saved_(lbcrypto::CryptoContextImpl<DCRTPoly>::GetAllEvalMultKeys()) {}

    EvalKeyCacheRestorer(const EvalKeyCacheRestorer&) = delete;
    EvalKeyCacheRestorer& operator=(const EvalKeyCacheRestorer&) = delete;

    ~EvalKeyCacheRestorer() {
        lbcrypto::CryptoContextImpl<DCRTPoly>::GetAllEvalMultKeys() = saved_;
    }

private:
    EvalMultKeyMap saved_;
};

CryptoContext<DCRTPoly> MakeContext(std::uint32_t ringDimension = kRingDimension) {
    lbcrypto::CCParams<lbcrypto::CryptoContextCKKSRNS> parameters;
    parameters.SetMultiplicativeDepth(kMultiplicativeDepth);
    parameters.SetScalingModSize(kScalingModSize);
    parameters.SetFirstModSize(kFirstModSize);
    parameters.SetScalingTechnique(lbcrypto::FIXEDMANUAL);
    parameters.SetKeySwitchTechnique(lbcrypto::HYBRID);
    parameters.SetSecretKeyDist(lbcrypto::UNIFORM_TERNARY);
    parameters.SetSecurityLevel(lbcrypto::HEStd_NotSet);
    parameters.SetRingDim(ringDimension);
    parameters.SetBatchSize(kBatchSize);

    auto context = lbcrypto::GenCryptoContext(parameters);
    context->Enable(lbcrypto::PKE);
    context->Enable(lbcrypto::KEYSWITCH);
    context->Enable(lbcrypto::LEVELEDSHE);
    return context;
}

CiphertextPair MakeReadyPair(const CryptoContext<DCRTPoly>& context,
                             const lbcrypto::PublicKey<DCRTPoly>& publicKey,
                             const DoubleCKKS& module,
                             double phase) {
    const std::vector<double> values{
        0.0, 0.125 + phase, -0.25, 0.5 - phase,
        -0.375, 0.0625, 0.25, -0.125};
    const auto plaintext = context->MakeCKKSPackedPlaintext(values, 2, 0);
    const auto ciphertext = context->Encrypt(plaintext, publicKey);
    return module.DCP(ciphertext);
}

void ClearEvalKeyCache() {
    lbcrypto::CryptoContextImpl<DCRTPoly>::GetAllEvalMultKeys().clear();
}

void TestTerminalInputsFailBeforeKeyAccess() {
    [[maybe_unused]] EvalKeyCacheRestorer restorer;
    auto context = MakeContext();
    const auto keys = context->KeyGen();
    context->EvalMultKeyGen(keys.secretKey);
    DoubleCKKS module(context);
    const auto left = MakeReadyPair(context, keys.publicKey, module, 0.0);
    const auto right = MakeReadyPair(context, keys.publicKey, module, 0.03125);
    const auto terminal = module.Mult2(left, right);
    Check(terminal.GetLifecycle() == PairLifecycle::RefreshRequired,
          "terminal fixture did not complete its first Mult2");

    const auto leftBefore = SnapshotPair(left, "terminal-guard ready left");
    const auto rightBefore = SnapshotPair(right, "terminal-guard ready right");
    const auto terminalBefore = SnapshotPair(terminal, "terminal-guard terminal");

    ClearEvalKeyCache();
    Check(lbcrypto::CryptoContextImpl<DCRTPoly>::GetAllEvalMultKeys().empty(),
          "terminal-guard fixture failed to remove evaluation keys");
    const auto emptyCache = SnapshotEvalKeyCache();

    CheckThrowsExactInvalidArgument(
        [&] { (void)module.Mult2(terminal, right); },
        "DoubleCKKS: Tensor2 requires ReadyForFirstMult inputs",
        "terminal left operand before key access");
    CheckEvalKeyCacheMatches(emptyCache,
                             "terminal-left empty evaluation-key cache");
    CheckPairUnchanged(terminal, terminalBefore, "terminal-left terminal input");
    CheckPairUnchanged(right, rightBefore, "terminal-left ready input");

    CheckThrowsExactInvalidArgument(
        [&] { (void)module.Mult2(left, terminal); },
        "DoubleCKKS: Tensor2 requires ReadyForFirstMult inputs",
        "terminal right operand before key access");
    CheckEvalKeyCacheMatches(emptyCache,
                             "terminal-right empty evaluation-key cache");
    CheckPairUnchanged(left, leftBefore, "terminal-right ready input");
    CheckPairUnchanged(terminal, terminalBefore, "terminal-right terminal input");
}

void TestMismatchedContextFailsLoudly() {
    [[maybe_unused]] EvalKeyCacheRestorer restorer;
    auto context = MakeContext();
    auto foreignContext = MakeContext(kRingDimension * 2);
    const auto keys = context->KeyGen();
    const auto foreignKeys = foreignContext->KeyGen();
    DoubleCKKS module(context);
    DoubleCKKS foreignModule(foreignContext);
    const auto left = MakeReadyPair(context, keys.publicKey, module, 0.0);
    const auto foreignRight =
        MakeReadyPair(foreignContext, foreignKeys.publicKey, foreignModule, 0.03125);
    const auto leftBefore = SnapshotPair(left, "context-mismatch left");
    const auto rightBefore = SnapshotPair(foreignRight, "context-mismatch right");

    ClearEvalKeyCache();
    const auto emptyCache = SnapshotEvalKeyCache();
    CheckThrowsExactInvalidArgument(
        [&] { (void)module.Mult2(left, foreignRight); },
        "DoubleCKKS: pair belongs to a different context",
        "mismatched context");
    CheckEvalKeyCacheMatches(emptyCache, "context rejection evaluation-key cache");
    CheckPairUnchanged(left, leftBefore, "context-mismatch left");
    CheckPairUnchanged(foreignRight, rightBefore, "context-mismatch right");
}

void TestMismatchedKeyFailsLoudly() {
    [[maybe_unused]] EvalKeyCacheRestorer restorer;
    auto context = MakeContext();
    const auto leftKeys = context->KeyGen();
    const auto rightKeys = context->KeyGen();
    DoubleCKKS module(context);
    const auto left = MakeReadyPair(context, leftKeys.publicKey, module, 0.0);
    const auto right = MakeReadyPair(context, rightKeys.publicKey, module, 0.03125);
    Check(left.GetKeyTag() != right.GetKeyTag(),
          "key-mismatch fixture unexpectedly reused a key tag");
    const auto leftBefore = SnapshotPair(left, "key-mismatch left");
    const auto rightBefore = SnapshotPair(right, "key-mismatch right");

    ClearEvalKeyCache();
    const auto emptyCache = SnapshotEvalKeyCache();
    CheckThrowsExactInvalidArgument(
        [&] { (void)module.Mult2(left, right); },
        "DoubleCKKS: Tensor2 input key tags do not match",
        "mismatched key tag");
    CheckEvalKeyCacheMatches(emptyCache, "key-tag rejection evaluation-key cache");
    CheckPairUnchanged(left, leftBefore, "key-mismatch left");
    CheckPairUnchanged(right, rightBefore, "key-mismatch right");
}

void TestTamperedScaleFailsLoudly() {
    [[maybe_unused]] EvalKeyCacheRestorer restorer;
    auto context = MakeContext();
    const auto keys = context->KeyGen();
    DoubleCKKS module(context);
    auto left = MakeReadyPair(context, keys.publicKey, module, 0.0);
    const auto right = MakeReadyPair(context, keys.publicKey, module, 0.03125);

    auto mutableHigh =
        std::const_pointer_cast<lbcrypto::CiphertextImpl<DCRTPoly>>(left.GetHigh());
    Check(mutableHigh != nullptr, "scale-tamper fixture high member is null");
    mutableHigh->SetScalingFactor(mutableHigh->GetScalingFactor() * 2.0);
    const auto leftBefore = SnapshotPair(left, "scale-tamper left");
    const auto rightBefore = SnapshotPair(right, "scale-tamper right");

    ClearEvalKeyCache();
    const auto emptyCache = SnapshotEvalKeyCache();
    CheckThrowsExactInvalidArgument(
        [&] { (void)module.Mult2(left, right); },
        "DoubleCKKS: pair high recorded scaling factor does not match its pair state",
        "tampered scale");
    CheckEvalKeyCacheMatches(emptyCache, "scale rejection evaluation-key cache");
    CheckPairUnchanged(left, leftBefore, "scale-tamper left");
    CheckPairUnchanged(right, rightBefore, "scale-tamper right");
}

void TestTamperedBasisFailsLoudly() {
    [[maybe_unused]] EvalKeyCacheRestorer restorer;
    auto context = MakeContext();
    const auto keys = context->KeyGen();
    DoubleCKKS module(context);
    auto left = MakeReadyPair(context, keys.publicKey, module, 0.0);
    const auto right = MakeReadyPair(context, keys.publicKey, module, 0.03125);

    auto mutableHigh =
        std::const_pointer_cast<lbcrypto::CiphertextImpl<DCRTPoly>>(left.GetHigh());
    Check(mutableHigh != nullptr, "basis-tamper fixture high member is null");
    auto elements = mutableHigh->GetElements();
    Check(!elements.empty(), "basis-tamper fixture has no RLWE components");
    for (auto& element : elements) {
        Check(element.GetAllElements().size() >= 2,
              "basis-tamper fixture has too few towers");
        element.DropLastElement();
    }
    mutableHigh->SetElements(std::move(elements));
    const auto leftBefore = SnapshotPair(left, "basis-tamper left");
    const auto rightBefore = SnapshotPair(right, "basis-tamper right");

    ClearEvalKeyCache();
    const auto emptyCache = SnapshotEvalKeyCache();
    CheckThrowsExactInvalidArgument(
        [&] { (void)module.Mult2(left, right); },
        "DoubleCKKS: pair high ordered RNS basis mismatch",
        "tampered ordered basis");
    CheckEvalKeyCacheMatches(emptyCache, "basis rejection evaluation-key cache");
    CheckPairUnchanged(left, leftBefore, "basis-tamper left");
    CheckPairUnchanged(right, rightBefore, "basis-tamper right");
}

void RunSelectedCase(const std::string& name) {
    if (name == "terminal_before_key") {
        TestTerminalInputsFailBeforeKeyAccess();
        return;
    }
    if (name == "mismatched_context") {
        TestMismatchedContextFailsLoudly();
        return;
    }
    if (name == "mismatched_key") {
        TestMismatchedKeyFailsLoudly();
        return;
    }
    if (name == "tampered_scale") {
        TestTamperedScaleFailsLoudly();
        return;
    }
    if (name == "tampered_basis") {
        TestTamperedBasisFailsLoudly();
        return;
    }
    throw TestFailure("unknown Mult2 validation case: " + name);
}

}  // namespace

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: mult2_validation_test "
                     "terminal_before_key|mismatched_context|mismatched_key|"
                     "tampered_scale|tampered_basis\n";
        return 2;
    }

    try {
        RunSelectedCase(argv[1]);
        lbcrypto::CryptoContextFactory<DCRTPoly>::ReleaseAllContexts();
        return 0;
    }
    catch (const TestFailure& failure) {
        std::cerr << "mult2_validation_test failure: " << failure.what() << '\n';
        return 1;
    }
    catch (const std::exception& exception) {
        std::cerr << "mult2_validation_test unexpected exception: " << exception.what() << '\n';
        return 1;
    }
}
