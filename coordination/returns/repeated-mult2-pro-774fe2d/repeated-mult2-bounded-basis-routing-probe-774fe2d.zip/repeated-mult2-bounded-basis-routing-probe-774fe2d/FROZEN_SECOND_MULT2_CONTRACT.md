# Frozen second-Mult2 contract

## Status

`contracts/SECOND_MULT2_EXACT_VECTORS.json` is the normative arithmetic contract for the first future GREEN repeated-operation implementation. It is frozen before any hosted execution. The Stage-1 executable in this package instead records the **current supported boundary**: the retained first-Mult2 high-precision oracle must pass unchanged, and the exact second call must reject with `DoubleCKKS: Tensor2 requires ReadyForFirstMult inputs`. That current-boundary observation must not be reported as a manufactured RED unless it is actually executed.

## Arithmetic sequence

For all 16 complex slots and each of four fresh keypairs:

```text
Z = Mult2(X, Y)
W = Mult2(Z, Z)
```

`X`, `Y`, `Z` and `W` are exact dyadic complex values represented as `n·2^-k`. Z and W are independently computed by integer/rational complex arithmetic, not by staged/direct ciphertext self-comparison. Slots 0 and 1 differ only through information below binary64 resolution in the original operands; both `Z0-Z1` and `W0-W1` are exact nonzero acceptance values. The contract also includes signs, real and complex values, zero, near-zero and bounded magnitudes.

## Frozen development configuration

- ring dimension 64; batch 16; multiplicative depth 9;
- scaling-modulus 50 bits, first modulus 55 bits;
- FIXEDMANUAL, HYBRID, CKKS complex, UNIFORM_TERNARY, HEStd_NotSet;
- input recombined logical scale exactly `2^100`; input noise-scale degree 2;
- four fresh keypairs per invocation; no reused cached key tag;
- exact ordered prime identities, roots, family index, local level and eval-key row basis must be checked.

This is a low-N diagnostic and cannot be relabeled as Section 6.3.

## Precision acceptance

Both stages freeze `max_slot_abs_error <= 2^-80`; equality is accepted. The value is not copied as a theorem. It is a bounded diagnostic target based on the supplied first-Mult2 observation (worst about `1.7e-27`, roughly nine bits below `2^-80`), the contract's sub-unit magnitudes, and one additional operation. This leaves a useful margin while remaining falsifiable. It is not a universal all-key Gaussian/headroom guarantee. A runtime miss is evidence requiring diagnosis, not permission to weaken the threshold after seeing the result.

The following are mandatory and independent:

1. exact lossless encoding of all operands without the stale binary64 fixture cache;
2. exact CRT/RLWE reconstruction for Z and W;
3. max error over all 16 slots at each stage;
4. exact distinguishing deltas at each stage;
5. input/key/context immutability;
6. ordered Q/root, family, key tag, key-row QP, local level and lifecycle progression;
7. rejection of every mismatched family/basis/tag/level/scale state.

## Scale and state

The machine contract fixes `Si=S(i-1)^2/(d*mi)` using actual prime integers. A ready pair is family-relative level 1; raised high is level 0; RS2 produces level 2 in the current family; rehoming creates a new level-1 object in the next family. OpenFHE's floating scaling-factor field and noise-scale degree are verified metadata, not substitutes for the exact factor ledger.

## Current versus future acceptance

- **Stage 1 package test:** first arithmetic stays GREEN; exact second-call rejection stays stable.
- **Stage 2 package probe:** context/key construction and active/full-basis relinearization route executes without any secret surviving setup.
- **Future semantic second-Mult2 test:** the exact JSON Z/W oracle and `<=2^-80` threshold turn GREEN without changing the contract.
