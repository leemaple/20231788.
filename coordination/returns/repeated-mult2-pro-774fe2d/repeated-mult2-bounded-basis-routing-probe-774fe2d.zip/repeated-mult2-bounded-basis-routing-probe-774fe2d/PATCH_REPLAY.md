# Verified patch replay

$ git apply --check /mnt/data/repeated-mult2-delivery-build/repeated-mult2-bounded-basis-routing-probe-774fe2d/patches/0001-freeze-current-second-mult2-boundary.patch

$ git apply /mnt/data/repeated-mult2-delivery-build/repeated-mult2-bounded-basis-routing-probe-774fe2d/patches/0001-freeze-current-second-mult2-boundary.patch

$ git apply --check /mnt/data/repeated-mult2-delivery-build/repeated-mult2-bounded-basis-routing-probe-774fe2d/patches/0002-add-immutable-basis-key-routing-probe.patch

$ git apply /mnt/data/repeated-mult2-delivery-build/repeated-mult2-bounded-basis-routing-probe-774fe2d/patches/0002-add-immutable-basis-key-routing-probe.patch


| Final file | Bytes | SHA-256 |
|---|---:|---|
| `CMakeLists.txt` | 13259 | `1325c9418c8e69e3a56272ff19997262586abe43a8535b42b9f352d8a859d12e` |
| `tests/repeated_mult2_second_contract_test.cpp` | 59250 | `65b11ef62675dea9777ff939ec100f7545646eff9624024e644578e79c352503` |
| `tests/repeated_mult2_basis_family_probe.cpp` | 17768 | `fbdc5190fc3a90658fdfe1e69cbeb6044be79d46d8dcdd186eb9f65410cdb7bb` |

Both patches apply in order and complete files match byte-for-byte. C++ compilation/runtime was not performed.
