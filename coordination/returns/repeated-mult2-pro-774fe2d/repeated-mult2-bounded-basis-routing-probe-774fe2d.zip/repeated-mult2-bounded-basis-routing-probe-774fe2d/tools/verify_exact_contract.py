#!/usr/bin/env python3
from __future__ import annotations
import json
import sys
from fractions import Fraction
from pathlib import Path


def f(x):
    return Fraction(int(x["n"]), 1 << int(x["k"]))


def c(slot):
    return f(slot["real"]), f(slot["imag"])


def mul(a, b):
    return a[0]*b[0] - a[1]*b[1], a[0]*b[1] + a[1]*b[0]


def main(path: str) -> int:
    doc = json.loads(Path(path).read_text(encoding="utf-8"))
    vectors = {name: [c(v) for v in values]
               for name, values in doc["vectors"].items()}
    assert len(vectors["X"]) == len(vectors["Y"]) == 16
    assert [mul(a, b) for a, b in zip(vectors["X"], vectors["Y"])] == vectors["Z"]
    assert [mul(a, a) for a in vectors["Z"]] == vectors["W"]
    dz = (vectors["Z"][0][0] - vectors["Z"][1][0],
          vectors["Z"][0][1] - vectors["Z"][1][1])
    dw = (vectors["W"][0][0] - vectors["W"][1][0],
          vectors["W"][0][1] - vectors["W"][1][1])
    expected_dz = c(doc["distinguishing_deltas"]["Z0_minus_Z1"])
    expected_dw = c(doc["distinguishing_deltas"]["W0_minus_W1"])
    assert dz == expected_dz and dw == expected_dw
    assert dz != (0, 0) and dw != (0, 0)
    print("EXACT_CONTRACT=PASS slots=16 stage1=exact stage2=exact distinguishing=exact")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else
                          "contracts/SECOND_MULT2_EXACT_VECTORS.json"))
