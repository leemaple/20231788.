# Immutable basis/key-routing probe acceptance

## Exact question

Can pristine OpenFHE 1.5.0 construct two immutable CKKS-RNS/HYBRID contexts `B0=[A0,d]` and `B1=[A1,d]`, generate family-local evaluation keys from one setup secret projected by actual prime/root identity, discard all private-key objects, clone an active ciphertext into B1 without mutating the source, and relinearize controlled nonzero three-component ciphertexts on both A1 and B1?

## Frozen acceptance

The focused test uses ring dimension 256 with `SPARSE_TERNARY` (normal public setup h=192), and passes only when all of the following hold:

- supplied generated B0 has at least five Q towers; B1 removes the first RS2-consumed q_l and retains the same q_div identity;
- ordered moduli and roots survive public ILDCRTParams/CryptoParameters/factory construction;
- different Q bases are not returned as the same context; equivalent-context interning is printed but not required;
- each family has `numPartQ=|Q|`, `numPerPartQ=1`, nonempty P and exact own `QP=Q||P`;
- P equality across families is printed as informational and never required;
- family-1 secret towers are selected by exact modulus/root identity from family 0 during setup;
- eval-key tags are distinct; A/B row counts equal family Q count; every row has exact family QP and evaluation format;
- all private-key objects leave scope before any evaluator-only relinearization;
- a level-2 active-basis controlled ciphertext in B0 is cloned to a fresh level-1 B1 ciphertext; source context/tag/level/elements remain exactly unchanged;
- B1 relinearizes controlled nonzero three-component ciphertexts on active A1 and full B1 to two components with exact context/tag/basis;
- contexts and key-row shapes remain unchanged after evaluation.

Any failed invariant is a probe RED. It decides the construction/key-routing prerequisite only; it is not a plaintext arithmetic or security oracle.

## Predicted observations

Source inspection predicts:

- different-basis context distinct: 1;
- alpha: 1;
- active and full relinearization: pass if public constructor/key routing assumptions are correct;
- source mutation: none;
- equivalent context interned: likely 1, but informational;
- P bases equal: unknown and informational.

No prediction is reported as an executed result.
