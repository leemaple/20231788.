// SPDX-License-Identifier: BSD-2-Clause
// Bounded pristine-OpenFHE public-API probe for immutable ordered-basis
// contexts and per-family HYBRID evaluation-key routing.  This is deliberately
// test-only: it does not claim semantic repeated-Mult2 correctness.

#include "openfhe.h"
#include "scheme/ckksrns/ckksrns-cryptoparameters.h"
#include "scheme/ckksrns/ckksrns-scheme.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace {

using namespace lbcrypto;
using DCRTParams = ILDCRTParams<DCRTPoly::Integer>;

[[noreturn]] void Fail(const std::string& message) {
    throw std::runtime_error(message);
}

void Require(bool condition, const std::string& message) {
    if (!condition) {
        Fail(message);
    }
}

std::vector<NativeInteger> OrderedModuli(const std::shared_ptr<DCRTParams>& params) {
    Require(static_cast<bool>(params), "null DCRT parameter object");
    std::vector<NativeInteger> result;
    result.reserve(params->GetParams().size());
    for (const auto& tower : params->GetParams()) {
        Require(static_cast<bool>(tower), "null native tower parameters");
        result.push_back(tower->GetModulus());
    }
    return result;
}

std::vector<NativeInteger> OrderedRoots(const std::shared_ptr<DCRTParams>& params) {
    Require(static_cast<bool>(params), "null DCRT parameter object");
    std::vector<NativeInteger> result;
    result.reserve(params->GetParams().size());
    for (const auto& tower : params->GetParams()) {
        Require(static_cast<bool>(tower), "null native tower parameters");
        result.push_back(tower->GetRootOfUnity());
    }
    return result;
}

bool OrderedBasisEquals(const std::shared_ptr<DCRTParams>& params,
                        const std::vector<NativeInteger>& moduli,
                        const std::vector<NativeInteger>& roots) {
    return OrderedModuli(params) == moduli && OrderedRoots(params) == roots;
}

struct FamilyContext {
    CryptoContext<DCRTPoly> context;
    std::shared_ptr<CryptoParametersCKKSRNS> parameters;
    std::vector<NativeInteger> qModuli;
    std::vector<NativeInteger> qRoots;
    std::vector<NativeInteger> pModuli;
    std::vector<NativeInteger> qpModuli;
};

FamilyContext MakeFamilyContext(
    const std::shared_ptr<CryptoParametersCKKSRNS>& seedParameters,
    usint cyclotomicOrder,
    const std::vector<NativeInteger>& qModuli,
    const std::vector<NativeInteger>& qRoots) {
    Require(static_cast<bool>(seedParameters), "null seed crypto parameters");
    Require(qModuli.size() == qRoots.size(), "modulus/root count mismatch");
    Require(qModuli.size() >= 3U, "probe family requires at least three Q towers");

    auto elementParameters =
        std::make_shared<DCRTParams>(cyclotomicOrder, qModuli, qRoots);

    // All parameters are explicit.  HEStd_NotSet is intentional because this
    // diagnostic manually supplies Q and is not a security-validation path.
    auto cryptoParameters = std::make_shared<CryptoParametersCKKSRNS>(
        elementParameters,
        seedParameters->GetEncodingParams(),
        seedParameters->GetDistributionParameter(),
        seedParameters->GetAssuranceMeasure(),
        HEStd_NotSet,
        seedParameters->GetDigitSize(),
        SPARSE_TERNARY,
        seedParameters->GetMaxRelinSkDeg(),
        HYBRID,
        FIXEDMANUAL,
        STANDARD,
        HPS,
        INDCPA);

    // numPartQ == |Q| makes alpha == 1.  It is the per-family active row
    // count, not a silent claim that the paper's initial dnum=11 changed.
    cryptoParameters->PrecomputeCRTTables(
        HYBRID,
        FIXEDMANUAL,
        STANDARD,
        HPS,
        static_cast<uint32_t>(qModuli.size()),
        60U,
        0U);

    auto scheme = std::make_shared<SchemeCKKSRNS>();
    // Enable(KEYSWITCH) does not select an implementation.  Do it explicitly
    // before factory registration.
    scheme->SetKeySwitchingTechnique(HYBRID);

    auto context = CryptoContextFactory<DCRTPoly>::GetContext(
        cryptoParameters, scheme);
    Require(static_cast<bool>(context), "factory returned a null context");
    context->Enable(PKE);
    context->Enable(KEYSWITCH);
    context->Enable(LEVELEDSHE);

    Require(OrderedBasisEquals(
                cryptoParameters->GetElementParams(), qModuli, qRoots),
            "factory context changed ordered Q basis");
    Require(cryptoParameters->GetNumPartQ() == qModuli.size(),
            "unexpected HYBRID partition count");
    Require(cryptoParameters->GetNumPerPartQ() == 1U,
            "probe requires one Q tower per HYBRID partition");

    const auto pModuli = OrderedModuli(cryptoParameters->GetParamsP());
    const auto qpModuli = OrderedModuli(cryptoParameters->GetParamsQP());
    Require(!pModuli.empty(), "HYBRID precompute produced an empty P basis");
    std::vector<NativeInteger> expectedQP = qModuli;
    expectedQP.insert(expectedQP.end(), pModuli.begin(), pModuli.end());
    Require(qpModuli == expectedQP, "QP is not the ordered concatenation Q || P");

    return FamilyContext{context, cryptoParameters, qModuli, qRoots,
                         pModuli, qpModuli};
}

DCRTPoly ProjectSecretByPrimeIdentity(
    const DCRTPoly& sourceSecret,
    const std::shared_ptr<DCRTParams>& targetParameters) {
    const auto& sourceTowers = sourceSecret.GetAllElements();
    std::vector<NativePoly> selected;
    selected.reserve(targetParameters->GetParams().size());

    for (const auto& targetTower : targetParameters->GetParams()) {
        const auto targetModulus = targetTower->GetModulus();
        const auto found = std::find_if(
            sourceTowers.begin(), sourceTowers.end(),
            [&targetModulus](const NativePoly& candidate) {
                return candidate.GetModulus() == targetModulus;
            });
        Require(found != sourceTowers.end(),
                "target family contains a prime absent from the setup secret");
        Require(found->GetParams()->GetRootOfUnity() ==
                    targetTower->GetRootOfUnity(),
                "same modulus has a different root of unity");
        selected.push_back(*found);
    }

    DCRTPoly projected(selected);
    Require(OrderedBasisEquals(projected.GetParams(),
                               OrderedModuli(targetParameters),
                               OrderedRoots(targetParameters)),
            "projected secret has the wrong ordered basis");
    return projected;
}

void RequireUnusedEvalMultTag(const std::string& tag) {
    const auto& allKeys = CryptoContextImpl<DCRTPoly>::GetAllEvalMultKeys();
    Require(allKeys.find(tag) == allKeys.end(),
            "evaluation-multiplication key tag collision before setup");
}

std::vector<EvalKey<DCRTPoly>> EvalMultKeysForTag(const std::string& tag) {
    const auto& allKeys = CryptoContextImpl<DCRTPoly>::GetAllEvalMultKeys();
    const auto found = allKeys.find(tag);
    Require(found != allKeys.end(), "no evaluation-multiplication key for family tag");
    Require(!found->second.empty(), "empty evaluation-multiplication key vector");
    return found->second;
}

void ValidateHybridKeyRows(const FamilyContext& family,
                           const std::string& tag) {
    const auto keys = EvalMultKeysForTag(tag);
    const auto relin =
        std::dynamic_pointer_cast<EvalKeyRelinImpl<DCRTPoly>>(keys.front());
    Require(static_cast<bool>(relin), "evaluation key is not EvalKeyRelinImpl");
    Require(relin->GetCryptoContext() == family.context,
            "evaluation key is bound to the wrong family context");
    Require(relin->GetKeyTag() == tag,
            "evaluation key tag does not match the family tag");

    const auto& a = relin->GetAVector();
    const auto& b = relin->GetBVector();
    Require(a.size() == family.qModuli.size(),
            "HYBRID A row count does not equal alpha=1 family Q count");
    Require(b.size() == family.qModuli.size(),
            "HYBRID B row count does not equal alpha=1 family Q count");
    for (std::size_t i = 0; i < a.size(); ++i) {
        Require(OrderedModuli(a[i].GetParams()) == family.qpModuli,
                "HYBRID A row has the wrong ordered QP basis");
        Require(OrderedModuli(b[i].GetParams()) == family.qpModuli,
                "HYBRID B row has the wrong ordered QP basis");
        Require(a[i].GetFormat() == Format::EVALUATION,
                "HYBRID A row is not in evaluation format");
        Require(b[i].GetFormat() == Format::EVALUATION,
                "HYBRID B row is not in evaluation format");
    }
}

Ciphertext<DCRTPoly> MakeControlledTensor(
    const CryptoContext<DCRTPoly>& context,
    const std::string& tag,
    const std::shared_ptr<DCRTParams>& elementParameters,
    uint32_t level) {
    DCRTPoly::DugType dug;
    std::vector<DCRTPoly> elements;
    elements.reserve(3U);
    for (std::size_t i = 0; i < 3U; ++i) {
        elements.emplace_back(dug, elementParameters, Format::EVALUATION);
    }
    auto tensor = std::make_shared<CiphertextImpl<DCRTPoly>>(
        context, tag, CKKS_PACKED_ENCODING);
    tensor->SetElements(std::move(elements));
    tensor->SetLevel(level);
    tensor->SetNoiseScaleDeg(2U);
    tensor->SetScalingFactor(std::ldexp(1.0, 100));
    tensor->SetSlots(8U);
    return tensor;
}

Ciphertext<DCRTPoly> RehomeControlledCiphertext(
    ConstCiphertext<DCRTPoly> source,
    const CryptoContext<DCRTPoly>& targetContext,
    const std::string& targetTag,
    uint32_t targetLevel) {
    Require(static_cast<bool>(source), "cannot rehome a null ciphertext");
    auto result = std::make_shared<CiphertextImpl<DCRTPoly>>(
        targetContext, targetTag, source->GetEncodingType());
    result->SetElements(source->GetElements());
    result->SetLevel(targetLevel);
    result->SetNoiseScaleDeg(source->GetNoiseScaleDeg());
    result->SetScalingFactor(source->GetScalingFactor());
    result->SetSlots(source->GetSlots());
    return result;
}

void RequireCiphertextBasis(ConstCiphertext<DCRTPoly> ciphertext,
                            const std::vector<NativeInteger>& expected,
                            std::size_t expectedComponents,
                            const CryptoContext<DCRTPoly>& expectedContext,
                            const std::string& expectedTag) {
    Require(static_cast<bool>(ciphertext), "null ciphertext result");
    Require(ciphertext->GetCryptoContext() == expectedContext,
            "ciphertext result has the wrong context");
    Require(ciphertext->GetKeyTag() == expectedTag,
            "ciphertext result has the wrong key tag");
    Require(ciphertext->GetElements().size() == expectedComponents,
            "ciphertext result has the wrong component count");
    for (const auto& component : ciphertext->GetElements()) {
        Require(OrderedModuli(component.GetParams()) == expected,
                "ciphertext component has the wrong ordered basis");
    }
}

int RunProbe() {
    CCParams<CryptoContextCKKSRNS> seedConfig;
    seedConfig.SetRingDim(256U);
    seedConfig.SetBatchSize(8U);
    seedConfig.SetMultiplicativeDepth(5U);
    seedConfig.SetScalingModSize(50U);
    seedConfig.SetFirstModSize(55U);
    seedConfig.SetScalingTechnique(FIXEDMANUAL);
    seedConfig.SetKeySwitchTechnique(HYBRID);
    seedConfig.SetNumLargeDigits(3U);
    seedConfig.SetSecretKeyDist(SPARSE_TERNARY);
    seedConfig.SetSecurityLevel(HEStd_NotSet);

    const auto seedContext = GenCryptoContext(seedConfig);
    Require(static_cast<bool>(seedContext), "failed to generate seed context");
    const auto seedParameters =
        std::dynamic_pointer_cast<CryptoParametersCKKSRNS>(
            seedContext->GetCryptoParameters());
    Require(static_cast<bool>(seedParameters),
            "seed context is not CryptoParametersCKKSRNS");

    const auto seedQ = seedParameters->GetElementParams();
    const auto fullModuli = OrderedModuli(seedQ);
    const auto fullRoots = OrderedRoots(seedQ);
    Require(fullModuli.size() >= 5U,
            "seed context did not provide enough Q towers for two families");

    // B0 = [A0, q_div].  B1 removes the q_l consumed by the first RS2 but
    // retains the same actual trailing q_div prime by identity.
    std::vector<NativeInteger> nextModuli(fullModuli.begin(), fullModuli.end() - 2);
    std::vector<NativeInteger> nextRoots(fullRoots.begin(), fullRoots.end() - 2);
    nextModuli.push_back(fullModuli.back());
    nextRoots.push_back(fullRoots.back());

    const auto family0 = MakeFamilyContext(
        seedParameters, seedQ->GetCyclotomicOrder(), fullModuli, fullRoots);
    const auto family1 = MakeFamilyContext(
        seedParameters, seedQ->GetCyclotomicOrder(), nextModuli, nextRoots);

    Require(family0.context != family1.context,
            "different ordered Q bases were interned as one context");

    const auto equivalentFamily1 = MakeFamilyContext(
        seedParameters, seedQ->GetCyclotomicOrder(), nextModuli, nextRoots);
    const bool equivalentWasInterned =
        equivalentFamily1.context == family1.context;
    const bool pBasesEqual = family0.pModuli == family1.pModuli;

    std::string family0Tag;
    std::string family1Tag;
    {
        auto family0Keys = family0.context->KeyGen();
        Require(family0Keys.good(), "family-0 KeyGen failed");
        family0Tag = family0Keys.secretKey->GetKeyTag();
        RequireUnusedEvalMultTag(family0Tag);
        family0.context->EvalMultKeyGen(family0Keys.secretKey);

        family1Tag = family0Tag + "::repeated-mult2-family-1";
        RequireUnusedEvalMultTag(family1Tag);
        auto family1Secret =
            std::make_shared<PrivateKeyImpl<DCRTPoly>>(family1.context);
        family1Secret->SetKeyTag(family1Tag);
        family1Secret->SetPrivateElement(ProjectSecretByPrimeIdentity(
            family0Keys.secretKey->GetPrivateElement(),
            family1.parameters->GetElementParams()));
        family1.context->EvalMultKeyGen(family1Secret);

        ValidateHybridKeyRows(family0, family0Tag);
        ValidateHybridKeyRows(family1, family1Tag);
    }
    // No PrivateKey survives this scope.  Everything below is evaluator-only.

    // A1 is the active pair basis after the first RS2: B1 without q_div.
    std::vector<NativeInteger> activeModuli(
        nextModuli.begin(), nextModuli.end() - 1);
    std::vector<NativeInteger> activeRoots(
        nextRoots.begin(), nextRoots.end() - 1);
    auto activeParameters = std::make_shared<DCRTParams>(
        seedQ->GetCyclotomicOrder(), activeModuli, activeRoots);

    auto sourceAtFamily0Level2 = MakeControlledTensor(
        family0.context, family0Tag, activeParameters, 2U);
    const auto sourceElementsBefore = sourceAtFamily0Level2->GetElements();
    const auto sourceLevelBefore = sourceAtFamily0Level2->GetLevel();
    const auto sourceTagBefore = sourceAtFamily0Level2->GetKeyTag();
    const auto sourceContextBefore = sourceAtFamily0Level2->GetCryptoContext();

    auto rehomedAtFamily1Level1 = RehomeControlledCiphertext(
        sourceAtFamily0Level2, family1.context, family1Tag, 1U);
    RequireCiphertextBasis(rehomedAtFamily1Level1, activeModuli, 3U,
                           family1.context, family1Tag);
    Require(rehomedAtFamily1Level1->GetLevel() == 1U,
            "rehomed active ciphertext is not at family-relative level 1");

    const auto activeRelinearized =
        family1.context->Relinearize(rehomedAtFamily1Level1);
    RequireCiphertextBasis(activeRelinearized, activeModuli, 2U,
                           family1.context, family1Tag);

    const auto fullTensor = MakeControlledTensor(
        family1.context, family1Tag,
        family1.parameters->GetElementParams(), 0U);
    const auto fullRelinearized = family1.context->Relinearize(fullTensor);
    RequireCiphertextBasis(fullRelinearized, nextModuli, 2U,
                           family1.context, family1Tag);

    Require(sourceAtFamily0Level2->GetLevel() == sourceLevelBefore,
            "rehoming or family-1 evaluation mutated source level");
    Require(sourceAtFamily0Level2->GetKeyTag() == sourceTagBefore,
            "rehoming or family-1 evaluation mutated source tag");
    Require(sourceAtFamily0Level2->GetCryptoContext() == sourceContextBefore,
            "rehoming or family-1 evaluation mutated source context");
    Require(sourceAtFamily0Level2->GetElements() == sourceElementsBefore,
            "rehoming or family-1 evaluation mutated source elements");

    // Re-check immutable table/key shape after evaluator operations.
    Require(OrderedModuli(family0.parameters->GetElementParams()) == fullModuli,
            "family-0 Q basis mutated");
    Require(OrderedModuli(family1.parameters->GetElementParams()) == nextModuli,
            "family-1 Q basis mutated");
    ValidateHybridKeyRows(family0, family0Tag);
    ValidateHybridKeyRows(family1, family1Tag);

    std::cout << "OBS different_basis_context_distinct=1\n";
    std::cout << "OBS equivalent_context_interned="
              << (equivalentWasInterned ? 1 : 0) << "\n";
    std::cout << "OBS p_bases_equal=" << (pBasesEqual ? 1 : 0)
              << " (informational_only)\n";
    std::cout << "OBS family0_q_towers=" << family0.qModuli.size() << "\n";
    std::cout << "OBS family1_q_towers=" << family1.qModuli.size() << "\n";
    std::cout << "OBS alpha=1\n";
    std::cout << "OBS active_and_full_relinearize=pass\n";
    std::cout << "OBS source_mutation=none\n";
    std::cout << "PROBE_RESULT=PASS\n";
    return 0;
}

}  // namespace

int main() {
    try {
        return RunProbe();
    }
    catch (const std::exception& error) {
        std::cerr << "PROBE_RESULT=FAIL: " << error.what() << '\n';
        return 1;
    }
}
