# SOURCE CLAIM / TEST LEDGER

All citations below are line ranges computed from the exact files in the supplied archive. The upstream tree is pinned to OpenFHE `df495ba2e91739a6dc8f1de254fc5a41155ce504`; project source is `774fe2dcfca47d7a08cab9c04b29c430e354cf9f`.

| ID | Claim resolved | Exact supplied source | Evidence / test disposition |
|---|---|---|---|
| S1 | Current Relin2 appends the single constructor-bound trailing tower and then validates against that original full basis. | `project/src/double_ckks.cpp:L508-L524` | Static: supports the stated second-operation mismatch; runtime not required. |
| S2 | Current Tensor2 rejects any input not in the first-multiplication lifecycle. | `project/src/double_ckks.cpp:L762-L772` | Static: exact current boundary used by Stage 1. |
| S3 | HYBRID precompute rejects numPartQ greater than sizeQ and constructs contiguous partitions by index. | `official-full/src/pke/lib/schemerns/rns-cryptoparameters.cpp:L402-L418` | Static: sizeQ<=10 with numPartQ=11 cannot construct. |
| S4 | HYBRID P is generated from auxBits while Q collisions are skipped; no P-vector argument exists. | `official-full/src/pke/lib/schemerns/rns-cryptoparameters.cpp:L140-L165` | Static: cross-family P equality is not automatic and is not required by the selected no-key-sharing route. |
| S5 | QP is assembled in ordered Q-then-P form. | `official-full/src/pke/lib/schemerns/rns-cryptoparameters.cpp:L177-L190` | Static: every family key row must match its own QP. |
| S6 | HYBRID decomposition derives the active digit count from current sizeQl and the context partition size. | `official-full/src/pke/lib/keyswitch/keyswitch-hybrid.cpp:L323-L339` | Static: alpha=1 can retain one-prime digits while row count shrinks with the immutable family. |
| S7 | HYBRID key switching indexes context complement tables and evaluation-key rows. | `official-full/src/pke/lib/keyswitch/keyswitch-hybrid.cpp:L354-L384` | Static: a single original-context key is not basis-agnostic. |
| S8 | ILDCRTParams has a public constructor accepting explicit ordered moduli and roots. | `official-full/src/core/include/lattice/hal/default/ildcrtparams.h:L125-L139` | Compile/runtime probe: MakeFamilyContext. |
| S9 | CryptoParametersCKKSRNS exposes public construction and PrecomputeCRTTables. | `official-full/src/pke/include/scheme/ckksrns/ckksrns-cryptoparameters.h:L56-L96` | Compile/runtime probe: MakeFamilyContext. |
| S10 | The RNS scheme exposes explicit key-switch implementation selection. | `official-full/src/pke/include/schemerns/rns-scheme.h:L63-L77` | Compile/runtime probe explicitly selects HYBRID. |
| S11 | CKKS Enable(KEYSWITCH) does not itself instantiate/select key switching. | `official-full/src/pke/lib/scheme/ckksrns/ckksrns-scheme.cpp:L46-L58` | Static: explicit setter is mandatory. |
| S12 | CryptoContextFactory searches existing contexts for parameter/scheme equivalence before creating one. | `official-full/src/pke/lib/cryptocontextfactory.cpp:L62-L91` | Runtime probe records equivalent-context interning and rejects different-basis aliasing. |
| S13 | FIXEDMANUAL records a nominal 2^p scaling factor. | `official-full/src/pke/lib/scheme/ckksrns/ckksrns-cryptoparameters.cpp:L46-L84` | Static: exact project-owned rational scale remains authoritative. |
| S14 | FLEXIBLE scaling enforces a ratio interval and is not a universal workaround for 40/60 ordering. | `official-full/src/pke/lib/scheme/ckksrns/ckksrns-cryptoparameters.cpp:L137-L150` | Static: selected route stays FIXEDMANUAL. |
| S15 | Normal sparse KeyGen uses a hard-coded h=192. | `official-full/src/pke/lib/schemebase/base-pke.cpp:L62-L80` | Static: low-N probe is not the paper h=128 setup. |
| S16 | The low-level ternary sampler accepts an explicit h. | `official-full/src/core/include/math/ternaryuniformgenerator-impl.h:L51-L72` | Static: capability exists, but keypair relation remains a separate executable gate. |
| S17 | DCRTPoly exposes ternary construction with h. | `official-full/src/core/include/lattice/hal/default/dcrtpoly-impl.h:L174-L191` | Static: not by itself a complete h=128 KeyGen path. |
| S18 | PrivateKey exposes replacement of the private element. | `official-full/src/pke/include/key/privatekey.h:L134-L147` | Static: setter-only replacement after other keys exist is rejected by design. |
| S19 | Evaluation multiplication keys are globally stored by key tag. | `official-full/src/pke/lib/cryptocontext.cpp:L81-L105` | Probe uses unique tags and validates rows before evaluator-only scope. |
| S20 | RNS PKE exposes EncryptZeroCore with a supplied private key. | `official-full/src/pke/lib/schemerns/rns-pke.cpp:L39-L64` | Static only: explicitly not endorsed until an h=128 keypair probe proves all relations. |
| S21 | CryptoObject exposes context retrieval but no public context mutator. | `official-full/src/pke/include/cryptoobject.h:L78-L111` | Static: rehoming must construct a new ciphertext rather than mutate the source object. |
| S22 | Ciphertext has public context/tag constructors and element setters. | `official-full/src/pke/include/ciphertext.h:L67-L92` | Compile/runtime probe: controlled clone into family 1. |
| S23 | Normal CKKS parameter generation invokes security/ring-dimension calculations. | `official-full/src/pke/lib/scheme/ckksrns/ckksrns-parametergeneration.cpp:L114-L205` | Static: manual context creation bypasses this generator; no security claim. |

## Paper anchors

The supplied paper text is independently line-indexed in the archive. Definition 4.7 defines `Mult2 = RS2 ∘ Relin2 ∘ Tensor2`; Section 6.3 specifies eight repeated squarings without the Section 6.2 intermediate refresh, and Table 3 gives the `t=2` `N=2^15`, `dnum=11`, `h=128`, `Base 50×2`, `Mult 60×8`, `Div 40`, `P 60` configuration. The exact paper ranges are recorded in `SOURCE_LINE_INDEX.json`, generated from the supplied bytes rather than recalled from another conversation.
