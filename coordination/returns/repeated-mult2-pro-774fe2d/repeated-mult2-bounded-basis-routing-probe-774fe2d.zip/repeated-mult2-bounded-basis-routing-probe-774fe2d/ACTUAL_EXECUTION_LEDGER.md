# Actual execution ledger

| Item | Status in this environment | Exact result / boundary |
|---|---|---|
| Supplied ZIP size/SHA-256 | **RUN / PASS** | `1451817` bytes; `efc96137d3412bae57099b6e2f7f85a96bd175b4dd810b587083e1e3d324587d` |
| ZIP path/duplicate/symlink/CRC safety | **RUN / PASS** | 156 regular members; no duplicates, unsafe paths or symlinks; every member streamed through CRC verification |
| Non-self manifest closure | **RUN / PASS** | 155 entries; exact path, size and SHA-256 closure |
| SOURCE-PROVENANCE identity | **RUN / PASS** | source `774fe2dcfca47d7a08cab9c04b29c430e354cf9f`; tested production `47907783a6141d0174da79eae264d779fc598f28`; OpenFHE pin `df495ba2e91739a6dc8f1de254fc5a41155ce504` |
| Supplied project Git-blob identities | **RUN / PASS** | 81 project records checked in the prior source-audit phase; no mismatch |
| Supplied full-path upstream identities | **RUN / PASS** | 53 additional official records checked in the prior source-audit phase; no mismatch |
| Exact vector/oracle generation | **RUN / PASS** | Python `Fraction` generation; 16 Z products, 16 W squares and two exact distinguishing deltas |
| Independent exact contract verifier | **RUN / PASS** | See `evidence/verify_exact_contract.txt` |
| Stage-1 patch apply/check | **RUN / PASS** | replayed on a clean copy of current project |
| Stage-2 patch apply/check | **RUN / PASS** | replayed after Stage 1 |
| Complete-file equality after replay | **RUN / PASS** | every changed/new file matches `complete/project/` byte-for-byte |
| Existing CTest binding preservation | **RUN / PASS** | first 55 name/command pairs unchanged; rows 56–57 additive |
| C++ configure/build | **NOT RUN** | No pristine OpenFHE install was available in this environment; no compile claim |
| Stage-1 CTest runtime | **NOT RUN** | Source predicts the exact current rejection, but no runtime RED/GREEN is claimed |
| Stage-2 API probe runtime | **NOT RUN** | Predicted observations are frozen in `PROBE_ACCEPTANCE.md`; no result claimed |
| Linux/Windows GitHub Actions | **NOT RUN** | No network/account/credential, dispatch, push or external message operation performed |
| h=128 setup | **NOT RUN / UNRESOLVED** | normal public sparse KeyGen is h=192; complete matching h=128 keypair/key-family gate remains |
| Semantic second Mult2 | **NOT IMPLEMENTED** | exact future contract frozen; this package is a bounded probe |
| Eight squarings / 1000 trials / performance | **NOT RUN** | no paper-goal claim |
| Security validation | **NOT RUN** | manual contexts and related-key family require separate analysis |

## Supplied hosted evidence

The first-Mult2 Linux/Windows results described in TASK.md are treated as supplied, source-associated evidence only. They are not executions performed here and are not extended to the second operation.
