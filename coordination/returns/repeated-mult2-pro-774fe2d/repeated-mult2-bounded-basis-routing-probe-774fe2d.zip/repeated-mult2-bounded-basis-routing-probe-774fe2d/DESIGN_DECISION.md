# DESIGN DECISION: immutable ordered-basis/key families

## Terminal choice

**Choose per-step immutable contexts and per-family HYBRID evaluation keys. Deliver a bounded construction/key-routing probe now; do not claim a complete second-Mult2 production patch until that probe and the h=128 setup gate execute on pristine OpenFHE 1.5.0.**

The route keeps the existing public `Tensor2`, `Relin2`, `RS2`, `Mult2`, Add/Sub and pair representation. It adds only project-owned repeated-operation state and setup/routing around those seams after the probe is GREEN. It never decrypts, re-encrypts, bootstraps, or accesses a secret in evaluator operations.

## Why the obvious shortcuts are wrong

After the first RS2, a representative original basis `B0=[q0,q1,q2,q3,d]` has active pair basis `A1=[q0,q1,q2]`. The next high raise must use `B1=[q0,q1,q2,d]`; this is not the original prefix `[q0,q1,q2,q3]`. Current Relin2 appends the constructor-bound trailing tower and validates against the original full basis. HYBRID then consumes partition/complement tables and evaluation-key rows by family-local index. Therefore guard removal, setting level 0, changing only `m_params`, or retagging under the original key cannot establish the required algebra or table/key identity.

## Minimal family model

Let `d` be the actual trailing Div prime and let `m1..m8` be the actual Mult primes in the order consumed by RS2 (right to left). For the paper ordering:

```text
B0 = [Base50_0, Base50_1, Mult60_1, ..., Mult60_8, d40]
Ai = Bi without d40
Bi+1 = Ai without its trailing mi, followed by the same d40
```

There are eight operation families `B0..B7`; `B8=[Base50_0,Base50_1,d40]` is the post-eight terminal/decryption routing family. Every `Bi` is immutable and owns:

- exact ordered Q moduli and roots;
- a `CryptoParametersCKKSRNS` constructed for that Q;
- its own precomputed P, QP, partition and complement tables;
- an explicitly selected HYBRID `SchemeCKKSRNS`;
- a unique key tag and evaluation-multiplication key rows generated for that context;
- a parameter fingerprint checked after factory lookup, because equivalent contexts may be interned.

No eval key or QP row is shared between families. Equivalent context interning is harmless only when the full fingerprint is equal; pointer allocation is never treated as identity evidence.

## dnum and active partitions

The paper's initial `dnum=11` means one-prime HYBRID digits for the eleven-prime full Q (`alpha=ceil(11/11)=1`). Pristine `PrecomputeCRTTables` rejects `numPartQ=11` once a nonempty family has ten or fewer Q towers. For family `Bi`, set `numPartQ=|Bi|`; this keeps `alpha=1` and therefore preserves the one-prime decomposition convention while reducing only the number of rows that physically exist at that family.

This is a concrete implementation of **initial dnum 11 plus per-level active row count**, not a claim that the paper's initial parameter changed. It must nevertheless be disclosed as an OpenFHE context-family realization and empirically compared against the full paper configuration; it is not silently relabeled as the paper's own implementation detail.

## P requirements

OpenFHE generates P from `auxBits` and skips collisions with that family's Q; it does not accept an explicit P vector. Thus P equality across families is not automatic. The chosen route does not require equality:

- each family key is generated against that family's own QP;
- each family relinearization uses only its own tables/key rows;
- pair ciphertexts carried between operations contain Q towers, not P towers;
- no evaluation key is shared or projected across P bases.

The required invariant is **within-family exact agreement** among ordered Q, generated P, QP, complement tables and every key row. The probe reports cross-family P equality only as an observation. Any future optimization that shares P-dependent material would need a new contract and proof/test.

## Client setup and evaluator boundary

1. Construct/register `B0` through `CryptoContextFactory`; explicitly select HYBRID before enabling features.
2. Generate the initial public/secret keypair in `B0`. The public key is used only for input encryption.
3. During client setup, project the same secret polynomial to each `Bi` by exact prime/root identity and generate the family-local eval-multiplication key. Use unique tags and reject any existing cache collision.
4. Validate each key row against its family's exact QP, then destroy all family private-key objects.
5. Give the evaluator only immutable family contexts, public metadata, ciphertexts and eval keys.
6. After each RS2, clone the two Q-basis components into a new ciphertext object bound to `Bi+1`, set the family-relative level to 1 and its matching tag, and preserve the exact logical-scale state. Never mutate the caller input or a shared context/key.
7. For final decryption, clone the terminal active-prefix ciphertext back to `B0` with its absolute level/tag; the coefficients remain on an original-Q prefix and the client owns the matching `B0` secret.

The current probe uses `SPARSE_TERNARY` at ring dimension 256, so normal public KeyGen takes its hard-coded `h=192` branch, only to decide the context/key-routing mechanism. It intentionally does not solve the paper's `h=128` root keypair. A setter-only secret replacement is invalid because the public key and all eval keys must be related to exactly the same secret. The separate gate must construct the entire matching key family from an h=128 root secret before any key material is cached. `PREMode=INDCPA` is fixed for this route; no PRE operation is used.

## State and mutation model for the eventual minimal production patch

Add two explicit project-owned fields, not a generic backend abstraction:

```text
PairState.familyIndex       // 0..8
PairState.logicalScale      // exact factor ledger, not double metadata
```

A ready pair is at family-relative level 1 on `Ai`. During one Mult2, the raised high path is at level 0 on `Bi`; the low path remains at level 1. RS2 returns `Ai+1` at level 2 in `Bi`; a fresh clone rehomes it to level 1 in `Bi+1`. `noiseScaleDeg` and OpenFHE `scalingFactor` are checked/local metadata, while `logicalScale` is the authority. Invalid family, basis, root, tag, key-row, level, lifecycle and scale combinations remain rejected.

No existing context, ciphertext input or key object is mutated. Setup may register immutable contexts/keys once; evaluator calls only read them and construct fresh outputs.

## Exact scale progression

Let `S0=2^100` be the recombined logical scale, `d` the actual Div prime, and `mi` the actual Mult prime dropped by RS2 operation `i`:

```text
Si = S(i-1)^2 / (d * mi)
S1 = 2^200 / (d*m1)
S2 = 2^400 / (d^3*m1^2*m2)
S8 = 2^25600 / (d^255*m1^128*m2^64*m3^32*m4^16*m5^8*m6^4*m7^2*m8)
```

The factor ledger computes this exactly. FIXEDMANUAL's nominal metadata uses powers of `2^p`, but the arithmetic drops actual primes; `SetScalingFactor` alone cannot change the physical polynomial scale. FLEXIBLEAUTO is rejected as a shortcut because the 40/60 ordering can violate its ratio check and it still would not repair context/key identity.

## Div40/Mult60 capacity

The route does not dead-end before eight operations: `d40` is always the actual last tower of each `Bi`, while each RS2 consumes exactly the trailing active `m60`. After eight operations, the two Base50 towers remain. The low-N probe is homogeneous and diagnostic only; paper-ordered 50/60/40 prime identities and the exact scale recurrence are mandatory at the next gates. Section 6.2's separate recombine/decompose refresh is neither inserted nor used as a success condition.

## Security boundary

Manual context construction bypasses normal parameter-generation security checks. `HEStd_NotSet`, or merely storing `HEStd_128_classic`, is not validation. The eventual report must disclose actual Q/P, `h=128` distribution, same-secret related-key family, key tags and all exposed eval material. No h-aware estimator or security proof was run, so no 128-bit security claim is made by this package.
