# Next empirical gates

No gate below may be skipped or relabeled. A later gate may reuse artifacts from an earlier GREEN gate only when the source/parameter/key association remains exact.

## G0 — pristine API compile and construction probe

Apply both patches on source `774fe2d…`, build Debug with warnings as errors against pristine OpenFHE 1.5.0 `df495ba…`, build the five existing explicit API targets plus both new targets, then run the two focused CTests and the full suite. Record exact compiler, platform, target commands, context fingerprints, ordered Q/P/QP, tags, row counts, and probe observations.

Acceptance: all 55 old bindings unchanged and passing; current-boundary test reports the exact rejection; basis-family probe passes active and full relinearization with no source mutation. P equality is informational only. A compile error is an API-contract RED, not evidence against the design mathematics.

## G1 — asymmetric ordered-Q setup

Replace the homogeneous generated seed only in a test branch with explicit ordered identities corresponding to Base50×2, at least two Mult60 towers and trailing Div40. Build `B0` and `B1`, verify roots and actual prime identities, each family's own generated P/QP and HYBRID rows, secret projection on overlap, distinct tags, and final clone back to the B0 absolute level.

Acceptance: no 40/60 ratio shortcut; exact factor ledger agrees with actual primes; no context/key/table mutation; no private key survives setup.

## G2 — semantic second Mult2

Implement the minimal project-owned family index/exact-scale state and routing adapter. Run `contracts/SECOND_MULT2_EXACT_VECTORS.json` with four fresh keys. Independently reconstruct and compare Z and W, all slots and both distinguishing deltas, at `<=2^-80`. Add invalid-family/basis/root/tag/row/level/scale tests. Direct-versus-staged ciphertext comparison may be logged only as wiring evidence.

Acceptance: contract is unchanged from this package; no decryption or secret is used by evaluator operations; production uses a lossless codec not the current binary64 cache.

## G3 — h=128 complete setup family

At N>=128, construct the root secret with exactly h=128 and construct a matching B0 public key and every family eval key before cache exposure. Verify algebraic relationships by encryption/decryption and repeated evaluation; prove no h192 key material or stale tag entry survives. Freeze PREMode and all key-generation randomness/sample counts.

Acceptance: changing only the private-key object is forbidden. The entire public/eval key family must match the same h=128 secret. This is functional evidence, not security validation.

## G4 — eight ordered squarings at diagnostic N

Use Base50×2, Mult60×8, Div40, P60 and family sequence B0..B8. Execute eight squarings with exact oracles and exact `S8` factor ledger. Check that no intermediate Section 6.2 refresh is invoked and no family runs out of active Mult towers.

Acceptance: all eight lifecycle transitions, final original-prefix routing and decryption pass; thresholds are frozen before execution and reported per stage.

## G5 — paper Section 6.3 reproduction

Use N=2^15, h=128, initial dnum=11/alpha=1, auxiliary P60, Base50×2, Mult60×8, Div40, logical input scale 2^100, eight repeated squarings and 1000 executions. Report exact hardware/software, key generation, warm-up, timing aggregation, failures, every precision sample or committed raw ledger, and average precision.

Acceptance: compare honestly with the paper's approximately 81.8-bit average; do not tune exclusions/thresholds post hoc. A low-N result is never substituted.

## G6 — security and related-key disclosure

Run an h-aware estimator/review over actual Q/P, ring dimension, ternary h=128 distribution and the same-secret per-context evaluation-key family. Document manual-context bypass of normal checks and all exposed related-key material.

Acceptance: only then may a concrete security level be claimed. Functional GREEN is not security validation.

## Separate later boundary

Section 6.2's 18-level recombine/decompose refresh remains a separate explicit-capacity experiment. It is neither a prerequisite for Section 6.3 nor a hidden bootstrap requirement.
