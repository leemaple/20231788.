# Repeated Mult2 bounded delivery

**Delivery class: `BOUNDED_PUBLIC_API_PROBE`, not a complete second-Mult2 implementation and not a paper reproduction.**

This package is bound to project source `774fe2dcfca47d7a08cab9c04b29c430e354cf9f` (active tested production code `47907783a6141d0174da79eae264d779fc598f28`) and pristine OpenFHE `df495ba2e91739a6dc8f1de254fc5a41155ce504`. The supplied archive identity and all manifests were verified before source claims were accepted.

## Decision

A source-defensible repeated route is an immutable ordered-basis context/key family. A complete production patch is intentionally not claimed yet because the decisive pristine-API construction/key-routing path has not been compiled or executed in this environment, and the paper's `h=128` keypair construction is a separate unresolved setup gate. Returning a metadata relabel, guard removal, shared full-context key, secret-assisted evaluator refresh, or an untested production stub would be misleading.

The staged increment therefore contains:

1. `patches/0001-freeze-current-second-mult2-boundary.patch`: additive executable coverage cloned from the unchanged high-precision first-Mult2 fixture. It keeps that independent arithmetic oracle and freezes the exact current second-call rejection. It does **not** manufacture or claim a runtime RED.
2. `patches/0002-add-immutable-basis-key-routing-probe.patch`: an evaluator-only-after-setup public-API probe for two immutable ordered-Q contexts, alpha-one HYBRID key rows, secret projection during client setup, distinct tags, active/full-basis relinearization, context rehoming by fresh ciphertext construction, and no source mutation.
3. `contracts/SECOND_MULT2_EXACT_VECTORS.json`: the normative future GREEN arithmetic contract `Z=Mult2(X,Y)`, then `W=Mult2(Z,Z)`, with exact dyadic operands/oracles and a frozen `<=2^-80` stage-two diagnostic threshold. `tools/verify_exact_contract.py` independently checks every exact slot and both distinguishing deltas.

## Apply order

```text
git apply --check patches/0001-freeze-current-second-mult2-boundary.patch
git apply patches/0001-freeze-current-second-mult2-boundary.patch
git apply --check patches/0002-add-immutable-basis-key-routing-probe.patch
git apply patches/0002-add-immutable-basis-key-routing-probe.patch
```

`complete/project/` contains every final changed/new file after both patches. `PATCH_REPLAY.md` and `MANIFEST.json` bind replay to those bytes. The prior 55 CTest name/command pairs are byte-for-byte preserved in `EXPECTED_CTEST_BINDINGS.tsv`; two additive tests are rows 56 and 57.

## What the probe decides

The probe accepts only if a second family `B1=[A1,q_div]` can be built with the actual ordered prime identities, its own precomputed Q/P/QP tables and HYBRID rows, a private key projected from the family-0 secret solely during setup, and evaluator-only active/full-basis relinearization after all private-key objects leave scope. P equality across families is reported but is not an acceptance condition because keys and tables are never shared across families.

## Not claimed

No OpenFHE C++ build, crypto runtime, Linux/Windows Actions, h=128 keypair setup, semantic second Mult2, eight squarings, 1000-run result, 81.8-bit precision, performance, or security validation was run here. See `ACTUAL_EXECUTION_LEDGER.md`.
