#!/usr/bin/env python3
"""Bounded exact-scalar and patch validation; never builds or runs OpenFHE.
Usage: python3 checks/validate.py /path/to/extracted/input
"""
import hashlib,json,re,shutil,subprocess,sys,tempfile
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
ANCHORS=(0,1,256,257,512,513,768,769,1023,16383)
def mul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def sub(a,b):return a[0]-b[0],a[1]-b[1]
def function(text,name):
    pos=text.index(name+'('); start=text.rfind('\n',0,pos)+1
    brace=text.index('{',pos); depth=1; end=brace+1
    while depth:
        if text[end]=='{':depth+=1
        elif text[end]=='}':depth-=1
        end+=1
    return text[start:end]
def main(input_root):
    expected={}
    for a,s in enumerate(ANCHORS):
        z=(F(31,32)+F(s,2**20),F(1,128))
        previous=(z[0]+F(a+1,2**90),z[1]-F(a+1,2**91)); inherited=previous
        for r in range(1,9):
            z=mul(z,z); inherited=mul(inherited,inherited)
            previous_squared=mul(previous,previous); actual=previous_squared
            if r==3:actual=(actual[0]+F(1,2**110),actual[1]-F(1,2**112))
            for kind,v in [('E',sub(actual,z)),('I',sub(inherited,z)),('A',sub(actual,inherited)),('L',sub(actual,previous_squared))]:
                for j,component in enumerate(('real','imag')):
                    expected[f'diag.synthetic_round_{r}.anchor_{s}.{kind}.{component}']=v[j]
            previous=actual
    actual={}
    for line in (HERE/'evidence/scalar_algebra.txt').read_text().splitlines():
        m=re.fullmatch(r'OBS field=(\S+) value=(\S+)',line)
        if m and m[1] in expected:
            assert m[1] not in actual
            actual[m[1]]=F(m[2])
    assert set(actual)==set(expected)
    maximum=max(abs(actual[k]-v) for k,v in expected.items())
    assert maximum<F(1,2**360)
    finite=(HERE/'evidence/scalar_numeric-failure.txt').read_text()
    invalid=(HERE/'evidence/scalar_nonfinite.txt').read_text()
    assert 'cleanup_reached failures=1' in finite and 'result=FAIL' in finite and 'result=PASS' not in finite
    assert 'cleanup_reached' not in invalid and 'nonfinite' in invalid and 'result=FAIL' in invalid
    baseline=input_root/'project'
    H='tests/paper_full_eight_square_oracle.h'; C='tests/paper_full_eight_square_contract_test.cpp'
    bh=(baseline/H).read_text(); bc=(baseline/C).read_text()
    dh=(HERE/'complete/diagnostic'/H).read_text(); dc=(HERE/'complete/diagnostic'/C).read_text()
    for name in ['Scales','Input','Inputs','ClientInputs','ReadSecret','SparseDecrypt','RecombinedPolynomial','AnchorRoots','Horner']:
        assert function(bh,name)==function(dh,name),name
    assert function(bc,'Evaluate')==function(dc,'Evaluate')
    for name in ['CheckFamilies','CheckCipher','CheckReceipt','CheckPair','CheckReceiptChain','CheckBound','ForeignRejections']:
        assert function(bc,name)==function(dc,name),name
    assert bc.count('client.Encrypt(')==dc.count('client.Encrypt(')==1
    assert bc.count('catch (')==dc.count('catch (')
    assert bh.count('catch (')==dh.count('catch (')==0
    for assertion in ['Require(cross>=0 && cross<=Pow2(-120),label+" codec 2^-120 gate");',
                      'Require(decoded.diagnostics.centeredHeadroom>0,"positive actual centered headroom");',
                      'Require(disagreement<=Pow2(-80),label+" anchor vs production 2^-80 gate");']:
        assert assertion in bh and assertion in dh
    assert dc.index('OBS lifecycle=paper_owner_cleanup')<dc.index('Require(numericFailures==0')<dc.index('COMPLETE test=paper_full_eight_square_contract result=PASS')
    # Every production, test/build/workflow input still matches the incoming manifest.
    manifest=json.loads((input_root/'MANIFEST.json').read_text())
    entries=manifest.get('files',manifest.get('payloads'))
    assert entries is not None
    for entry in entries:
        data=(input_root/entry['path']).read_bytes()
        assert len(data)==entry.get('bytes',entry.get('size'))
        assert hashlib.sha256(data).hexdigest()==entry['sha256']
    applications=[]
    plans=[(['DIAGNOSTIC.patch'],'diagnostic'),(['PORTABILITY.patch'],'portability'),
           (['DIAGNOSTIC.patch','PORTABILITY.patch'],'combined'),
           (['PORTABILITY.patch','DIAGNOSTIC.patch'],'combined')]
    for patches,kind in plans:
        with tempfile.TemporaryDirectory(prefix='precision-apply-') as temp:
            work=Path(temp)/'project'; shutil.copytree(baseline,work)
            commands=[]
            for patch in patches:
                for flags in [['--check'],[]]:
                    cmd=['git','apply']+flags+[str(HERE/patch)]
                    proc=subprocess.run(cmd,cwd=work,text=True,capture_output=True)
                    if proc.returncode:
                        print(json.dumps({"plan":patches,"command":cmd,"stderr":proc.stderr}),file=sys.stderr)
                        proc.check_returncode()
                    commands.append({'command':cmd,'exit':proc.returncode,'output':proc.stdout+proc.stderr})
            for complete in (HERE/'complete'/kind).rglob('*'):
                if complete.is_file(): assert complete.read_bytes()==(work/complete.relative_to(HERE/'complete'/kind)).read_bytes()
            changed=[]
            for original in baseline.rglob('*'):
                if original.is_file():
                    rel=original.relative_to(baseline)
                    if original.read_bytes()!=(work/rel).read_bytes():changed.append(str(rel))
            assert set(changed)==({H} if kind=='portability' else {H,C})
            applications.append({'patches':patches,'complete_files_match':True,'changed':changed,'commands':commands})
    print(json.dumps({'scalar_signed_components_checked':len(expected),
                      'scalar_absolute_tolerance':'2^-360',
                      'maximum_scalar_disagreement_approx':float(maximum),
                      'synthetic_finite_failure_retained':True,'synthetic_nonfinite_abort_retained':True,
                      'unchanged_oracle_evaluator_and_invariant_functions':True,
                      'input_manifest_reverified':len(entries),
                      'applications':applications},indent=2))
if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit(__doc__)
    main(Path(sys.argv[1]))
