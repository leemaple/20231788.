#!/usr/bin/env python3
"""Bounded scalar audit of first (61:-prefixed) stream; no FHE/NTT/FFT.
Usage: python3 checks/analyze.py /path/to/extracted/input
Uses only 10 public diagnostic slots and their printed component-error norms.
Decimal intervals include a deliberately conservative 1e-42 relative allowance
for printed observations; precision is 120 decimal digits, not interval arithmetic.
"""
import json, re, sys
from decimal import Decimal as D, localcontext
from pathlib import Path
from fractions import Fraction as F

ANCHORS = (0,1,256,257,512,513,768,769,1023,16383)
def mul(a,b): return (a[0]*b[0]-a[1]*b[1], a[0]*b[1]+a[1]*b[0])
def power(z,n):
    out=(F(1),F(0))
    while n:
        if n&1: out=mul(out,z)
        z=mul(z,z); n//=2
    return out
def inp(s):
    t=s//2
    a=F(1015,1024)-F(t%16,65536)+F(s,2**75)
    b=F(1+(t//16)%8,1024)*(-1 if (t//512)%2 else 1)
    return ((a,b),(-b,a),(-a,-b),(b,-a))[(t//128)%4]
def dec(x): return D(x.numerator)/D(x.denominator)
def bounds(z, p, error):
    # derivative multiplication acts on the real 2D component infinity norm.
    d=tuple(p*x for x in power(z,p-1)); a,b=map(dec,d)
    e_lo=error*(1-D('1e-42')); e_hi=error*(1+D('1e-42'))
    op=abs(a)+abs(b)
    inv= (a*a+b*b)/op
    radius=(dec(z[0])**2+dec(z[1])**2).sqrt()
    rho=D(2).sqrt()*e_hi
    rem=D(p*(p-1))/2 * (radius+rho)**(p-2)*rho*rho
    return inv*e_lo-rem,op*e_hi+rem,rem

def main(root):
    text=(root/'evidence/WINDOWS_LF.log').read_text()
    observations={}
    for lineno,line in enumerate(text.splitlines(),1):
        m=re.search(r' 61: OBS field=(\S+) value=(\S+)',line)
        if m:
            if m[1] in observations: raise ValueError('duplicate live observation '+m[1])
            observations[m[1]]=(D(m[2]),lineno)
    def err(r,s): return observations[f'{"fresh" if r==0 else "round_"+str(r)}.anchor_{s}_error'][0]
    rows=[]
    with localcontext() as ctx:
        ctx.prec=120
        gate=D(2)**-80
        for r in (1,2,3,4,8):
            for s in ANCHORS:
                lo,hi,rem=bounds(inp(s),2**r,err(0,s))
                entry=dict(round=r,slot=s,inherited_lower=str(lo),inherited_upper=str(hi),remainder_upper=str(rem))
                if r<=4:
                    actual=err(r,s)
                    al=max(D(0),lo-actual*(1+D('1e-42')),actual*(1-D('1e-42'))-hi)
                    ll,lh,lr=bounds(power(inp(s),2**(r-1)),2,err(r-1,s))
                    local_lower=max(D(0),ll-actual*(1+D('1e-42')),actual*(1-D('1e-42'))-lh)
                    entry.update(observed=str(actual),cumulative_residual_norm_lower=str(al),local_residual_norm_lower=str(local_lower))
                rows.append(entry)
        pk_sigma=D('3.19') # heuristic only: configuration is 3.19F, not exact decimal
        coefvar=pk_sigma**2*(D(2)*32768/3+128+1)
        results=dict(precision=120,gate=str(gate),live_observation_count=len(observations),
            fresh_error=str(observations['fresh.full_max_component_error'][0]),
            encoding_rounding_component_upper=str(D(32768)/2/(D(2)**100)),
            heuristic_complex_slot_rms=str((D(32768)*coefvar).sqrt()/(D(2)**100)),
            round4_gate_ratio=str(err(4,512)/gate),
            round4_failing_anchors=[s for s in ANCHORS if err(4,s)>gate],
            rows=rows)
    print(json.dumps(results,indent=2))
if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit(__doc__)
    main(Path(sys.argv[1]))
