#!/usr/bin/env python3
"""Extract only scalar helpers; never include OpenFHE or compile the project."""
from pathlib import Path
ROOT=Path('/mnt/data/precision_review')
BASE=Path('/mnt/data/input/project/tests/paper_full_eight_square_oracle.h').read_text()
CAND=(ROOT/'complete/combined/tests/paper_full_eight_square_oracle.h').read_text()
def function(text,name):
    start=text.index('inline ',text.rfind('\n',0,text.index(name+'(')))
    brace=text.index('{',start); depth=1; end=brace+1
    while depth:
        if text[end]=='{':depth+=1
        elif text[end]=='}':depth-=1
        end+=1
    return text[start:end]+'\n'
prefix='''// Isolated scalar compiler probe, NOT an OpenFHE/production test.
#include <boost/math/constants/constants.hpp>
#include <boost/math/special_functions/fpclassify.hpp>
#include <boost/multiprecision/cpp_bin_float.hpp>
#include <boost/multiprecision/cpp_dec_float.hpp>
#include <boost/multiprecision/cpp_int.hpp>
#include <array>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>
using Int=boost::multiprecision::cpp_int;
using Real=boost::multiprecision::number<boost::multiprecision::backends::cpp_bin_float<512,boost::multiprecision::backends::digit_base_2>>;
static_assert(std::numeric_limits<Real>::digits==512,"unchanged binary512");
constexpr std::uint32_t kM=65536;
constexpr std::array<std::size_t,10> kAnchors{{0,1,256,257,512,513,768,769,1023,16383}};
struct Complex final { Real real,imag; };
'''
rootmain='''
int main() {
    using Ref=boost::multiprecision::number<boost::multiprecision::cpp_dec_float<160>>;
    const auto roots=AnchorRoots();
    const Ref pi=boost::math::constants::pi<Ref>();
    Ref maxError=0;
    for (std::size_t a=0;a<kAnchors.size();++a) {
        std::uint32_t exponent=1;
        for (std::size_t j=0;j<kAnchors[a];++j) exponent=exponent*5%kM;
        const Ref angle=Ref(2)*pi*exponent/kM;
        const Ref re(roots[a].real.str(160,std::ios_base::scientific));
        const Ref im(roots[a].imag.str(160,std::ios_base::scientific));
        const Ref er=abs(re-cos(angle)),ei=abs(im-sin(angle));
        if (er>maxError) maxError=er;
        if (ei>maxError) maxError=ei;
    }
    std::cout << std::scientific << std::setprecision(40)
              << "SCALAR_ROOTS count=10 max_component_vs_decimal160=" << maxError << '\\n';
    return maxError<pow(Ref(2),-480)?0:1;
}
'''
for kind,text in [('original',BASE),('portable',CAND)]:
    (ROOT/'checks'/f'roots_{kind}.cpp').write_text(prefix+function(text,'AnchorRoots')+rootmain)
helpers=''.join(function(CAND,name) for name in ['Require','R','Abs','Pow2','Finite','Multiply','Error','Emit','PrecisionGate','Difference','EmitSigned','ObserveResiduals'])
main='''
// Pure scalar, deliberately synthetic data. These are not ciphertext results.
int main(int argc,char** argv) {
    try {
        const std::string mode=argc>1?argv[1]:"algebra";
        std::size_t failures=0;
        if (mode=="numeric-failure") PrecisionGate(false,"synthetic finite miss",failures);
        if (mode=="nonfinite") Finite(std::numeric_limits<Real>::quiet_NaN(),"synthetic invalid state");
        if (mode=="algebra") {
            PrecisionGate(true,"synthetic pass",failures);
            std::vector<Complex> expected(16384);
            std::array<Complex,10> previous{},freshPower{};
            for (std::size_t a=0;a<10;++a) {
                const Complex z{Real(31)/32+Real(kAnchors[a])*Pow2(-20),Real(1)/128};
                expected[kAnchors[a]]=z;
                previous[a]={z.real+Real(a+1)*Pow2(-90),z.imag-Real(a+1)*Pow2(-91)};
                freshPower[a]=previous[a];
            }
            for (std::size_t r=1;r<=8;++r) {
                std::array<Complex,10> actual{};
                for (std::size_t a=0;a<10;++a) {
                    auto& z=expected[kAnchors[a]];
                    z=Multiply(z,z);
                    freshPower[a]=Multiply(freshPower[a],freshPower[a]);
                    actual[a]=Multiply(previous[a],previous[a]);
                    if (r==3) { actual[a].real+=Pow2(-110); actual[a].imag-=Pow2(-112); }
                }
                ObserveResiduals(actual,previous,freshPower,expected,"synthetic_round_"+std::to_string(r));
                previous=actual;
            }
        }
        std::cout << "SYNTHETIC cleanup_reached failures=" << failures << '\\n';
        Require(failures==0,"synthetic accumulated numeric failure");
        std::cout << "SYNTHETIC result=PASS\\n";
        return 0;
    }
    catch (const std::runtime_error& e) {
        std::cerr << "SYNTHETIC result=FAIL reason=" << e.what() << '\\n'; return 1;
    }
}
'''
(ROOT/'checks/scalar_diagnostics.cpp').write_text(prefix+helpers+main)
print('Extracted original/portable AnchorRoots and exact diagnostic helper bodies (no OpenFHE includes).')
