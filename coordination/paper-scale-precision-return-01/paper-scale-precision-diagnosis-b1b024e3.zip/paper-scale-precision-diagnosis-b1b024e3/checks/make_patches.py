#!/usr/bin/env python3
"""Build review artifacts from the exact read-only input snapshot. No FHE."""
from pathlib import Path
import difflib
ROOT=Path('/mnt/data/input/project')
OUT=Path('/mnt/data/precision_review')
H='tests/paper_full_eight_square_oracle.h'
C='tests/paper_full_eight_square_contract_test.cpp'
original={p:(ROOT/p).read_text() for p in (H,C)}
def replace(s,old,new):
    assert s.count(old)==1,(old,s.count(old))
    return s.replace(old,new)
h=original[H]
h=replace(h,'inline Real CheckFull(','''// Accumulate finite acceptance misses only. Shape, nonfinite, codec/oracle
// agreement and nonwrap checks still throw; no invalid-state continuation.
inline void PrecisionGate(bool condition,const std::string& label,std::size_t& failures) {
    if (!condition) {
        ++failures;
        std::cout << "OBS numeric_gate=FAIL label=" << label << '\\n' << std::flush;
    }
}
inline Complex Difference(const Complex& a,const Complex& b) {
    return {a.real-b.real,a.imag-b.imag};
}
inline void EmitSigned(const std::string& field,const Complex& z) {
    Finite(z.real,field+".real"); Finite(z.imag,field+".imag");
    // Enough digits to preserve the signed sub-binary64 perturbation in w0.
    // All arithmetic remains the original binary512 Real, not these strings.
    std::cout << std::scientific << std::setprecision(100)
              << "OBS field=" << field << ".real value=" << z.real << '\\n'
              << "OBS field=" << field << ".imag value=" << z.imag << '\\n' << std::flush;
}
inline void ObserveResiduals(const std::array<Complex,10>& actual,
                             const std::array<Complex,10>& previous,
                             const std::array<Complex,10>& freshPower,
                             const std::vector<Complex>& expected,const std::string& label) {
    Real inheritedMax=0, addedMax=0, localMax=0;
    for (std::size_t a=0;a<kAnchors.size();++a) {
        const auto& z=expected.at(kAnchors[a]);
        const auto inherited=Difference(freshPower[a],z);
        const auto added=Difference(actual[a],freshPower[a]);
        const auto local=Difference(actual[a],Multiply(previous[a],previous[a]));
        const auto field="diag."+label+".anchor_"+std::to_string(kAnchors[a]);
        EmitSigned(field+".E",Difference(actual[a],z));
        EmitSigned(field+".I",inherited);
        EmitSigned(field+".A",added);
        EmitSigned(field+".L",local);
        const Complex zero{Real(0),Real(0)};
        const Real i=Error(inherited,zero), b=Error(added,zero), l=Error(local,zero);
        if (i>inheritedMax) inheritedMax=i;
        if (b>addedMax) addedMax=b;
        if (l>localMax) localMax=l;
    }
    // Diagnostics, never substitute acceptance against freshPower for truth.
    Emit("diag."+label+".I_anchor_max_component",inheritedMax);
    Emit("diag."+label+".A_anchor_max_component",addedMax);
    Emit("diag."+label+".L_anchor_max_component",localMax);
}
inline Real CheckFull(''')
h=replace(h,'                      const std::string& label) {','                      const std::string& label,std::size_t& failures) {')
h=replace(h,'Require(maximum<=Pow2(-80),label+" full-slot 2^-80 gate");','PrecisionGate(maximum<=Pow2(-80),label+" full-slot 2^-80 gate",failures);')
# The plaintext aggregate supports inspecting binary512 conditioning without
# changing the CRT, coefficients, roots, Horner operations, or acceptance.
h=replace(h,'inline IntegerPolynomial RecombinedPolynomial(','''inline void ObserveCoefficientScale(const IntegerPolynomial& polynomial,const Scale& scale,
                                    const std::string& label) {
    Int maximum=0;
    for (const auto& c:polynomial.coefficients) {
        const Int magnitude=c<0?Int(-c):c;
        if (magnitude>maximum) maximum=magnitude;
    }
    Emit("diag."+label+".coefficient_max_over_scale",
         R(maximum)*R(scale.denominator)/R(scale.numerator));
}
inline IntegerPolynomial RecombinedPolynomial(''')
h=replace(h,'                         const std::string& label,const io::DecodedSlots* production=nullptr) {','                         const std::string& label,std::size_t& failures,\n                         const io::DecodedSlots* production=nullptr) {')
h=replace(h,'Require(maximum<=Pow2(-80),label+" independent anchor 2^-80 gate");','PrecisionGate(maximum<=Pow2(-80),label+" independent anchor 2^-80 gate",failures);')
# The independent-oracle/production agreement assertion stays prompt, unchanged.
c=original[C]
c=replace(c,'void Witness(const io::DecodedSlots& decoded,const std::vector<Complex>& expected,const std::string& label) {','void Witness(const io::DecodedSlots& decoded,const std::vector<Complex>& expected,\n             const std::string& label,std::size_t& failures) {')
c=replace(c,'Require(actual>Pow2(-76) && Abs(actual-difference)<=2*Pow2(-80),label+" retained sub-binary64 witness");','PrecisionGate(actual>Pow2(-76) && Abs(actual-difference)<=2*Pow2(-80),\n                  label+" retained sub-binary64 witness",failures);')
c=replace(c,'std::vector<std::string> RunPaper(const RepeatedMult2ClientSetup& foreign) {','std::vector<std::string> RunPaper(const RepeatedMult2ClientSetup& foreign,std::size_t& failures) {')
c=replace(c,'CheckFull(freshDecoded,expected,"fresh"); Witness(freshDecoded,expected,"fresh");','CheckFull(freshDecoded,expected,"fresh",failures); Witness(freshDecoded,expected,"fresh",failures);')
c=replace(c,'    CheckAnchors(Horner(freshPolynomial,scales[0],roots),expected,"fresh",&freshDecoded);','''    ObserveCoefficientScale(freshPolynomial,scales[0],"fresh");
    const auto freshAnchors=Horner(freshPolynomial,scales[0],roots);
    CheckAnchors(freshAnchors,expected,"fresh",failures,&freshDecoded);
    for (std::size_t a=0;a<kAnchors.size();++a) {
        const auto field="diag.fresh.anchor_"+std::to_string(kAnchors[a]);
        EmitSigned(field+".w0",freshAnchors[a]);
        EmitSigned(field+".E",Difference(freshAnchors[a],expected.at(kAnchors[a])));
    }
    auto previousAnchors=freshAnchors;
    auto freshPowers=freshAnchors;''')
c=replace(c,'        CheckAnchors(Horner(polynomial,scales[round],roots),expected,"round_"+std::to_string(round));','''        const auto label="round_"+std::to_string(round);
        ObserveCoefficientScale(polynomial,scales[round],label);
        const auto anchors=Horner(polynomial,scales[round],roots);
        for (auto& w:freshPowers) w=Multiply(w,w);
        ObserveResiduals(anchors,previousAnchors,freshPowers,expected,label);
        CheckAnchors(anchors,expected,label,failures);
        previousAnchors=anchors;''')
c=replace(c,'CheckFull(decoded,expected,"final"); Witness(decoded,expected,"final");','CheckFull(decoded,expected,"final",failures); Witness(decoded,expected,"final",failures);')
c=replace(c,'    CheckAnchors(Horner(finalPolynomial,scales[8],roots),expected,"final",&decoded);','    ObserveCoefficientScale(finalPolynomial,scales[8],"final");\n    CheckAnchors(Horner(finalPolynomial,scales[8],roots),expected,"final",failures,&decoded);')
c=replace(c,'    const auto paperTags=RunPaper(foreign);','    std::size_t numericFailures=0;\n    const auto paperTags=RunPaper(foreign,numericFailures);')
c=replace(c,'    std::cout << "COMPLETE test=paper_full_eight_square_contract result=PASS source="','''    std::cout << "OBS numeric_gate_failures=" << numericFailures << '\\n' << std::flush;
    Require(numericFailures==0,"accumulated numeric acceptance failures: "+std::to_string(numericFailures));
    std::cout << "COMPLETE test=paper_full_eight_square_contract result=PASS source="''')
diag={H:h,C:c}
oldroots='''    const Real pi=boost::math::constants::pi<Real>();
    for (std::size_t i=0;i<kAnchors.size();++i) {
        std::uint32_t exponent=1;
        for (std::size_t s=0;s<kAnchors[i];++s) exponent=(exponent*5)%kM;
        const Real angle=Real(2)*pi*exponent/kM;
        roots[i]={boost::multiprecision::cos(angle),boost::multiprecision::sin(angle)};'''
newroots='''    // Avoid the fixed-storage 512 -> 1536 trig-reduction conversion that
    // triggers GCC's array-bounds diagnostic in Boost 1.83. Storage only:
    // precision, exponent range, angles and returned binary512 Real stay fixed.
    using RootReal=boost::multiprecision::number<boost::multiprecision::backends::cpp_bin_float<
        512,boost::multiprecision::backends::digit_base_2,
        std::allocator<boost::multiprecision::limb_type>>,boost::multiprecision::et_off>;
    const RootReal pi=boost::math::constants::pi<RootReal>();
    for (std::size_t i=0;i<kAnchors.size();++i) {
        std::uint32_t exponent=1;
        for (std::size_t s=0;s<kAnchors[i];++s) exponent=(exponent*5)%kM;
        const RootReal angle=RootReal(2)*pi*exponent/kM;
        const RootReal re=boost::multiprecision::cos(angle), im=boost::multiprecision::sin(angle);
        roots[i]={Real(re),Real(im)};'''
def portable(text):
    return replace(replace(text,'#include <iostream>','#include <iostream>\n#include <memory>'),oldroots,newroots)
port={H:portable(original[H])}
combined={H:portable(h),C:c}
def diff(files):
    return ''.join(''.join(difflib.unified_diff(original[p].splitlines(True),text.splitlines(True),
                          fromfile='a/'+p,tofile='b/'+p,n=3)) for p,text in files.items())
(OUT/'DIAGNOSTIC.patch').write_text(diff(diag))
(OUT/'PORTABILITY.patch').write_text(diff(port))
for folder,files in [('diagnostic',diag),('portability',port),('combined',combined)]:
    for p,text in files.items():
        dest=OUT/'complete'/folder/p; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_text(text)
print('Written independent patches and complete diagnostic-only, portability-only, and combined files.')
