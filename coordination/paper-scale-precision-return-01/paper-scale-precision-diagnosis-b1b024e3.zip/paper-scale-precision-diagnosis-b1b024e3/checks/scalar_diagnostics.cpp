// Isolated scalar compiler probe, NOT an OpenFHE/production test.
#include <boost/math/constants/constants.hpp>
#include <boost/math/special_functions/fpclassify.hpp>
#include <boost/multiprecision/cpp_bin_float.hpp>
#include <boost/multiprecision/cpp_dec_float.hpp>
#include <boost/multiprecision/cpp_int.hpp>
#include <array>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>
using Int=boost::multiprecision::cpp_int;
using Real=boost::multiprecision::number<boost::multiprecision::backends::cpp_bin_float<512,boost::multiprecision::backends::digit_base_2>>;
static_assert(std::numeric_limits<Real>::digits==512,"unchanged binary512");
constexpr std::uint32_t kM=65536;
constexpr std::array<std::size_t,10> kAnchors{{0,1,256,257,512,513,768,769,1023,16383}};
struct Complex final { Real real,imag; };
inline void Require(bool condition, const std::string& label) {
    if (!condition) throw std::runtime_error("paper contract: " + label);
}
inline Real R(const Int& x) { return Real(x.convert_to<std::string>()); }
inline Real Abs(const Real& x) { return x < 0 ? Real(-x) : x; }
inline Real Pow2(int e) { return boost::multiprecision::ldexp(Real(1), e); }
inline void Finite(const Real& x, const std::string& label) {
    Require(boost::math::isfinite(x), label + " nonfinite");
}
inline Complex Multiply(const Complex& a,const Complex& b) {
    return {a.real*b.real-a.imag*b.imag,a.real*b.imag+a.imag*b.real};
}
inline Real Error(const Complex& a,const Complex& b) {
    const Real re=Abs(a.real-b.real), im=Abs(a.imag-b.imag);
    Finite(re,"real error"); Finite(im,"imag error"); return re>im?re:im;
}
inline void Emit(const std::string& field,const Real& value) {
    Finite(value,field);
    std::cout << std::scientific << std::setprecision(45)
              << "OBS field=" << field << " value=" << value << '\n' << std::flush;
}
inline void PrecisionGate(bool condition,const std::string& label,std::size_t& failures) {
    if (!condition) {
        ++failures;
        std::cout << "OBS numeric_gate=FAIL label=" << label << '\n' << std::flush;
    }
}
inline Complex Difference(const Complex& a,const Complex& b) {
    return {a.real-b.real,a.imag-b.imag};
}
inline void EmitSigned(const std::string& field,const Complex& z) {
    Finite(z.real,field+".real"); Finite(z.imag,field+".imag");
    // Enough digits to preserve the signed sub-binary64 perturbation in w0.
    // All arithmetic remains the original binary512 Real, not these strings.
    std::cout << std::scientific << std::setprecision(100)
              << "OBS field=" << field << ".real value=" << z.real << '\n'
              << "OBS field=" << field << ".imag value=" << z.imag << '\n' << std::flush;
}
inline void ObserveResiduals(const std::array<Complex,10>& actual,
                             const std::array<Complex,10>& previous,
                             const std::array<Complex,10>& freshPower,
                             const std::vector<Complex>& expected,const std::string& label) {
    Real inheritedMax=0, addedMax=0, localMax=0;
    for (std::size_t a=0;a<kAnchors.size();++a) {
        const auto& z=expected.at(kAnchors[a]);
        const auto inherited=Difference(freshPower[a],z);
        const auto added=Difference(actual[a],freshPower[a]);
        const auto local=Difference(actual[a],Multiply(previous[a],previous[a]));
        const auto field="diag."+label+".anchor_"+std::to_string(kAnchors[a]);
        EmitSigned(field+".E",Difference(actual[a],z));
        EmitSigned(field+".I",inherited);
        EmitSigned(field+".A",added);
        EmitSigned(field+".L",local);
        const Complex zero{Real(0),Real(0)};
        const Real i=Error(inherited,zero), b=Error(added,zero), l=Error(local,zero);
        if (i>inheritedMax) inheritedMax=i;
        if (b>addedMax) addedMax=b;
        if (l>localMax) localMax=l;
    }
    // Diagnostics, never substitute acceptance against freshPower for truth.
    Emit("diag."+label+".I_anchor_max_component",inheritedMax);
    Emit("diag."+label+".A_anchor_max_component",addedMax);
    Emit("diag."+label+".L_anchor_max_component",localMax);
}

// Pure scalar, deliberately synthetic data. These are not ciphertext results.
int main(int argc,char** argv) {
    try {
        const std::string mode=argc>1?argv[1]:"algebra";
        std::size_t failures=0;
        if (mode=="numeric-failure") PrecisionGate(false,"synthetic finite miss",failures);
        if (mode=="nonfinite") Finite(std::numeric_limits<Real>::quiet_NaN(),"synthetic invalid state");
        if (mode=="algebra") {
            PrecisionGate(true,"synthetic pass",failures);
            std::vector<Complex> expected(16384);
            std::array<Complex,10> previous{},freshPower{};
            for (std::size_t a=0;a<10;++a) {
                const Complex z{Real(31)/32+Real(kAnchors[a])*Pow2(-20),Real(1)/128};
                expected[kAnchors[a]]=z;
                previous[a]={z.real+Real(a+1)*Pow2(-90),z.imag-Real(a+1)*Pow2(-91)};
                freshPower[a]=previous[a];
            }
            for (std::size_t r=1;r<=8;++r) {
                std::array<Complex,10> actual{};
                for (std::size_t a=0;a<10;++a) {
                    auto& z=expected[kAnchors[a]];
                    z=Multiply(z,z);
                    freshPower[a]=Multiply(freshPower[a],freshPower[a]);
                    actual[a]=Multiply(previous[a],previous[a]);
                    if (r==3) { actual[a].real+=Pow2(-110); actual[a].imag-=Pow2(-112); }
                }
                ObserveResiduals(actual,previous,freshPower,expected,"synthetic_round_"+std::to_string(r));
                previous=actual;
            }
        }
        std::cout << "SYNTHETIC cleanup_reached failures=" << failures << '\n';
        Require(failures==0,"synthetic accumulated numeric failure");
        std::cout << "SYNTHETIC result=PASS\n";
        return 0;
    }
    catch (const std::runtime_error& e) {
        std::cerr << "SYNTHETIC result=FAIL reason=" << e.what() << '\n'; return 1;
    }
}
