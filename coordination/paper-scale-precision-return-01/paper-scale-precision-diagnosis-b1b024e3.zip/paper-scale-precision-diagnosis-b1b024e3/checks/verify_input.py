#!/usr/bin/env python3
"""Read-only archive/manifest identity verification, no execution of payloads.
Usage: python3 checks/verify_input.py ARCHIVE EXTRACTED_INPUT
"""
import hashlib, json, stat, sys, zipfile
from pathlib import Path, PurePosixPath

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main(archive, root):
    raw=archive.read_bytes()
    expected_sha='28fa7ee1297af78ac4c2848b85d1fce1efdd81bbd1a13d15b0e75076c2719336'
    assert len(raw)==1480623 and sha(raw)==expected_sha
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        names=set(); members={}
        for item in z.infolist():
            path=PurePosixPath(item.filename)
            assert not item.is_dir(), item.filename
            assert not path.is_absolute() and '..' not in path.parts
            assert '\\' not in item.filename and ':' not in item.filename
            assert str(path)==item.filename and item.filename not in names
            mode=item.external_attr >> 16
            assert stat.S_IFMT(mode) in (0, stat.S_IFREG), item.filename
            names.add(item.filename); members[item.filename]=z.read(item)
        manifest=json.loads(members['MANIFEST.json'])
        assert manifest['manifest_self_excluded'] is True
        entries=manifest['files']
        assert len(entries)==133 and len(members)==134
        assert len({e['path'] for e in entries})==len(entries)
        assert {e['path'] for e in entries}==names-{'MANIFEST.json'}
        assert manifest['source']=='b1b024e3134fbb4e8cac7c0d59cf790a37e4ed89'
        assert manifest['official_pin']=='df495ba2e91739a6dc8f1de254fc5a41155ce504'
        for entry in entries:
            data=members[entry['path']]
            assert len(data)==entry['bytes'] and sha(data)==entry['sha256']
        assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}==names
        for name,data in members.items():
            assert (root/name).read_bytes()==data
        print(json.dumps(dict(archive_bytes=len(raw),archive_sha256=sha(raw),crc='PASS',
            unique_safe_regular_members=len(members),manifest_payloads=len(entries),
            expanded_bytes=sum(map(len,members.values())),exact_manifest_closure=True,
            extracted_bytes_equal=True,source=manifest['source'],
            documentation_checkpoint=manifest['documentation_checkpoint'],
            official_pin=manifest['official_pin']),indent=2))

if __name__=='__main__':
    if len(sys.argv)!=3: raise SystemExit(__doc__)
    main(Path(sys.argv[1]),Path(sys.argv[2]))
