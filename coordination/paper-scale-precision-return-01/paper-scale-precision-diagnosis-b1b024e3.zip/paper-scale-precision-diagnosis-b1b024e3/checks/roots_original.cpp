// Isolated scalar compiler probe, NOT an OpenFHE/production test.
#include <boost/math/constants/constants.hpp>
#include <boost/math/special_functions/fpclassify.hpp>
#include <boost/multiprecision/cpp_bin_float.hpp>
#include <boost/multiprecision/cpp_dec_float.hpp>
#include <boost/multiprecision/cpp_int.hpp>
#include <array>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>
using Int=boost::multiprecision::cpp_int;
using Real=boost::multiprecision::number<boost::multiprecision::backends::cpp_bin_float<512,boost::multiprecision::backends::digit_base_2>>;
static_assert(std::numeric_limits<Real>::digits==512,"unchanged binary512");
constexpr std::uint32_t kM=65536;
constexpr std::array<std::size_t,10> kAnchors{{0,1,256,257,512,513,768,769,1023,16383}};
struct Complex final { Real real,imag; };
inline std::array<Complex,10> AnchorRoots() {
    std::array<Complex,10> roots;
    const Real pi=boost::math::constants::pi<Real>();
    for (std::size_t i=0;i<kAnchors.size();++i) {
        std::uint32_t exponent=1;
        for (std::size_t s=0;s<kAnchors[i];++s) exponent=(exponent*5)%kM;
        const Real angle=Real(2)*pi*exponent/kM;
        roots[i]={boost::multiprecision::cos(angle),boost::multiprecision::sin(angle)};
    }
    return roots;
}

int main() {
    using Ref=boost::multiprecision::number<boost::multiprecision::cpp_dec_float<160>>;
    const auto roots=AnchorRoots();
    const Ref pi=boost::math::constants::pi<Ref>();
    Ref maxError=0;
    for (std::size_t a=0;a<kAnchors.size();++a) {
        std::uint32_t exponent=1;
        for (std::size_t j=0;j<kAnchors[a];++j) exponent=exponent*5%kM;
        const Ref angle=Ref(2)*pi*exponent/kM;
        const Ref re(roots[a].real.str(160,std::ios_base::scientific));
        const Ref im(roots[a].imag.str(160,std::ios_base::scientific));
        const Ref er=abs(re-cos(angle)),ei=abs(im-sin(angle));
        if (er>maxError) maxError=er;
        if (ei>maxError) maxError=ei;
    }
    std::cout << std::scientific << std::setprecision(40)
              << "SCALAR_ROOTS count=10 max_component_vs_decimal160=" << maxError << '\n';
    return maxError<pow(Ref(2),-480)?0:1;
}
