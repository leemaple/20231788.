# Independent view recorded before opening the supplied propagation audit

The raw first Windows stream has 60 distinct numeric observations, not two
chains. The signed exact input and printed component-error norms suffice for
an orientation-independent first-order propagation interval plus a negligible
binomial remainder, not for reconstructing signed inherited/arithmetic errors.
The independently written checks/analyze.py finds slot 512 inherited round-4
error in [1.49406650020095744e-24, 1.53821965758586599e-24] conditional on the
fresh oracle, even under exact later arithmetic, above 2^-80=8.27180612553e-25.
Observed round-4 norm is 1.51983054369e-24. Inherited fresh error is therefore
my leading explanation. Small norm inconsistencies already require some
additional residual (e.g. slot 256 first-square residual norm >=3.42366e-28),
but they are LOWER bounds, not evidence that the total signed residual is small.

The exact public key is (a*s+e,-a) from EncryptZeroCore(privateKey); its use in
EncryptZeroCore(publicKey) yields plaintext + e*v + e0 + e1*s. The pinned
non-Gaussian public-encryption branch samples v with default ternary h=0,
not the separately sampled signed h128 secret. Paper Section 2.1 leaves
chi_enc/chi_err abstract. Section 6.3 reports an average over 1000 HEaaN
executions, not this fixed all-slot end-to-end worst-case gate; its precise
sample input/distributions/error reference cannot be reconstructed from the
reported text. No production defect has yet been proved.

The next patch should preserve one evaluation, exact input/scale and gates,
retain signed fresh anchor values, and report E, I, A, L for the same ten
anchors across all eight stages. Finite numerical acceptance failures can be
remembered until cleanup, but structural/oracle-invalid exceptions must abort.
Linux compilation is a separate fixed-storage multiprecision conversion
warning issue; a local allocator-backed trig seam is a candidate, not a
validated hosted fix.
