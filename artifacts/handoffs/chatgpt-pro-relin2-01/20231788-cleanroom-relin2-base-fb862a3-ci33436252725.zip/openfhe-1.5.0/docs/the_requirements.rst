.. code-block:: nginx

   alabaster==0.7.12
   Babel==2.9.1
   breathe==4.33.1
   certifi==2021.10.8
   charset-normalizer==2.0.12
   docutils==0.17.1
   exhale>=0.3.0
   idna==3.3
   imagesize==1.3.0
   importlib-metadata>=4.0.0
   Jinja2==3.0.3
   MarkupSafe>=2.0.0
   packaging==21.3
   Pygments==2.11.2
   pyparsing==3.0.7
   pytz==2021.3
   requests==2.27.1
   snowballstemmer==2.2.0
   Sphinx==4.4.0
   sphinx-rtd-theme==1.0.0
   sphinxcontrib-applehelp==1.0.2
   sphinxcontrib-devhelp==1.0.2
   sphinxcontrib-htmlhelp==2.0.0
   sphinxcontrib-jsmath==1.0.1
   sphinxcontrib-mermaid==0.7.1
   sphinxcontrib-qthelp==1.0.3
   sphinxcontrib-serializinghtml==1.1.5
   urllib3==1.26.9
   zipp==3.7.0

