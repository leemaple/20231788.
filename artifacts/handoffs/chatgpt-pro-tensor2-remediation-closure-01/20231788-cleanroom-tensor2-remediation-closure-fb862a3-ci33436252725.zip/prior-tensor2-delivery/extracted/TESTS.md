# Tensor2 execution record

## Evidence boundary

This file records only commands actually executed in this clean-room task. The supplied project export has no `.git`; commit identities are therefore package/CI identities, not locally recomputed Git history. No commit, push, PR, workflow dispatch/rerun, credential use, or Windows execution was performed.

Input identities used for every stage:

- exact project base: `87c84b879c13b55cf15d6559d3317853228fdc05` (bound by the corrected handoff and base CI evidence);
- official OpenFHE 1.5.0 source: `df495ba2e91739a6dc8f1de254fc5a41155ce504` (bound by the corrected handoff/source package);
- complete Tensor2 task SHA-256: `5a932619c5916b32d1dc5e1de2de253f39c041954d096db291a944ef0161d2c6`;
- successful **base-only** GitHub Actions run: `33411494861`, `headSha=87c84b879c13b55cf15d6559d3317853228fdc05`, conclusion `success`.

The required final Tensor2 GitHub `ubuntu-24.04` and `windows-2022` runs are **pending downstream** because this task explicitly forbids creating provider state.

## Local environment

Executed environment:

- OS: Debian GNU/Linux 13 (trixie), x86_64; kernel `6.18.35`;
- CMake `3.31.6`;
- GCC/G++ `14.2.0`;
- Git `2.47.3`;
- Boost development package `1.83.0.2+b2`;
- project language/warning policy remained C++17 with `-Wall -Wextra -Wpedantic -Werror` on this GCC build.

This is **not** the requested final GitHub `ubuntu-24.04` runner, so local success is not reported as the required hosted Linux result.

The supplied pristine OpenFHE 1.5.0 source was configured, built, and installed locally at `/mnt/data/tensor2_openfhe_install` with unit tests/examples/benchmarks/extras disabled. Upstream OpenFHE tests were **not run**. The archive/source timestamps were several hours ahead of the container clock; this caused GNU Make `Clock skew detected` warnings in some early runs. For the final warning-clean local verification, only filesystem mtimes were normalized with `touch`; no file bytes were changed. Installed OpenFHE header mtimes were similarly normalized later. Compiler diagnostics remained governed by `-Werror` throughout.

For project builds, the command authority was the requested command sequence:

```sh
cmake -S . -B build \
  -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_PREFIX_PATH=${OPENFHE_PREFIX}
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
```

## Patch identities

The exact delivered patch hashes are:

```text
758dfdbc1c28099749d65be3438ea245d24e66d0b90793443137b8997f4b7723  01-red-api.patch
e725c1e9d289f733ec5aeb25e209431ae5045bfc1daba66a9fd4effc9d66a31d  02-api-scaffold.patch
38d5857430504527d9a8fe3441938364c3d12c36f0eb65dc6427ca0512e37416  03-red-tensor2-contract.patch
27d10a4a929f4f7d994c2aa477d607723be41e606f60de8af5b6c62879a04fb2  04-green-tensor2.patch
be3b2c0bad3bd86bbdf6d0a9f7bc6a210e80f14e6e9978105d9747e53ef29703  05-final-docs.patch
```

After the explicit non-mergeable scaffold comment was added, all five exact patches were applied again, in order, to a fresh copy of the exact exported base. For **each** patch the corresponding `git apply --check` returned exit `0`; applying all five then produced a tree recursively byte-identical to the retained final `stage05` tree (`diff -qr` exit `0`).

## Boundary 1 — `01-red-api.patch`

Scope checked: workflow registration, build-only API contract target, and the compile-only public seam test; no production file is changed by this patch.

Executed:

```sh
git apply --check 01-red-api.patch
# exit 0
git apply 01-red-api.patch
# exit 0
cmake -S . -B build \
  -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_PREFIX_PATH=${OPENFHE_PREFIX}
# exit 0
cmake --build build --parallel 2
# exit 2, expected compile red
```

Before this clean compile-red rerun, only project file mtimes were normalized to eliminate archive clock-skew noise; bytes were unchanged. The build log contained no warning/clock-skew diagnostics and failed on the intended missing public seam. Representative exact diagnostics were:

```text
tests/tensor2_api_contract_test.cpp:12:26: error: 'TensorCiphertextPair' has not been declared in 'openfhe_2023_1788'
tests/tensor2_api_contract_test.cpp:13:26: error: 'TensorScaleDescriptor' has not been declared in 'openfhe_2023_1788'
tests/tensor2_api_contract_test.cpp:17:52: error: 'Tensor2' is not a member of 'openfhe_2023_1788::DoubleCKKS'
```

CTest was **not run** at this boundary because the build intentionally failed. No later compiler/runtime failure is substituted for this compile red.

## Boundary 2 — `02-api-scaffold.patch`

`02-api-scaffold.patch` adds the final public declarations/result getters and the intentionally temporary body:

```text
TDD scaffold only: explicitly non-mergeable; 04-green-tensor2.patch must replace it.
DoubleCKKS: Tensor2 is not implemented
```

The body casts the two parameters to void and immediately throws `std::logic_error` before any ciphertext element access or OpenFHE arithmetic.

Executed on the exact stage-02 byte tree after the final scaffold-comment update (non-build tree equality against retained `stage02` was checked with `diff -qr --exclude=build`, exit `0`):

```sh
git apply --check 02-api-scaffold.patch
# exit 0 (also rechecked in the full ordered application)
cmake -S . -B build \
  -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_PREFIX_PATH=${OPENFHE_PREFIX}
# exit 0
cmake --build build --parallel 2
# exit 0
ctest --test-dir build --output-on-failure
# exit 0
```

Observed CTest result: **1/1 passed**, only existing `dcp_rcb`. No Tensor2 behavioral CTest exists yet, so this is explicitly **not** a Tensor2 behavioral green and the scaffold is not mergeable/fallback production behavior. This early run included GNU Make future-mtime/clock-skew environment warnings; it had no compiler warning admitted past `-Werror` and is not used as the final warning-clean evidence.

## Boundary 3 — `03-red-tensor2-contract.patch`

This patch adds the complete Tensor2 behavioral test executable and four separately registered CTest cases without changing the scaffold production behavior.

Executed on the exact stage-03 byte tree after the final scaffold-comment update (non-build tree equality against retained `stage03` checked with `diff -qr --exclude=build`, exit `0`):

```sh
git apply --check 03-red-tensor2-contract.patch
# exit 0 (also rechecked in the full ordered application)
cmake -S . -B build \
  -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_PREFIX_PATH=${OPENFHE_PREFIX}
# exit 0
cmake --build build --parallel 2
# exit 0
ctest --test-dir build --output-on-failure
# exit 8, expected runtime-red aggregate
```

The exact rerun was warning-clean after mtime normalization. CTest executed **all 5 entries**; existing `dcp_rcb` passed and all four Tensor2 cases independently failed:

```text
1/5 dcp_rcb                                  Passed
2/5 tensor2_valid_arithmetic_immutability    Failed
    Tensor2 unexpected exception: DoubleCKKS: Tensor2 is not implemented
3/5 tensor2_result_scale_contract            Failed
    Tensor2 unexpected exception: DoubleCKKS: Tensor2 is not implemented
4/5 tensor2_right_input_validation           Failed
    ...threw the wrong exception type: DoubleCKKS: Tensor2 is not implemented
5/5 tensor2_mutual_compatibility              Failed
    ...threw the wrong exception type: DoubleCKKS: Tensor2 is not implemented
```

Thus no first failure masked another case, valid operations fail on the scaffold, and both negative cases reject the scaffold `logic_error` as the wrong project behavior.

The test file contains no `EvalMultNoRelin` call. Expected arithmetic is produced by the test-owned Boost `cpp_int` schoolbook negacyclic oracle for every component/tower/coefficient. The executed cases include the named witnesses described in `REVIEW.md`: `X^(N-1)*X=-1`, signed product `(-1000003)*(1000033)` crossing active tower 1, and independently nonzero omitted low-low `17*(-19)=-323` at component 0 / tower 0 / coefficient 5.

## Boundary 4 — `04-green-tensor2.patch`

Chronologically, this boundary was built/tested **before** `05-final-docs.patch` was drafted. The patch removes the immediate-throw scaffold and supplies the complete implementation/validation/result normalization in one production patch.

Executed:

```sh
git apply --check 04-green-tensor2.patch
# exit 0 (rechecked after the final scaffold-comment regeneration)
cmake -S . -B build \
  -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_PREFIX_PATH=${OPENFHE_PREFIX}
# exit 0
cmake --build build --parallel 2
# exit 0
ctest --test-dir build --output-on-failure
# exit 0
```

Observed CTest result: **5/5 passed**:

```text
dcp_rcb                                  Passed
tensor2_valid_arithmetic_immutability    Passed
tensor2_result_scale_contract            Passed
tensor2_right_input_validation           Passed
tensor2_mutual_compatibility              Passed
```

That first 04-green run had an archive-mtime GNU Make clock-skew warning, not a compiler diagnostic. `stage04` bytes did not change afterward. The later final docs-only tree is behavior/source-identical to stage04 and was rebuilt warning-clean as recorded below.

Static post-green checks also found:

- no final `Tensor2 is not implemented` scaffold in production;
- exactly three production `EvalMultNoRelin` calls in Tensor2: high-high and the two cross products;
- no low-low multiplication;
- no production `try`/`catch` added;
- no change to upstream OpenFHE;
- no Tensor lifecycle enum/state added.

## Boundary 5 — `05-final-docs.patch`

This patch changes only `README.md` and adds `coordination/TENSOR2_DESIGN.md`. A recursive comparison of stage04/stage05 showed no other changed path, so documentation was added only after the behavioral green.

Executed in a fresh final-tree verification after applying/checking the complete exact patch sequence:

```sh
git apply --check 05-final-docs.patch
# exit 0
cmake -S . -B build \
  -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_PREFIX_PATH=${OPENFHE_PREFIX}
# exit 0
cmake --build build --parallel 2
# exit 0
ctest --test-dir build --output-on-failure
# exit 0
```

For this final local verification, only file mtimes were normalized before configure/build. `grep -iE 'warning:|Clock skew|error:'` over the build log returned no matches. Final CTest result was **5/5 passed**, 0 failed, total reported test time about 0.05 s.

## Required hosted verification not executed here

The following task-required downstream work is intentionally **pending**, not inferred from local execution or the earlier base CI:

- create an exact project commit after applying 01→05;
- GitHub Actions Linux/GCC run on `ubuntu-24.04` bound to that final project SHA;
- GitHub Actions Windows 2022/MSYS2 MinGW64 run bound to the same project SHA;
- corresponding final Actions URLs, compiler/CMake versions, command logs and test counts.

Red Windows runs are not required and were not run. No precision benchmark, performance benchmark, security test, or unsupported second-multiplication behavior was run or claimed.

## Non-evidence interrupted reruns

Two auxiliary mtime-cleanup umbrella reruns were killed by this tool harness timeout while compiling OpenFHE-heavy C++ translation units. They are **not** used as evidence: one stopped during boundary 02, and another completed exact boundary 02 but was killed during the boundary-03 build. Boundary 03 was then rerun separately to completion with the exact stage-03 bytes and produced the complete four-case red recorded above. No test conclusion was inferred from either interrupted command.
