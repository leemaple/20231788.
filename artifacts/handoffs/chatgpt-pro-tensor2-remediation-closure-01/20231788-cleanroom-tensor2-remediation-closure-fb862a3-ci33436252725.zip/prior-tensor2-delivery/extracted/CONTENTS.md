# Delivery contents

This ZIP is a patch-only Tensor2 clean-room handoff. It contains no competing full-file production replacement and no repository/provider state.

Apply source-of-truth patches in exactly this order:

1. `01-red-api.patch`
2. `02-api-scaffold.patch`
3. `03-red-tensor2-contract.patch`
4. `04-green-tensor2.patch`
5. `05-final-docs.patch`

Supporting records:

- `INPUT_GATE.md` — corrected r2 package gate and evidence boundary.
- `REVIEW.md` — paper/OpenFHE equation mapping, scale proof, design inference, validation contract, witnesses, and pending items.
- `TESTS.md` — actual red/scaffold/red/green/final execution record and all pending hosted verification.
- `PATCHES.sha256` — hashes of the five ordered patches.
- `evidence/` — selected raw local logs supporting the stated local execution results.

The final GitHub `ubuntu-24.04` and `windows-2022` runs remain pending and must bind the same downstream final project SHA after these patches are applied.
