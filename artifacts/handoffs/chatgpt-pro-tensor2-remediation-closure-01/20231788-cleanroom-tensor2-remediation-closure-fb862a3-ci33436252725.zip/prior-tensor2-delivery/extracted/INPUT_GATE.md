# Corrected r2 input-package gate

Decision: **PASS**. Algorithm review and patching began only after this corrected gate passed.

## Independently rechecked attachment identity

For `20231788-cleanroom-tensor2-base-87c84b-ci334114-r2.zip`:

- actual size: `8,691,359` bytes;
- actual SHA-256: `eea8aca629e98bfc4fc719c2c7ddbf38610f654630bf92d499d5aa75826753be`;
- actual central-directory entry count: `2,219`;
- `unzip -t`: exit `0`, no compressed-data errors.

For the separately supplied external binding record:

- actual SHA-256: `b62aaa15784fe5a71eece4ffadd21814bace6fe9f3c6c36e4356335368083e79`.

The binding record names the external-after-ZIP mechanism, the exact r2 ZIP name/size/hash, central-directory count, exact source base, official OpenFHE commit, task hash, internal handoff hash, and the packaging verification outcomes.

## Independently rechecked internal identities

Fresh extraction / supplied extracted working tree checks:

- `HANDOFF_CONTENTS.md` SHA-256: `af07d16bb5815a2276a33e9c0554a40da9a1216dbbca723ca750698d4d989508`;
- `TENSOR2_TASK.md` SHA-256: `5a932619c5916b32d1dc5e1de2de253f39c041954d096db291a944ef0161d2c6`;
- `MANIFEST.sha256`: `1,961` entries;
- `sha256sum -c MANIFEST.sha256`: exit `0`, `1,961/1,961` entries verified;
- production header SHA-256: `7c45776cf1eba1db9efab5fa3c69e728c2c4d5e24239103184b4185afbbc9611`;
- production source SHA-256: `61cfe9bb07fd6c4c9ca4afa87265e1dc14e30693ceb9968df63f56df9bd7e05c`;
- existing DCP/RCB test SHA-256: `9f93e3794183d545338462bd7b6d5b9ccc787dc27b8555359f0dda7349105596`;
- paper PDF SHA-256: `61d9b948b17b6a624d3bf3372462555288308011226d2893e9e6bc3d6d197eac`.

The internal handoff identifies exact source base `87c84b879c13b55cf15d6559d3317853228fdc05` and official OpenFHE 1.5.0 `df495ba2e91739a6dc8f1de254fc5a41155ce504`. The supplied base CI JSON independently contains `headSha=87c84b879c13b55cf15d6559d3317853228fdc05`, conclusion `success`, and run URL ending in `33411494861`.

The source package contains no `.git`, so those commit identities are binding handoff/CI identities rather than locally recomputed `git rev-parse` results.

## Packaging/security-record boundary

The corrected internal and external handoff records both state:

- Gitleaks `8.30.1` staged-tree scan: approximately 24.53 MB, no leaks;
- Gitleaks `8.30.1` fresh-extraction scan: approximately 24.53 MB, no leaks;
- external binding scan: approximately 3.05 KB, no leaks;
- targeted secret/state/build exclusions passed;
- fresh extracted tree was recursively byte-identical to the final staged payload.

`gitleaks` is not installed in this execution container, so those Gitleaks results are accepted as **recorded handoff evidence and were not falsely claimed as locally rerun**. Local targeted checks found no `.env`, credential/token JSON, PEM/P12/PFX material, SSH private-key filenames, browser Cookie/Login Data databases, `.git`, `node_modules`, build/CMakeFiles, cache, or runtime-state directories.

The staged-vs-extracted recursive equality cannot be independently replayed without Codex's original staging directory; it is present in both corrected handoff records. The full extracted manifest and archive integrity were independently rechecked locally.

No fact from the earlier blocked attachment was used to supply an algorithm conclusion, test patch, source patch, build result, or Tensor2 execution result.
