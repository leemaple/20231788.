# Tensor2 clean-room review and scale proof

## Bounded decision

The Tensor2 slice is **not blocked by the scale contract**. The paper and the supplied pristine OpenFHE 1.5.0 source support a two-layer contract:

1. paper/logical scaling uses the actual integer prime `q_div`; and
2. OpenFHE FIXEDMANUAL bookkeeping uses its configured real `baseSF = CryptoParametersCKKSRNS::GetScalingFactorReal(0)`.

Those quantities are deliberately not equated. Tensor2 performs the paper's actual division by `q_div` through the pair representation itself, without consuming a tower. The only additional normalization needed after OpenFHE's raw ciphertext multiplications is metadata-only: one FIXEDMANUAL scale degree is removed and the recorded floating scaling factor is divided by `baseSF`. No polynomial coefficient, RNS tower, basis order, or level is changed by this normalization.

## Authorities and evidence boundary

Mathematical authority is the supplied IACR ePrint 2023/1788. Implementation-platform facts below are observations from the supplied pristine OpenFHE 1.5.0 source bound to commit `df495ba2e91739a6dc8f1de254fc5a41155ce504`. The project design choices are called out separately as inferences.

No previous/private 2023/1788 implementation was used.

## Paper equation to code mapping

### Fixed-point and pair-tensor identity

On paper page 7, immediately before Section 4.1, the fixed-point decomposition is

`m_i = q_div * high_i + low_i`.

The paper expands the product and states that for the target fixed-point precision the `low_1 * low_2` term is discarded. Definition 4.1 then defines

`Tensor2((h1,l1),(h2,l2)) = (h1 tensor h2, h1 tensor l2 + l1 tensor h2)`

with both members in `R^3_{Q_l}`. Therefore the implementation maps directly to exactly three OpenFHE no-relinearization multiplications:

- `high3 = EvalMultNoRelin(left.high, right.high)`;
- `cross12 = EvalMultNoRelin(left.high, right.low)`;
- `cross21 = EvalMultNoRelin(left.low, right.high)`;
- `low3 = cross12 + cross21`;
- no `EvalMultNoRelin(left.low, right.low)` call exists.

The working modulus remains `Q_l`.

### Lemma 4.2 and the paper-scale transition

Lemma 4.2 gives, modulo `Q_l`, the decrypted relationship

`Tensor(ct1,ct2) = q_div * RCB(Tensor2(CT1,CT2)) + Dec(low1) * Dec(low2)`

under `(1,s,s^2)`. The text following the lemma explicitly interprets Tensor2, when the centered-range condition holds, as approximately the ordinary tensor plaintext divided by `q_div`, with no modulus consumption.

Let the existing DCP manifest for pair `i` provide:

- `R_i = pair_i.GetPaperScale().inputRecordedScalingFactor`, the scale of the value reconstructed by `q_div * high_i + low_i`; and
- `H_i = pair_i.GetPaperScale().approximateLogicalScalingFactor = R_i / q_div`, the DCP high-component logical scale.

The already-reviewed DCP descriptor is sufficient to derive both input values and does not need to change.

For the high output, Definition 4.1 contains `high_1 tensor high_2`, so

`H_out = H_1 * H_2`.

For the recombined Tensor2 output, Lemma 4.2 contributes one division by the actual `q_div`, so

`R_out = R_1 * R_2 / q_div`.

These are separate result invariants. The Tensor result therefore gets a separate minimal descriptor containing only `H_out` and `R_out`; the DCP `PaperScaleDescriptor` and public DCP/RCB API remain frozen.

As a consistency consequence, because `H_i = R_i/q_div`, `q_div * H_out = R_out`; this is not used to substitute `baseSF` for `q_div`.

## Observed OpenFHE 1.5.0 behavior

### `EvalMultNoRelin` arithmetic and raw metadata

`src/pke/include/cryptocontext.h:1968-1972` shows that public `EvalMultNoRelin` first performs `TypeCheck` and then calls the scheme's `EvalMult`.

`src/pke/lib/schemerns/rns-leveledshe.cpp:182-192` clones both ciphertexts, calls `AdjustForMultInPlace`, and then `EvalMultCore`. Under FIXEDMANUAL, `AdjustForMultInPlace` calls only `AdjustLevelsInPlace` (`rns-leveledshe.cpp:479-485`); equal-basis level-1 inputs therefore do not lose a tower or receive a coefficient rescale.

`src/pke/lib/schemebase/base-leveledshe.cpp:620-660` shows that two two-component ciphertexts are convolved into exactly three components and that the raw result receives:

- `noiseScaleDeg = degree_1 + degree_2`;
- `scalingFactor = SF_1 * SF_2`.

For the current DCP members, each input degree is 2. Thus every raw Tensor2 product has degree 4 before project-owned normalization.

### FIXEDMANUAL's recorded one-rescale metadata transition

`src/pke/lib/scheme/ckksrns/ckksrns-leveledshe.cpp:172-190` is the relevant CKKS rescale bookkeeping. `ModReduceInternalInPlace` performs the actual polynomial `DropLastElementAndScale`, decrements the noise-scale degree, increments the level, and divides the floating recorded scaling factor by `GetModReduceFactor(...)`.

`src/pke/include/schemerns/rns-cryptoparameters.h:601-620,637-649` states that for FIXEDMANUAL both `GetScalingFactorReal(...)` and `GetModReduceFactor(...)` return the same configured approximate scaling factor `m_approxSF`. Define

`baseSF = CryptoParametersCKKSRNS::GetScalingFactorReal(0)`.

Therefore the OpenFHE bookkeeping for one FIXEDMANUAL rescale is a one-degree reduction and division of the recorded floating factor by `baseSF`; the actual RNS prime used by the coefficient operation is not required to equal that floating bookkeeping value.

## Scale-contract proof and design inference

The raw OpenFHE multiplication result is degree 4 with recorded factor `SF_1 * SF_2`. Independently, the paper proves that Tensor2's pair arithmetic already contributes one actual division by `q_div` while leaving modulus `Q_l` unchanged.

A normal OpenFHE rescale would combine two effects:

1. an actual coefficient/modulus operation by the current RNS prime; and
2. the FIXEDMANUAL metadata transition `degree - 1`, `factor / baseSF`.

Tensor2 already supplies the first *logical* scale-reduction effect through the actual `q_div` pair identity and must not perform a second coefficient division or drop a tower. To place the result on OpenFHE's corresponding FIXEDMANUAL scale schedule, only effect (2) is applied to the result metadata.

Hence the proved project result metadata contract is:

`recordedSF_out = SF_1 * SF_2 / baseSF`

`noiseScaleDegree_out = degree_1 + degree_2 - 1 = 3`

with unchanged level 1 and unchanged ordered `Q_l` basis.

This is a **design inference grounded in the paper and the observed OpenFHE bookkeeping**, not a claim that `EvalMultNoRelin` itself emits degree 3. It does not equate `q_div` and `baseSF`; the tests derive paper `H_out`/`R_out` with the actual divisor and derive the OpenFHE recorded factor with `baseSF` separately. The tests also assert that the actual divisor is not silently substituted for `baseSF`.

## Validation and result contract

`Tensor2(left,right)` must complete all project validation before any raw element access or OpenFHE arithmetic:

1. call the existing complete `ValidatePair` path on `left`;
2. call the same path on `right`;
3. reject any mutual incompatibility, in particular key tag or slots, with project-owned `std::invalid_argument` and the stable `DoubleCKKS: ` prefix;
4. only then invoke OpenFHE arithmetic.

The final result is a distinct read-only `TensorCiphertextPair` whose constructor is private to `DoubleCKKS`. Each member must have exactly three RLWE components. The result manifest exposes the same invariant facts needed by callers/tests as `CiphertextPair`, except there is no lifecycle state, and it adds a separate `TensorScaleDescriptor` for `H_out` and `R_out`.

The existing `PaperScaleDescriptor`, `CiphertextPair`, DCP arithmetic, RCB arithmetic, and public DCP/RCB signatures are unchanged.

The ordered TDD seam is deliberate: `01-red-api.patch` contains no production implementation; `02-api-scaffold.patch` introduces the final declarations but labels its immediate-throw body explicitly non-mergeable; `03-red-tensor2-contract.patch` adds all four runtime contract cases without changing production behavior; only `04-green-tensor2.patch` removes that scaffold and supplies the complete result.

## Test oracle and witnesses

The Tensor2 behavioral tests use only the public pair/result seam. Expected multiplication values are calculated by a test-owned Boost `cpp_int` schoolbook negacyclic convolution in `Z_q[X]/(X^N+1)` for every output component, coefficient, and active tower; expected values never call OpenFHE multiplication.

The deterministic pair fixtures are constructed by choosing explicit desired DCP `(high,low)` coefficient vectors and forming source coefficients `q_div*high + low` before calling the public DCP path. The encrypted shell is created through OpenFHE only to obtain valid context/key/encoding metadata; its RLWE elements are then replaced by the explicit coefficient fixtures before DCP. OpenFHE key generation/encryption RNG is not controlled, so no claim of global deterministic execution is made; the arithmetic coefficients under test are deterministic and independent of those random samples.

The required distinguishing witnesses are:

- negacyclic wrap: left high component 0 contains `X^(N-1)` and right high component 0 contains `X`, so high output component 0 has the explicit `X^N = -1` contribution at coefficient 0;
- signed modular wrap: left high component 1 constant is `-1,000,003` and right high component 1 constant is `1,000,033`, so their negative product has magnitude about `10^12`, explicitly checked to exceed a named active approximately-30-bit tower modulus before modular reduction;
- omitted low-low: left low component 0 has coefficient 2 equal to `17`, right low component 0 has coefficient 3 equal to `-19`, giving an independent low-low component-0/coefficient-5 contribution `-323`, nonzero modulo named active tower 0. The actual Tensor2 low member is asserted equal to the cross term and unequal to cross-plus-low-low at that witness.

## Assumptions and unresolved/pending items

- This slice supports only the existing `ReadyForFirstMult` DCP output. No new lifecycle value or invalid-lifecycle test is introduced.
- `EvalMultNoRelin` public `TypeCheck` is not relied upon for project invariants; both pairs and mutual fields are validated first.
- No Relin2, RS2, Mult2, second multiplication, serialization, pair Add/Sub, refresh, `t>2`, compatibility layer, or performance path is included.
- Local execution in this delivery environment is Debian GNU/Linux 13, not the required GitHub `ubuntu-24.04`/Windows runners. GitHub Actions and Windows results therefore remain explicitly pending for downstream application; no CI was dispatched by this task.
