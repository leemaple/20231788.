# Tensor2 ordered TDD and hosted-evidence audit

## Scope

This audit distinguishes four evidence classes:

1. **local replay/execution** performed during this closure review;
2. **raw retained remote evidence** actually present in the packet;
3. **retained summaries** whose underlying raw provider artifacts are not in the packet;
4. **unrun/cancelled** work.

No provider workflow was dispatched, rerun, or cancelled during this review.

## Exact base / patch-chain reconstruction

The final current tree was used with `PROJECT_DIFF.patch` to reconstruct the
exact base content. The base-to-head patch then passed `git apply --check` and,
when reapplied, produced a recursively byte-identical current tree
(`roundtrip_diff_bytes=0`).

The five preceding delivery patches were hashed and replayed in order. All
hashes matched:

```text
758dfdbc1c28099749d65be3438ea245d24e66d0b90793443137b8997f4b7723  01-red-api.patch
e725c1e9d289f733ec5aeb25e209431ae5045bfc1daba66a9fd4effc9d66a31d  02-api-scaffold.patch
38d5857430504527d9a8fe3441938364c3d12c36f0eb65dc6427ca0512e37416  03-red-tensor2-contract.patch
27d10a4a929f4f7d994c2aa477d607723be41e606f60de8af5b6c62879a04fb2  04-green-tensor2.patch
be3b2c0bad3bd86bbdf6d0a9f7bc6a210e80f14e6e9978105d9747e53ef29703  05-final-docs.patch
```

All five sequential `git apply --check` operations returned 0. The preceding
delivery ZIP's 22 extracted files were inspected; its retained local evidence
matches the replayed behavior.

## Boundary 1 — compile-only API red

### Supplied history

Commit: `f3db12ef9fb0d13df0f779157eed168b8d582ea4`.

`01-red-api.patch` adds build/workflow registration and the compile-only API
contract; no production header/source is added by that patch.

### Local execution

On reconstructed exact base plus patch 01:

- configure: exit 0;
- strict build: exit 2;
- existing production library and `dcp_rcb_test` built;
- compile-only Tensor2 API test failed because
  `TensorCiphertextPair`, `TensorScaleDescriptor`, and `DoubleCKKS::Tensor2`
  were absent;
- CTest was intentionally not run.

This is the intended compile red.

### Retained hosted claim

`tdd/compile-red-api-01.txt` names run `33425868973`, exact project SHA
`f3db12...`, Linux red, and cancelled Windows. No raw run/jobs/job-log artifact
for this run is present. These provider details are therefore retained claims,
not independently reverified remote evidence.

## Boundary 2 — non-mergeable scaffold

Commit: `76bac1800553f79c1dbaff15ccebf6e50c65ad89`.

Patch 02 supplies the final public type/API seam and an implementation that
immediately throws `std::logic_error("DoubleCKKS: Tensor2 is not implemented")`.
Source inspection confirms the throw precedes any ciphertext access or OpenFHE
arithmetic. The patch itself identifies the scaffold as non-mergeable.

Local replay:

- configure: 0;
- build: 0;
- CTest: 1/1 `dcp_rcb` passed.

No Tensor behavioral tests exist yet at this boundary, so this is not called a
behavioral green.

## Boundary 3 — complete runtime red

### Original public behavioral patch

Commit: `6f17c55df7c94edbe390eff42d891522a0c86e17`.

Local exact replay after patches 01-03:

- configure: 0;
- build: 0;
- CTest: exit 8;
- `dcp_rcb`: passed;
- all four Tensor2 tests independently executed and failed;
- valid-operation cases failed on the scaffold `logic_error`;
- negative cases explicitly rejected the scaffold `logic_error` as the wrong
  exception type.

Result: 1/5 passed, 4/5 failed. No first failure masked another case.

### Order-sensitive key-tag hardening

Commit: `482d27d0c43c22779aa548e00955ed90175dee97` adds the fifth Tensor case.

The exact commit cannot be reconstructed from a standalone per-commit patch in
the packet, but the current fifth test was overlaid on the unchanged scaffold
for a review-only behavior check. Local result:

- configure: 0;
- build: 0;
- CTest: exit 8;
- `dcp_rcb`: passed;
- all five Tensor cases independently failed on the scaffold, including
  `tensor2_prearithmetic_key_compatibility`.

This is behavior-equivalent local evidence for the fifth red; it is not falsely
described as a Git-object reconstruction of commit `482d27d0...`.

### Retained hosted claim

`tdd/runtime-red-contract-01.txt` reports run `33426712752` at exact test head
`482d27d0...`, Linux 1/6 with five intended Tensor failures, and cancelled
Windows. Raw provider run/jobs/job logs for this run are not in the packet.

## Boundary 4 — first implementation green

Commit: `1408d46217e97a1c14d43d49b64791da22f652da`.

On reconstructed base plus preceding patches 01-04 (the original four Tensor
behavioral tests):

- configure: 0;
- build: 0;
- CTest: 5/5 passed.

The packet's retained summary `tdd/linux-green-implementation-01.txt` reports
hosted run `33427271692` at the exact production commit with the already-added
fifth key-tag test and Linux 6/6, after which Windows was cancelled. The raw
provider records for that intermediate run are not supplied, so its provider
binding remains summary-level evidence.

## Boundary 5 — docs

Patch `05-final-docs.patch` applies after production green and changes
documentation only. The full current `COMMIT_HISTORY.txt` places later
shared-validator refactor and final documentation/workflow naming after this
boundary.

The previous 22-file delivery's own final local evidence reports configure 0,
build 0, CTest 5/5 for the original four Tensor tests plus `dcp_rcb`.

## Downstream key-tag test / shared-validator refactor

The downstream key-tag test is technically meaningful. Current
`tests/tensor2_test.cpp:621-643` makes two individually valid same-context,
same-slot pairs with distinct key tags and requires the module-owned diagnostic.
Pristine OpenFHE `CryptoContext::EvalMultNoRelin` invokes `TypeCheck`, which
also rejects mismatched key tags. Therefore multiply-before-mutual-validation
would be observable as the wrong exception attribution.

The shared-validator refactor removes Tensor-only duplication and preserves
validation predicates, but it does not preserve every legacy two-component
diagnostic byte-for-byte: see P3-01 in the main review.

## Exact current final hosted gate — raw retained evidence

Run: `33428194982`, attempt 1, event `push`.

`ci/run.json` directly records:

- status `completed`;
- conclusion `success`;
- `head_sha = 55f3b43c47b5b2464625afcc6a1f244724336d5b`;
- head tree `2269bee6bac5e7cd1124ab78c49a750af9a38942`.

`ci/jobs.json` lists exactly two successful jobs.

Linux raw log:

- `ubuntu-24.04`;
- exact current project checkout;
- exact OpenFHE `df495ba...`;
- CMake 3.31.6;
- GCC 13.3.0;
- strict project build succeeds;
- all 6 CTest entries pass;
- total CTest time 0.19 s.
- OpenFHE install was restored from an exact-commit cache; provenance checkout
  was still verified.

Windows raw log:

- Windows Server 2022;
- MSYS2 `MINGW64`;
- exact current project checkout;
- exact OpenFHE `df495ba...`;
- CMake 4.4.2;
- GCC 16.2.0;
- pristine OpenFHE configured/built/installed in the job;
- project strict build succeeds;
- all 6 CTest entries pass;
- total CTest time 0.20 s.

These are retained remote results. They were inspected, not rerun.

## Cancelled / unrun matrix

| Boundary | Linux | Windows | Evidence class |
|---|---|---|---|
| API compile red | red claimed remotely; red independently reproduced locally | cancelled per retained summary | early remote raw log absent |
| Scaffold | local build + 1/1 DCP only | not required | local |
| Complete runtime red | red claimed remotely; red independently reproduced locally | cancelled per retained summary | early remote raw log absent |
| First implementation green | green claimed remotely; green independently reproduced locally (original 5-test stage) | cancelled per retained summary | early remote raw log absent |
| Exact current head | success 6/6 | success 6/6 | complete raw retained final CI evidence |
| Included closure-fix patch | local Linux 6/6 | **not run** | local only; new hosted exact-head CI required after application |

No red Windows run was required by the original TDD contract. No current review
workflow was dispatched.

## History / rewrite boundary

`COMMIT_HISTORY.txt` presents an ordered linear sequence retaining red and green
evidence commits. The exact base-to-head binary patch and all five original
patches replay consistently. The external package binding also states that
`cleanroom-project/` was byte-identical to a fresh Git archive of the exact
tree.

However, the package intentionally excludes `.git`; therefore this reviewer
cannot independently traverse the Git object graph or prove at object level
that no earlier history was rewritten. That point remains a provenance
limitation rather than a source-correctness claim.
