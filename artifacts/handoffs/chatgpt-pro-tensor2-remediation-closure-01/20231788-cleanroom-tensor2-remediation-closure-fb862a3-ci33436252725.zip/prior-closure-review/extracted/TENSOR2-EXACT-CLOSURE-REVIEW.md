# Tensor2 exact-current closure review

Reviewed: 2026-09-01 Asia/Singapore/Shanghai (+08:00)

## Bounded verdict

**NEEDS NAMED FIXES**

This verdict is bound only to branch `agent/codex-tensor2-01`, exact current head
`55f3b43c47b5b2464625afcc6a1f244724336d5b`, Git tree
`2269bee6bac5e7cd1124ab78c49a750af9a38942`, and pristine OpenFHE 1.5.0
`df495ba2e91739a6dc8f1de254fc5a41155ce504`.

Finding counts:

| Severity | Count |
|---|---:|
| P0 | 0 |
| P1 | 0 |
| P2 | 1 |
| P3 | 1 |

The bounded Tensor2 arithmetic, scale separation, result type, validation order,
independent oracle, immutability checks, and exact-head Linux/Windows CI are
substantively correct. The current head is not closed for merge because (1) the
closure packet does not contain the raw hosted records needed to independently
re-bind the three intermediate TDD runs that the task explicitly says are
supplied with complete logs, and (2) the shared-validator refactor introduced a
small but real DCP diagnostic compatibility regression. A minimal current-head
source/test patch for the latter is included.

Applying that patch creates a new source head, so Actions run `33428194982`
cannot be reused as final evidence for the patched tree. The repaired head must
receive a new exact-head Linux/Windows run and the separately required
Windows ZCode/Zima same-commit review before a later reviewer can issue
`MERGEABLE`.

## Input-package gate

**PASS.** Work continued only after the corrected exact-current package gate
matched.

Independently recomputed:

- ZIP size: `8,919,510` bytes.
- ZIP SHA-256:
  `31c96c983cdff1613ab0f95972655d7c5314e420ea585c358de234c4eb0ff785`.
- ZIP central-directory entries: `2,271`.
- `unzip -t`: exit `0`.
- Internal `HANDOFF_CONTENTS.md` SHA-256:
  `540b26f3e2935a323821243a90f282cce9fb17563c03fbd6c7965b1a096d9ba1`.
- Internal `MANIFEST.sha256` SHA-256:
  `c5d45ed54c528a68adfcb82c1edeb418ec6cdb9ea021cb2150033bd17aaa7c4f`.
- Manifest: `2,005/2,005` files verified.
- Internal `FINAL_REVIEW_TASK.md` was byte-identical to the separately attached
  `chatgpt-pro-tensor2-final-review-01.md`; SHA-256
  `1421ec8bf9f23e67eae9ee1b871b4d8422c49569174d1258693429319f285eb4`.
- Bound head/tree/run/OpenFHE identities match the external and internal
  records.

The package-recorded Gitleaks results were inspected as retained packaging
evidence. Gitleaks was not rerun locally during this review.

## Findings

### P2-01 — Early hosted TDD run provenance is summarized, not supplied as raw hosted evidence

**Location / requirement:** `FINAL_REVIEW_TASK.md:143-145` says that all TDD
identities are supplied with complete logs and asks the reviewer to inspect
their `headSha`, commands, failure attribution, and test counts rather than
accepting a summary. The relevant retained claims are in:

- `tdd/compile-red-api-01.txt:10-21,29-44` for run `33425868973`;
- `tdd/runtime-red-contract-01.txt:16-26,35-62` for run `33426712752`;
- `tdd/linux-green-implementation-01.txt:10-20,29-42` for run `33427271692`.

**Proof:** Recursive inspection of the supplied packet found raw GitHub API
records/job logs only for the final run under `ci/` (`run.json`, `jobs.json`,
`linux-gcc.log`, `windows-mingw64.log`). The three earlier run IDs occur in
retained summary text, but no corresponding earlier-run raw API JSON or hosted
job-log file is present.

**Reachable impact:** This does **not** undermine current source correctness:
the exact TDD patch boundaries were independently replayed locally, and the
final exact-head run has complete raw Linux/Windows evidence. It does mean that
the review cannot independently verify the earlier provider-side `headSha`,
job IDs, cancellation timing, and hosted exit/test records from raw provider
artifacts as the task requests. Those facts remain **retained remote claims**,
not independently reverified hosted evidence.

**Smallest remediation:** supply the raw run JSON, jobs JSON, and relevant
Linux/Windows job logs (with hashes) for runs `33425868973`, `33426712752`, and
`33427271692` in the successor closure packet. No production code change is
needed for this finding.

### P3-01 — Shared-validator refactor changed one reachable legacy DCP diagnostic

**Current-head location:** `cleanroom-project/src/double_ckks.cpp:244-305`
parameterizes the shared validator; `:278-280` emits key-tag state diagnostics,
and `:324-325` calls it from `ValidateDcpInput` with state label `"ciphertext"`.

**Base-to-head proof:** `PROJECT_DIFF.patch:569-607` shows that the pre-refactor
validator used the literal wording `"pair state"` for the same key-tag check,
while the DCP call was changed to pass `"ciphertext"`. The refactor commit
`5bdf9c9af90aa44989401693489af994acf323c4` states that existing
two-component diagnostics were preserved byte-for-byte.

**Executed proof:** A review-only probe cloned a valid fresh DCP input, called
`SetKeyTag("")`, and required the legacy diagnostic. On the reconstructed exact
base, the augmented `dcp_rcb_test` passed. On exact current head, the same probe
failed with:

`DoubleCKKS: DCP input key tag does not match its ciphertext state`

instead of the legacy:

`DoubleCKKS: DCP input key tag does not match its pair state`

This path is reachable because `ValidateDcpInput` does not reject an empty key
tag before the shared validator. Exception type, `DoubleCKKS:` prefix,
fail-before-arithmetic behavior, and the actual validation predicate remain
correct.

**Reachable impact:** diagnostic compatibility/evidence accuracy only. DCP/RCB
arithmetic, Tensor2 arithmetic, validation ordering, and metadata invariants are
unchanged. Existing `dcp_rcb_test.cpp` did not cover this one input diagnostic,
which is why exact-head CI remained green.

**Smallest remediation:** `0001-tensor2-exact-closure-fixes.patch` changes the
DCP caller's state label back to `"pair"` and adds one regression assertion for
the empty-key-tag DCP input. The patch applies cleanly to exact current head and
was locally built/tested 6/6.

## Evidence-class separation

### Observed current-source facts

- `DoubleCKKS::Tensor2` calls `ValidatePair(left)`, `ValidatePair(right)`, then
  `ValidateTensorCompatibility(left,right)` before taking raw member handles:
  `src/double_ckks.cpp:508-516`.
- Exactly three production `EvalMultNoRelin` calls occur:
  `src/double_ckks.cpp:518-520`. The only combination is `EvalAdd` of the two
  cross terms at `:521-523`. There is no low-low product.
- No production `ModReduce`, relinearization, `try`, or `catch` exists in this
  slice.
- Tensor output metadata is normalized only through setters at
  `src/double_ckks.cpp:525-539`; no tower or coefficient operation occurs
  there.
- The result paper-scale descriptor is calculated from both input manifests and
  actual `divisor_` at `:541-546`.
- Result validation enforces basis/level, three components, degree 3, recorded
  factor, key tag, slots, and the two paper scales at `:461-505`.
- `TensorCiphertextPair` is a distinct final type with read-only ciphertext
  getters and private construction: `include/openfhe_2023_1788/double_ckks.h:86-133`.
  It has no lifecycle member.

### Mathematical derivation

From the supplied paper page 7, Definition 4.1 gives the pair tensor

`(h1 tensor h2, h1 tensor l2 + l1 tensor h2)`

and deliberately omits `l1 tensor l2`. Lemma 4.2 relates the ordinary tensor to
`q_div` times recombined Tensor2 plus the omitted low-low term. Therefore:

- `H_out = H_1 * H_2`;
- `R_out = R_1 * R_2 / q_div`.

The actual prime `q_div` is the paper/logical divisor.

### Observed pristine OpenFHE source facts

- Public `EvalMultNoRelin` calls `TypeCheck` before delegating to scheme
  multiplication: `src/pke/include/cryptocontext.h:1968-1972`.
- `TypeCheck` itself rejects different key tags:
  `cryptocontext.h:263-288`.
- Under FIXEDMANUAL, multiplication only aligns tower counts before
  `EvalMultCore`: `rns-leveledshe.cpp:182-191,393-400,479-484`.
- Two 2-component inputs produce 3 components; raw degree is the sum and raw
  recorded factor is the product:
  `base-leveledshe.cpp:620-660`.
- FIXEDMANUAL `GetScalingFactorReal` and `GetModReduceFactor` return the fixed
  approximate factor:
  `rns-cryptoparameters.h:601-620,636-649`.
- A real CKKS `ModReduceInternalInPlace` changes the degree/level, physically
  drops/scales a tower, and divides the recorded factor:
  `ckksrns-leveledshe.cpp:172-190`.

### Module-design inference

The paper provides one logical division by the actual `q_div` without modulus
consumption, while raw OpenFHE multiplication produces degree 4 and
`SF_1*SF_2`. For this supported first lifecycle, the module intentionally
represents the paper and OpenFHE schedules separately:

- paper: actual `q_div`, with the two equations above;
- OpenFHE bookkeeping: degree `3` and recorded factor
  `SF_1*SF_2/baseSF`, where
  `baseSF = GetScalingFactorReal(0)`.

This metadata-only normalization is a project integration contract derived from
the paper plus OpenFHE's FIXEDMANUAL schedule; it is not an assertion that
OpenFHE automatically performs it, and it does not equate `q_div` with
`baseSF`.

### Retained remote execution evidence

Complete raw retained evidence exists for exact final run `33428194982`:

- `ci/run.json` binds `head_sha` to exact current head and conclusion `success`;
- `ci/jobs.json` lists exactly two successful jobs;
- `ci/linux-gcc.log`: `ubuntu-24.04`, CMake 3.31.6, GCC 13.3.0, 6/6 CTest;
- `ci/windows-mingw64.log`: Windows 2022/MSYS2 MINGW64, CMake 4.4.2,
  GCC 16.2.0, pristine OpenFHE built and project 6/6 CTest.

These are inspected **remote** records, not local execution.

### Local execution

A local Linux review build against a locally built/installed supplied pristine
OpenFHE source used CMake 3.31.6 and GCC 14.2.0. Exact current head configured,
strict-built, and passed 6/6 CTest. Ordered red/scaffold/red/green boundaries
were also replayed locally. The diagnostic regression was reproduced on base
versus current, and the included fix patch applied cleanly and passed local
6/6 CTest.

No local Windows run, hosted CI dispatch, precision benchmark, performance
benchmark, or security test was performed.

### Unverified claims

- The exact provider-side `headSha`/jobs/log contents of the three intermediate
  hosted runs remain unverified because their raw hosted records are absent
  (P2-01).
- Because the supplied source export has no `.git`, the complete object-level
  assertion that history was never rewritten cannot be cryptographically
  recomputed locally. `COMMIT_HISTORY.txt`, exact base-to-head diff replay, and
  current-tree Git-archive binding are consistent with the stated linear
  history, but they are not a substitute for the Git object graph.
- No claim is made about Relin2, RS2, Mult2, pair Add/Sub, repeated
  multiplication, precision, performance, or security.

## Answers to the nine required questions

### 1. Definition 4.1 arithmetic

**PASS.** Exact head performs exactly:

1. `h1 tensor h2`;
2. `h1 tensor l2`;
3. `l1 tensor h2`;
4. one addition of products 2 and 3.

There is no `l1 tensor l2` multiplication. Static inspection finds exactly
three production `EvalMultNoRelin` calls. No tower drop, `ModReduce`, or
relinearization is present.

### 2. `H_out`, `R_out`, degree, and recorded factor

**PASS.** The result type separately records `H_out` and `R_out`; the production
calculation uses the two input paper descriptors and the actual integer divisor.
The tests independently compute both expectations from inputs. The test also
asserts `q_div != baseSF` in the fixture. Degree `3` and
`SF_1*SF_2/baseSF` are maintained as the distinct FIXEDMANUAL metadata
schedule. The latter is a module-design inference, not a paper equation or an
automatic OpenFHE transition.

### 3. Validation order and key-tag observability

**PASS.** Both complete pair validators and mutual compatibility run at
`src/double_ckks.cpp:509-511`, before raw member access at `:513-516` and
arithmetic at `:518`. The current key-tag test is genuinely order-sensitive:
it creates individually valid pairs with different key tags, requires the
project-owned `std::invalid_argument`, stable prefix, and field message
(`tests/tensor2_test.cpp:621-643`); OpenFHE's own `TypeCheck` would otherwise
reject that mismatch first.

### 4. Distinct result type/state boundary

**PASS.** `TensorCiphertextPair` is distinct, final, privately constructed by
`DoubleCKKS`, exposes read-only ciphertext pointers, records exactly the
necessary invariant facts, and has no speculative lifecycle enum/state. It
therefore cannot be passed to the existing `CiphertextPair`-typed DCP/RCB seam.

### 5. Independent oracle, witnesses, immutability, metadata

**PASS.** The test oracle is Boost `cpp_int` schoolbook negacyclic convolution
and does not call OpenFHE multiplication
(`tests/tensor2_test.cpp:265-371`). It covers every output component/tower/
coefficient. The fixture/assertions include:

- `X^(N-1)*X=-1`: `:231-233,494-499`;
- signed modular wrap: `:235-237,501-506`;
- independently nonzero low-low `-323` at component 0/tower 0/coefficient 5:
  `:239-243,508-525`.

Whole observable ciphertext state, independent deep metadata-map values, and
all pair-manifest fields are snapshotted and compared
(`:62-115,373-437,527-528`). Result metadata and dual scale equations are
asserted independently at `:531-585`.

### 6. Shared-validator refactor

**FAIL, narrowly (P3-01).** Validation predicates and module attribution are
preserved, and the original `dcp_rcb_test.cpp` is byte-identical from base to
current. Pair diagnostics remain on state label `"pair"`. However the DCP input
call changed one reachable deep key-tag diagnostic from `"pair state"` to
`"ciphertext state"`, contradicting the refactor's byte-for-byte compatibility
claim. The included patch restores it and adds coverage.

### 7. Ordered TDD/history/hosted gates

**QUALIFIED FAIL (P2-01).**

What is independently established:

- all five preceding patches retain the supplied hashes and pass ordered local
  `git apply --check`;
- exact base-to-head `PROJECT_DIFF.patch` reapplies to the reconstructed base
  and produces a byte-identical current tree;
- local replay reproduces compile red, fail-before-access scaffold, complete
  runtime reds, and green;
- exact final run `33428194982` has complete raw API/jobs/Linux/Windows logs and
  binds exact head with 6/6 on both hosted jobs.

What is not independently established from raw provider evidence:

- exact hosted bindings/log contents for the three intermediate runs, because
  only committed summaries are supplied;
- object-level no-history-rewrite proof, because no Git object database is
  supplied.

The stated Windows boundaries are otherwise coherent: compile-red and
runtime-red Windows jobs were cancelled; first-green Windows was cancelled;
only the final exact head has a completed Windows result.

### 8. Unsupported behavior/dependency/backdoor/portability/scope

**PASS for the implemented slice, subject to the two findings above.** No fourth
multiplication, low-low term, upstream OpenFHE modification, production
exception recovery, mutable Tensor constructor, test-only friend/backdoor,
new lifecycle, compatibility scaffold, or later-operation implementation was
found. Boost is test-only and is required by the specified independent oracle.
The exact final hosted Linux/Windows build gives direct retained portability
evidence for the unpatched head.

### 9. Exact-head verdict

**NEEDS NAMED FIXES.**

Required closure actions are bounded:

1. apply `0001-tensor2-exact-closure-fixes.patch`;
2. include raw provider records for the three intermediate hosted TDD runs, or
   explicitly replace the task's “complete logs supplied” requirement with a
   retained-summary boundary;
3. because item 1 changes source/test bytes, run a new exact patched head
   through the existing strict Linux and Windows workflow;
4. obtain the separately required Windows ZCode/Zima same-commit review.

No later operation should be added as part of this remediation.
