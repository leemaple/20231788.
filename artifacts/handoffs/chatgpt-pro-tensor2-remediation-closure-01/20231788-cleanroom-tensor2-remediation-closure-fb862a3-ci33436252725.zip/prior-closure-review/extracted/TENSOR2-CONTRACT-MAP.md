# Tensor2 contract map — exact head 55f3b43

Status values: **PASS**, **FAIL**, **QUALIFIED**, **N/A**.

| Contract area | Status | Evidence / reasoning |
|---|---|---|
| Input package identity | PASS | ZIP 8,919,510 bytes, SHA-256 `31c96c...f785`, 2,271 entries, internal handoff/manifest hashes match, 2,005/2,005 manifest files verify. |
| Exact source binding | PASS | Binding and raw final `ci/run.json` identify head `55f3b43...`, tree `2269bee6...`; `PROJECT_DIFF.patch` replays from reconstructed base to byte-identical final tree. |
| Paper Tensor2 high | PASS | Definition 4.1: `h1 tensor h2`; production `src/double_ckks.cpp:518`. |
| Paper Tensor2 low | PASS | Cross terms at `src/double_ckks.cpp:519-523`; no low-low multiplication. |
| Product count | PASS | Exactly three production `EvalMultNoRelin` calls. |
| Low-low omission | PASS | Independent `-323` witness and explicit cross-only vs cross-plus-low-low rejection at `tests/tensor2_test.cpp:508-525`. |
| Unchanged active basis / level | PASS | No `ModReduce`; result retains left ordered basis/level at `src/double_ckks.cpp:548-550`; result validation requires level 1 / first-pair basis at `:461-505`. |
| `H_out` paper scale | PASS | Production uses input high logical scales at `:541-543`; test expected value from inputs at `tests/tensor2_test.cpp:536-542`. |
| `R_out` paper scale | PASS | Production uses input recombined scales divided by actual `divisor_` at `src/double_ckks.cpp:543-546`; test derives from inputs at `tests/tensor2_test.cpp:538-542`. |
| `q_div` vs `baseSF` separation | PASS | `q_div` remains integer divisor; metadata uses `GetScalingFactorReal(0)`; test explicitly asserts inequality at `tests/tensor2_test.cpp:553-554`. |
| Raw OpenFHE multiplication metadata | PASS | Pristine OpenFHE `EvalMultCore` sets degree sum and factor product (`base-leveledshe.cpp:653-658`). Production verifies raw metadata before normalization (`src/double_ckks.cpp:531-534`). |
| Derived FIXEDMANUAL normalized degree/factor | PASS (bounded inference) | First lifecycle only: degree 3 and `SF1*SF2/baseSF`, metadata-only at `src/double_ckks.cpp:525-539`; consistent with paper's no-tower logical division and OpenFHE's physical-rescale schedule. Not claimed generic. |
| Distinct three-component type | PASS | `TensorCiphertextPair` at header `:86-133`, private constructor, no lifecycle, read-only ciphertext getters. |
| Complete left validation | PASS | `Tensor2` calls `ValidatePair(left)` at source `:509`. |
| Complete right validation | PASS | `Tensor2` calls `ValidatePair(right)` at source `:510`. Right manifest corruption test at `tests/tensor2_test.cpp:588-599`. |
| Mutual slot compatibility before arithmetic | PASS | Source `:511` precedes raw handles/multiplication; test `:601-619`. |
| Mutual key compatibility before arithmetic | PASS | Source compatibility key check `:447-448`; order-sensitive test `tests/tensor2_test.cpp:621-643`; OpenFHE `TypeCheck` would otherwise reject first. |
| Project exception attribution | PASS | `Invalid()` emits `std::invalid_argument("DoubleCKKS: ...")` at source `:11-13`; Tensor negative-test helper rejects other exception types at test `:42-60`. |
| Independent coefficient oracle | PASS | Boost `cpp_int` schoolbook negacyclic oracle at test `:265-371`, all 3 components, all active towers, all coefficients. |
| Negacyclic wrap witness | PASS | Fixture `:231-233`; assertion `:494-499`. |
| Signed modular wrap witness | PASS | Fixture `:235-237`; assertion `:501-506`. |
| Nonzero low-low witness | PASS | Fixture `:239-243`; assertion `:508-525`. |
| Input whole-state immutability | PASS | Independent metadata clone plus ciphertext/manifest snapshots at test `:62-115,373-437`; both operands checked at `:527-528`. |
| Result metadata completeness | PASS | Test `:560-585`; source result validation `:461-505`. |
| Existing DCP/RCB arithmetic/test regression | PASS | `tests/dcp_rcb_test.cpp` SHA-256 is identical at base and exact head; local and hosted final CTest pass. |
| Existing DCP/RCB diagnostic byte preservation | **FAIL (P3-01)** | DCP caller now passes `"ciphertext"` state label at source `:324-325`; an empty input key tag therefore changes legacy diagnostic text. Included patch restores `"pair"` and adds regression coverage. |
| Compile-red boundary | PASS locally / remote-qualified | Local exact patch replay: configure 0, build 2 with missing Tensor public API. Hosted run `33425868973` is only supplied as retained summary, not raw provider log. |
| Immediate scaffold boundary | PASS | Patch body immediately throws specified `logic_error`; local scaffold builds and only existing `dcp_rcb` is registered/passes. |
| Complete runtime red | PASS locally / remote-qualified | Original 4 Tensor cases fail independently on exact patch replay; current fifth key test also independently fails when overlaid on same scaffold. Hosted six-entry run `33426712752` lacks raw provider artifacts. |
| First production green | PASS locally / remote-qualified | Original patch boundary passes local 5/5; retained hosted summary claims 6/6 at `1408d462...`, but raw provider artifacts are absent. |
| Docs after behavioral green | PASS | Commit order and prior patch replay place `05-final-docs.patch` after implementation green. |
| Shared validator removes duplication | PASS | One parameterized `ValidateCiphertext` is used by DCP/pair/Tensor result. |
| Shared validator exact diagnostic compatibility | **FAIL (P3-01)** | One reachable DCP key-tag state word changed; predicates and project attribution remain correct. |
| Exact final hosted Linux gate | PASS retained remote | Raw `ci/run.json/jobs.json/linux-gcc.log`: exact head, `ubuntu-24.04`, CMake 3.31.6, GCC 13.3.0, 6/6. |
| Exact final hosted Windows gate | PASS retained remote | Raw Windows log: Windows 2022/MSYS2 MINGW64, CMake 4.4.2, GCC 16.2.0, pristine OpenFHE build + project 6/6. |
| Early hosted run raw evidence completeness | **FAIL (P2-01)** | Task says complete logs supplied, but packet has only retained summaries for runs `33425868973`, `33426712752`, `33427271692`. |
| Hidden production dependency | PASS | No new production dependency found; Boost is test-only for required oracle. |
| Production `try`/`catch` | PASS | None in `src/double_ckks.cpp`. |
| Later-operation scope creep | PASS | No pair Add/Sub, Relin2, RS2, Mult2, refresh, repeated multiplication, serialization, perf work, or compatibility framework added. |
| Precision/performance/security claims | N/A / not verified | Outside bounded slice; no such result is claimed here. |

## Net contract disposition

Arithmetic/numeric/OpenFHE integration: **PASS**.

Current exact-head closure: **FAIL pending named fixes** because P2-01 and P3-01
remain. The included code patch addresses only P3-01. P2-01 requires evidence,
not source code.
