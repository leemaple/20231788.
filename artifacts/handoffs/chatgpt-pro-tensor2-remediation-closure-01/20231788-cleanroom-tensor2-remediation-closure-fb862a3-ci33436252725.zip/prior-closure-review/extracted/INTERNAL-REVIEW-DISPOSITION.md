# Internal two-axis review disposition

Source reviewed: `reviews/tensor2-final-two-axis-review.md`.

Independent disposition does **not** inherit the internal PASS. Each substantive
conclusion is addressed below.

## Standards axis

| Internal conclusion | Disposition | Reason |
|---|---|---|
| `PASS`; no hard violations | **Partly agree** | I found no P0/P1 issue and no algorithmic hard violation. I did find one P3 current-head diagnostic regression and one P2 closure-evidence completeness issue. |
| Shared `ValidateCiphertext` removes duplication | **Agree** | Current header/source contain one parameterized validator used for two- and three-component states. |
| Shared validator preserves two-component validation and DCP/RCB field attribution/invariants | **Agree on predicates/invariants; disagree on byte-exact diagnostic preservation** | `ValidateDcpInput` now passes state label `"ciphertext"`, changing the reachable empty-key-tag message from legacy `"pair state"` to `"ciphertext state"`. Exception type/module attribution remain correct. |
| No production `try`/`catch`, speculative lifecycle/result hooks, upstream changes, or scope expansion | **Agree** | Static inspection and base-to-head diff support this. |
| Ordered TDD commits/retained evidence satisfy documented workflow | **Qualified disagreement** | Local patch replay establishes the behavioral ordering. Raw provider records for three intermediate hosted runs are absent despite the review task saying complete logs are supplied; their remote bindings remain retained summaries. |
| Exact head passed Linux/Windows final Actions, 6/6 each | **Agree as retained remote evidence** | Complete `ci/run.json`, `ci/jobs.json`, and both raw final job logs support exact head `55f3b43...`, run `33428194982`. |

## Spec axis

| Internal conclusion | Disposition | Reason |
|---|---|---|
| `PASS`; no missing/partial requirements | **Disagree narrowly** | Diagnostic-preservation claim is not exact (P3-01), and earlier hosted TDD raw evidence is incomplete for the requested closure audit (P2-01). |
| No scope creep; key-tag CTest directly strengthens pre-arithmetic boundary | **Agree** | The test is bounded and genuinely order-sensitive. |
| No incorrect Tensor2 implementation | **Agree for algorithm/numeric semantics** | Exactly three required products, correct cross addition, omitted low-low, unchanged basis/level, correct separated paper scales and bounded metadata schedule. |
| Exactly three production `EvalMultNoRelin`; no low-low or `ModReduce` | **Agree** | Direct source count/inspection confirms it. |
| Both pairs and mutual metadata validate before arithmetic | **Agree** | Source order is explicit at `src/double_ckks.cpp:509-518`. |
| Different-key-tag test is order-sensitive because OpenFHE TypeCheck also rejects key mismatch | **Agree** | Test `tests/tensor2_test.cpp:621-643`; pristine OpenFHE `cryptocontext.h:263-288,1968-1972`. |
| `q_div` paper scales and `baseSF` metadata remain separate | **Agree** | Production/test calculate them separately; test explicitly asserts inequality. |
| Distinct read-only result, complete oracle/witnesses, immutability satisfy spec | **Agree** | Public type, all-component/all-tower/all-coefficient oracle, all named witnesses, and deep metadata snapshots are present. |
| Retained artifacts establish red/scaffold/runtime-red/green/docs | **Agree for behavior; qualify hosted provenance** | Local replay plus prior local logs establish behavior. Intermediate hosted run bindings cannot be re-audited from raw provider logs in this packet. |
| Validation refactor preserves arithmetic and validation predicates | **Agree** | It does. |
| Validation refactor preserves diagnostics | **Disagree for one reachable DCP diagnostic** | P3-01. |
| Final run's earlier temporal pending note is resolved by exact evidence | **Agree** | Final raw run/jobs/logs are complete and successful. |

## Resolved key-tag finding

The downstream key-tag test is a valid closure improvement, not a false
positive.

- It constructs both pairs through the public DCP seam.
- It executes `RCB` on both pairs to re-run the complete existing pair
  validator and demonstrate individual validity.
- Slots match and key tags differ.
- The expected exception is project-owned `std::invalid_argument` with
  `DoubleCKKS:` prefix and `Tensor2 input key tags do not match`.
- Pristine OpenFHE `EvalMultNoRelin` calls `TypeCheck`, whose key-tag check
  would reject the first multiplication if the project multiplied too early.

Current production performs mutual compatibility before raw handles and
multiplication, so the test passes for the right reason.

## Final internal-review disposition

The internal reviews were correct on Tensor2 arithmetic, scale separation,
validation order, independent oracle, type boundary, and final CI. They missed:

1. the legacy DCP empty-key-tag diagnostic drift introduced by the shared
   validator refactor; and
2. the difference between retained summaries and raw provider evidence for the
   three intermediate hosted runs.

Therefore I do not adopt their overall zero-finding PASS.
