# Execution record

This file records only commands/actions actually run during this closure review.
Inspection is not converted into execution.

## Review environment

Local environment used for execution:

```text
Linux localhost 6.18.35 x86_64
CMake 3.31.6
c++ (Debian 14.2.0-19) 14.2.0
```

The supplied source/OpenFHE exports contain no `.git`. Commit/tree identities
are therefore package/remote-evidence identities, not local `git rev-parse`
claims.

## 1. Input gate

Actually run against the exact uploaded ZIP:

```sh
stat / file-size inspection
sha256sum 20231788-cleanroom-tensor2-final-review-55f3b43-ci33428194982.zip
unzip -Z1 <zip> | wc -l
unzip -t <zip>
unzip -q <zip> -d <fresh-directory>
(cd <fresh-directory> && sha256sum -c MANIFEST.sha256)
sha256sum HANDOFF_CONTENTS.md MANIFEST.sha256 FINAL_REVIEW_TASK.md
cmp FINAL_REVIEW_TASK.md chatgpt-pro-tensor2-final-review-01.md
```

Results:

- size `8,919,510`;
- ZIP SHA-256
  `31c96c983cdff1613ab0f95972655d7c5314e420ea585c358de234c4eb0ff785`;
- 2,271 central-directory entries;
- `unzip -t`: 0;
- manifest `2,005/2,005`: 0;
- internal handoff/manifest/task hashes matched binding;
- internal and external task bytes matched.

Gitleaks was **not rerun locally**. The Gitleaks 8.30.1 results are retained
package-generation evidence from the supplied binding.

## 2. Paper inspection

The supplied `references/2023.1788.pdf` was rendered with the local PDF render
utility and page 7 was visually inspected. Definition 4.1, Lemma 4.2, the
low-low omission, and the no-modulus-consumption interpretation were checked
from that page. This was inspection, not a numerical experiment.

## 3. Base/current/delivery reconstruction checks

Actually run:

```sh
git apply --reverse --check PROJECT_DIFF.patch
git apply --reverse PROJECT_DIFF.patch        # disposable copy only
git apply --check PROJECT_DIFF.patch           # reconstructed base
git apply PROJECT_DIFF.patch                   # fresh round-trip copy
diff -qr <round-trip> cleanroom-project/
sha256sum prior-tensor2-delivery/extracted/0[1-5]-*.patch
git apply --check 01-red-api.patch
git apply 01-red-api.patch
...
git apply --check 05-final-docs.patch
git apply 05-final-docs.patch
sha256sum <base>/tests/dcp_rcb_test.cpp <final>/tests/dcp_rcb_test.cpp
```

Results:

- base reconstruction: successful;
- base-to-head forward apply-check: 0;
- forward round-trip tree diff: 0 bytes;
- all five prior patch hashes matched the declared values;
- every ordered `git apply --check`: 0;
- `dcp_rcb_test.cpp` base/final SHA-256 identical:
  `9f93e3794183d545338462bd7b6d5b9ccc787dc27b8555359f0dda7349105596`.

All 22 extracted files from the preceding delivery were enumerated/inspected.

## 4. Local pristine OpenFHE build/install

The supplied OpenFHE 1.5.0 source export bound to
`df495ba2e91739a6dc8f1de254fc5a41155ce504` was configured Release with unit
tests/examples/benchmarks/extras disabled and OpenMP enabled, then built and
installed to a review-local prefix.

The interactive tool harness terminated earlier build invocations before they
completed; those interrupted calls are **not** treated as passing builds.
Incremental continuation subsequently completed the build and `cmake --install`
successfully. The installed `OpenFHEConfig.cmake` and libraries were then used
for project tests.

No local OpenFHE unit-test suite was run.

## 5. Local ordered TDD replay

### 01 compile red

Reconstructed base + `01-red-api.patch`:

```text
configure = 0
build     = 2 (expected red)
CTest     = not run
```

First intended errors included absence of
`TensorCiphertextPair`, `TensorScaleDescriptor`, and `DoubleCKKS::Tensor2`.

### 02 scaffold

Base + patches 01-02:

```text
configure = 0
build     = 0
CTest     = 0; 1/1 dcp_rcb passed
```

No Tensor behavioral CTests existed at this boundary.

### 03 runtime red

Base + patches 01-03:

```text
configure = 0
build     = 0
CTest     = 8; 1/5 passed
```

`dcp_rcb` passed and all four Tensor2 cases independently failed on the
immediate-throw scaffold.

### 03b current fifth-test behavior probe

Review-only composition: unchanged scaffold plus the current
`tensor2_test.cpp`/CTest registration:

```text
configure = 0
build     = 0
CTest     = 8; 1/6 passed
```

All five Tensor2 tests independently failed, including
`tensor2_prearithmetic_key_compatibility`. This is behavior-equivalent evidence,
not an assertion that this disposable directory is the exact Git object for
commit `482d27d0...`.

### 04 original implementation green

Base + patches 01-04:

```text
configure = 0
build     = 0
CTest     = 0; 5/5 passed
```

## 6. Exact current-head local build/test

Against the locally installed supplied pristine OpenFHE:

```sh
cmake -S cleanroom-project -B /mnt/data/t2local_exact_head_build \
  -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_PREFIX_PATH=/mnt/data/t2local_openfhe_install
cmake --build /mnt/data/t2local_exact_head_build --parallel 2
ctest --test-dir /mnt/data/t2local_exact_head_build --output-on-failure
```

Results:

```text
configure = 0
build     = 0
CTest     = 0
6/6 passed
total local CTest time = 0.05 s
```

The strict target build completed. Static production scan found exactly three
`EvalMultNoRelin` occurrences and zero `ModReduce`, `try`, or `catch`
occurrences in `src/double_ckks.cpp`.

This is local Linux evidence only.

## 7. DCP diagnostic regression probe

A disposable copy of the unchanged `dcp_rcb_test.cpp` was augmented with one
review-only assertion:

- clone a fresh valid DCP input;
- `SetKeyTag("")`;
- require the legacy message substring
  `DCP input key tag does not match its pair state`.

Results:

```text
reconstructed exact base: test exit 0
exact current head:       test exit 1
current diagnostic:
DoubleCKKS: DCP input key tag does not match its ciphertext state
```

This execution isolates P3-01.

## 8. Included current-head fix patch

Actually run:

```sh
git apply --check 0001-tensor2-exact-closure-fixes.patch
git apply 0001-tensor2-exact-closure-fixes.patch
cmake -S <patched-tree> -B <patched-build> \
  -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_PREFIX_PATH=/mnt/data/t2local_openfhe_install
cmake --build <patched-build> --parallel 2
ctest --test-dir <patched-build> --output-on-failure
```

Results:

```text
git apply --check = 0
git apply         = 0
configure         = 0
build             = 0
CTest             = 0
6/6 passed
total CTest time  = 0.06 s
```

The added empty-key-tag DCP assertion executes inside the existing `dcp_rcb`
CTest and passes on the patched tree.

Patch SHA-256:
`ade1349ec52bc944d89a39e8bf376229f53cb92b272237fc7b50eb405a2224e9`.

## 9. Retained final hosted evidence inspected, not rerun

Files inspected:

- `ci/run.json`;
- `ci/jobs.json`;
- `ci/linux-gcc.log`;
- `ci/windows-mingw64.log`.

They establish for **unpatched** exact head `55f3b43...`:

- run `33428194982`, attempt 1, `push`, completed/success;
- exact `head_sha` and tree;
- Linux `ubuntu-24.04`, CMake 3.31.6, GCC 13.3.0, 6/6;
- Windows 2022/MSYS2 MINGW64, CMake 4.4.2, GCC 16.2.0, 6/6.

No workflow was dispatched or rerun during this review.

## 10. Not run / not verified

- No local Windows build.
- No hosted run for the included patch.
- No provider access to recover the absent raw records for earlier hosted TDD
  runs.
- No Git object-graph verification because `.git` is absent.
- No precision experiment.
- No performance benchmark.
- No Relin2/RS2/Mult2 or repeated-multiplication test.
- No network-security review.
- No ZCode/Zima Windows same-commit review.
