# Final package binding — Tensor2 exact-current closure review

Generated: 2026-09-01 03:29 Asia/Shanghai

This external record was generated only after the final ZIP existed. The ZIP's
internal `HANDOFF_CONTENTS.md` names this two-record mechanism and contains all
non-self-referential package facts.

## Final attachment identity

- ZIP filename:
  `20231788-cleanroom-tensor2-final-review-55f3b43-ci33428194982.zip`
- Final byte size: `8,919,510`
- Final SHA-256:
  `31c96c983cdff1613ab0f95972655d7c5314e420ea585c358de234c4eb0ff785`
- ZIP central-directory entries: `2,271`
- Manifest-listed files: `2,005`
- Exact source head:
  `55f3b43c47b5b2464625afcc6a1f244724336d5b`
- Exact source Git tree:
  `2269bee6bac5e7cd1124ab78c49a750af9a38942`
- Exact final Actions run: `33428194982`, conclusion `success`.
- Official OpenFHE 1.5.0 commit:
  `df495ba2e91739a6dc8f1de254fc5a41155ce504`.
- Final-review task SHA-256:
  `1421ec8bf9f23e67eae9ee1b871b4d8422c49569174d1258693429319f285eb4`.
- Internal `HANDOFF_CONTENTS.md` SHA-256:
  `540b26f3e2935a323821243a90f282cce9fb17563c03fbd6c7965b1a096d9ba1`.
- Internal `MANIFEST.sha256` SHA-256:
  `c5d45ed54c528a68adfcb82c1edeb418ec6cdb9ea021cb2150033bd17aaa7c4f`.

## Final verification results

- Staged-tree secret scan: Gitleaks `8.30.1` scanned approximately `24.74 MB`
  and reported `no leaks found`.
- Freshly extracted-tree secret scan: Gitleaks `8.30.1` scanned approximately
  `24.74 MB` and reported `no leaks found`.
- Archive integrity: `unzip -t` passed with no compressed-data errors.
- Manifest: all `2,005` entries verified successfully after fresh extraction.
- Targeted filename exclusions passed: no `.env`, credential/token JSON,
  PEM/private-key file, Cookie database, or browser `Login Data` file.
- Targeted directory exclusions passed: no `.git`, `node_modules`, generated
  build tree, `CMakeFiles`, cache, or runtime/browser-state directory.
- Entry-path safety passed: no absolute path or `..` traversal entry.
- Extracted-tree equality passed: recursive staged-versus-fresh comparison
  produced zero bytes of output.
- Exact Git-export equality passed: `cleanroom-project/` was byte-identical to
  a fresh `git archive` of tree `2269bee6...`.
- Top-level shape contains exactly the 15 entries named by the internal
  manifest and shown by the archive listing.

## Commands used

```sh
git archive --format=tar --prefix=cleanroom-project/ 55f3b43...
git diff --binary --full-index 87c84b... 55f3b43...
gh api repos/leemaple/20231788./actions/runs/33428194982
gh api repos/leemaple/20231788./actions/runs/33428194982/jobs --paginate
gh api repos/leemaple/20231788./actions/jobs/<job-id>/logs
shasum -a 256 <file>
shasum -a 256 -c MANIFEST.sha256
gitleaks detect --no-git --source <tree> --redact --report-format json
unzip -t <zip>
unzip -q <zip> -d <fresh-directory>
find <tree> <targeted forbidden filename/directory predicates>
diff -qr <staged-tree> <fresh-tree>
diff -qr <cleanroom-project> <fresh-git-archive>
```

The ZIP and this binding must be uploaded together to the same saved ChatGPT
Pro conversation. Any identity mismatch is an input blocker. The package is
for a bounded algorithm/OpenFHE engineering review, not a network-security
assessment.
