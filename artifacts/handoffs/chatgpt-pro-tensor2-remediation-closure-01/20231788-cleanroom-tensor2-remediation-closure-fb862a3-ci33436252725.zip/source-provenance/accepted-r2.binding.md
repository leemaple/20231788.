# Final package binding — Tensor2 clean-room handoff r2

Generated: 2026-09-01 01:37 Asia/Shanghai

This file is the external handoff record supplied beside the ZIP. It was
generated after the final ZIP existed so that the archive can be bound without
the impossible requirement that it contain its own hash. The ZIP's internal
`HANDOFF_CONTENTS.md` names this exact binding mechanism and records every
non-self-referential verification result.

## Final attachment identity

- ZIP filename:
  `20231788-cleanroom-tensor2-base-87c84b-ci334114-r2.zip`
- Final byte size: `8,691,359`
- Final SHA-256:
  `eea8aca629e98bfc4fc719c2c7ddbf38610f654630bf92d499d5aa75826753be`
- ZIP central-directory entries: `2,219`
- Exact source base:
  `87c84b879c13b55cf15d6559d3317853228fdc05`
- Official OpenFHE 1.5.0 commit:
  `df495ba2e91739a6dc8f1de254fc5a41155ce504`
- Tensor2 task SHA-256:
  `5a932619c5916b32d1dc5e1de2de253f39c041954d096db291a944ef0161d2c6`
- Internal `HANDOFF_CONTENTS.md` SHA-256:
  `af07d16bb5815a2276a33e9c0554a40da9a1216dbbca723ca750698d4d989508`

## Final verification results

- Staged-tree secret scan: Gitleaks `8.30.1` scanned approximately
  `24.53 MB` and reported `no leaks found`.
- Final freshly extracted-tree secret scan: Gitleaks `8.30.1` scanned
  approximately `24.53 MB` and reported `no leaks found`.
- Archive integrity: `unzip -t` passed with no compressed-data errors.
- Manifest: `1,961` listed files; every `MANIFEST.sha256` entry verified.
- Targeted filename exclusions: passed; no `.env`, `.env.*`, credential/token
  JSON, PEM/private-key file, Cookie database, or browser `Login Data` file.
- Targeted directory exclusions: passed; no `.git`, `node_modules`, build tree,
  `CMakeFiles`, cache, or runtime-state directory.
- Extracted-tree equality: passed; recursive `diff -qr` between the final
  staged payload and fresh extraction produced zero bytes of output.
- Top-level shape remains exactly the 12 entries described in the internal
  handoff manifest.

## Commands used

```sh
stat -f '%z' <zip>
shasum -a 256 <zip>
unzip -Z1 <zip> | wc -l
unzip -t <zip>
unzip -q <zip> -d <fresh-directory>
(cd <fresh-directory> && shasum -a 256 -c MANIFEST.sha256)
gitleaks detect --no-git --source <stage> --redact --report-format json
gitleaks detect --no-git --source <fresh-directory> --redact --report-format json
find <fresh-directory> <targeted forbidden filename predicates>
find <fresh-directory> <targeted forbidden directory predicates>
diff -qr <stage> <fresh-directory>
```

## Remediation boundary

The first attachment attempt was correctly blocked before algorithm review
because its internal handoff manifest delegated too many packaging facts to the
dispatch message. That attempt produced no Tensor2 source or test patch. This
r2 package changes only `HANDOFF_CONTENTS.md` and the derived
`MANIFEST.sha256`; all task, paper, OpenFHE, CI, prior-review, and exact-base
source bytes are unchanged. Review must restart at the input gate and must not
infer any algorithm result from the blocked attempt.
