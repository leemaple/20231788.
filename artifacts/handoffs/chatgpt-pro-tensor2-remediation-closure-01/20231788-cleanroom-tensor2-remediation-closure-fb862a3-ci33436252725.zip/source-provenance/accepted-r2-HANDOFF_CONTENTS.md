# Tensor2 clean-room handoff manifest

Prepared: 2026-09-01 Asia/Shanghai

## Binding identities

- Implementation branch: `agent/codex-tensor2-01`.
- Exact source base:
  `87c84b879c13b55cf15d6559d3317853228fdc05`.
- Last production-source change:
  `4971d2292b5af0ddbbe0c7dbe5a2e87f45102ff1`.
- Official OpenFHE 1.5.0 commit:
  `df495ba2e91739a6dc8f1de254fc5a41155ce504`.
- Exact base Actions run: `33411494861`, conclusion `success`.
- Tensor2 task-definition coordination commit:
  `c3f0e13b8a9314a7ab1df7fb86e6e689eb6259ae`.
- Tensor2 task SHA-256:
  `5a932619c5916b32d1dc5e1de2de253f39c041954d096db291a944ef0161d2c6`.
- Tensor2 preflight SHA-256:
  `5b2f465f3c73b28422f8cd3715f28658d6ed0b745ca3ebd2f1745b1eb48149d6`.
- Tensor2 task-audit SHA-256:
  `249a40af38f4143bb943ca569f9a78b70b14b1e96f0982b0e75aac810faa73b6`.

## Package contents

- `TENSOR2_TASK.md`: the complete independently reviewed engineering task.
- `TENSOR2_PREFLIGHT.md`: Codex paper/OpenFHE source preflight and explicit
  inference boundaries.
- `TENSOR2_TASK_AUDIT.md`: two-agent task audit and final PASS dispositions.
- `cleanroom-project/`: task-needed files exported directly from exact Git
  commit `87c84b...`, without Git metadata or stale external-task histories.
- `SOURCE_EXPORT_SCOPE.md`: exact inclusion/exclusion rationale.
- `openfhe-1.5.0/`: pristine official OpenFHE source at `df495ba...`, including
  recursive third-party sources and no Git metadata.
- `dcp-closure-review/`: hash-verified final ChatGPT Pro DCP/RCB exact-commit
  review ZIP and all four extracted deliverables.
- `BASE_CI_EVIDENCE.md` and `ci/`: concise binding plus complete run JSON,
  Linux log, and Windows log for exact base `87c84b...`.
- `references/`: the user-supplied paper PDF and extracted text.
- `MANIFEST.sha256`: per-file SHA-256 manifest generated after staging.

## Important file hashes

- Production header:
  `7c45776cf1eba1db9efab5fa3c69e728c2c4d5e24239103184b4185afbbc9611`.
- Production source:
  `61cfe9bb07fd6c4c9ca4afa87265e1dc14e30693ceb9968df63f56df9bd7e05c`.
- Existing DCP/RCB test:
  `9f93e3794183d545338462bd7b6d5b9ccc787dc27b8555359f0dda7349105596`.
- DCP/RCB exact-closure output ZIP:
  `dfe82d67d64e008f8a6ae3b140617b0f1edee899d12786575e7b4fb9a6591cd5`.
- Linux base log:
  `417261f51c2bfa46a977c4d541bc2f0fda555bd47ea663ac4633581b6e57a115`.
- Windows base log:
  `9102def86c8802f99bd140e62c98b9524f808eb50405d4982084077e4e285f6b`.
- Paper PDF:
  `61d9b948b17b6a624d3bf3372462555288308011226d2893e9e6bc3d6d197eac`.

## Package-verification record

This corrected package uses two coordinated handoff records:

- this internal `HANDOFF_CONTENTS.md`, which records every non-self-referential
  package fact; and
- `20231788-cleanroom-tensor2-base-87c84b-ci334114-r2.binding.md`, supplied as
  a separate attachment beside the ZIP, which was generated only after the
  final ZIP existed and therefore binds its exact byte size and SHA-256.

The final packaging run established:

- ZIP central-directory entries: `2,219`;
- manifest-listed files: `1,961`, all verified successfully after fresh
  extraction;
- staged-tree secret scan: Gitleaks `8.30.1`, `no leaks found`;
- final freshly extracted-tree secret scan: Gitleaks `8.30.1`,
  `no leaks found`;
- final archive integrity: `unzip -t` passed with no compressed-data errors;
- targeted filename and directory exclusions: passed; no `.env`, credential
  or token JSON, private key, Cookie/browser-login database, `.git`,
  `node_modules`, build tree, CMake object directory, cache, or runtime-state
  path was present;
- extracted-tree equality: passed; the final extracted payload was recursively
  byte-identical to the final staged payload.

The external binding record repeats these facts, their exact commands, and the
final ZIP size/hash. This two-record mechanism is necessary because embedding
a final archive hash inside that same archive is self-referential. The binding
record is part of the supplied handoff evidence and must be checked before any
algorithm review or patching. Any mismatch is a blocker.
